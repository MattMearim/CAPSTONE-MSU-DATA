# APPROVED PROCEDURE: SRF Cryomodule Temperature Monitoring and Response
Document ID: FRIB-SOP-CRYO-042
Revision: 2.0
Status: Approved for Operations

## 1. System Overview
This document defines the approved operating temperature thresholds, data quality expectations, and required engineering responses for Superconducting Radio Frequency (SRF) cryomodule operations.

## 2. Operating Thresholds
* Nominal Operating Range: 1.8 K to 2.0 K
* Warning Range: 2.1 K to 2.4 K
* Critical Trip Limit: 2.5 K and above

## 3. Required Procedural Actions
* **Condition A (Nominal):** If the temperature remains at or below 2.0 K, no action is required. Continue standard RF operations.
* **Condition B (Warning):** If the temperature exceeds 2.0 K but remains below 2.5 K for more than 10 consecutive seconds, operators must reduce the RF gradient by 10% and inspect the primary cryogenic supply valves for flow restrictions.
* **Condition C (Critical/Quench Risk):** If the temperature reaches or exceeds 2.5 K, the system faces an immediate quench risk. Operators must immediately trip the RF power, halt operations, and initiate the cavity recovery protocol.

## 4. Sensor Data Quality Expectations
Temperature telemetry should not exhibit physically impossible step-changes. A temperature reading that jumps by more than 0.5 K instantaneously (within a single 1-second polling interval) must be flagged as a sensor fault, signal dropout, or electrical noise rather than a genuine thermodynamic change.
