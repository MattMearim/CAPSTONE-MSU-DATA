# NASA public data snapshot - data dictionary

Retrieved 2026-10-30 (approx. 15:40-16:30 America/Detroit) from public NASA web services. All values are as published by NASA; no values were corrected.

## power_frib_hourly.csv
Source: NASA POWER Hourly API v2.10 (power.larc.nasa.gov), community RE, point 42.7245 N, 84.4746 W (Michigan State University / FRIB, East Lansing, Michigan; POWER grid elevation 281.97 m). Time standard: UTC. Period 2026-10-01 00:00 to 2026-10-28 23:00 (672 hourly rows).

| Column | NASA parameter | Unit |
|---|---|---|
| time_utc | hour (UTC) | ISO 8601 |
| air_temperature [C] | T2M, temperature at 2 m | degrees Celsius |
| dew_point [C] | T2MDEW, dew/frost point at 2 m | degrees Celsius |
| relative_humidity [%] | RH2M, relative humidity at 2 m | percent |
| surface_pressure [kPa] | PS, surface pressure | kilopascal |
| wind_speed_10m [m/s] | WS10M, wind speed at 10 m | metres per second |
| wind_direction_10m [deg] | WD10M, wind direction at 10 m (from which the wind blows) | degrees |
| precipitation [mm/h] | PRECTOTCORR, precipitation corrected | millimetres per hour |

## power_frib_daily.csv
Source: NASA POWER Daily API v2.10, same point. Time standard: local solar time (LST), not UTC. Period 2025-10-01 to 2026-10-28 (393 daily rows).

| Column | NASA parameter | Unit |
|---|---|---|
| date | day (LST) | YYYY-MM-DD |
| air_temperature_mean [C] | T2M | degrees Celsius |
| air_temperature_max [C] | T2M_MAX | degrees Celsius |
| air_temperature_min [C] | T2M_MIN | degrees Celsius |
| relative_humidity [%] | RH2M | percent |
| surface_pressure [kPa] | PS | kilopascal |
| wind_speed_10m [m/s] | WS10M | metres per second |
| precipitation [mm/day] | PRECTOTCORR | millimetres per day |
| solar_irradiance [kWh/m^2/day] | ALLSKY_SFC_SW_DWN, all-sky surface shortwave downward irradiance | kilowatt-hours per square metre per day |

NASA POWER fill value: **-999** means the value is not available (for example, recent days whose satellite inputs have not been processed yet).

## jpl_fireballs.csv
Source: NASA/JPL CNEOS Fireball Data API v1.2 (ssd-api.jpl.nasa.gov/fireball.api). Fireballs (bright meteors) detected by U.S. Government sensors, 2024-01-01 to retrieval. 89 rows.

| Column | Meaning | Unit |
|---|---|---|
| time_utc | peak brightness time | ISO 8601 UTC |
| latitude [deg] | latitude of peak brightness; negative = south | degrees |
| longitude [deg] | longitude of peak brightness; negative = west | degrees |
| altitude [km] | altitude above the geoid at peak brightness | kilometres |
| velocity [km/s] | pre-impact velocity | kilometres per second |
| radiated_energy [1e10 J] | approximate total optical radiated energy | units of 10^10 joules |
| impact_energy [kt] | calculated total impact energy | kilotons of TNT |

Blank cells mean NASA did not publish that value.

## jpl_close_approaches.csv
Source: NASA/JPL SBDB Close-Approach Data API v1.5 (ssd-api.jpl.nasa.gov/cad.api). Near-Earth asteroid close approaches to Earth within 0.02 au, 2026-09-01 to 2026-12-31. 204 rows.

| Column | Meaning | Unit |
|---|---|---|
| time_tdb | time of close approach, TDB (Barycentric Dynamical Time, about 69 s ahead of UTC) | ISO 8601 |
| object | asteroid designation | category |
| distance [au] | nominal approach distance (rounded to 6 decimals) | astronomical units |
| distance_min [au] / distance_max [au] | 3-sigma minimum / maximum distance | astronomical units |
| relative_velocity [km/s] | velocity relative to Earth at close approach (rounded to 3 decimals) | kilometres per second |
| absolute_magnitude [mag] | absolute magnitude H (lower = larger object) | magnitudes |
| diameter [km] | diameter if known | kilometres |
| time_uncertainty | 3-sigma close-approach time uncertainty, formatted days_hours:minutes | category |
| status | past = before retrieval; predicted = after retrieval | category |

Reference values: 1 au = 149,597,870.7 km; 1 lunar distance (LD) = 384,400 km = 0.002569555 au.

## documents/NTRS-*.md
32 bibliographic records (title, date, type, NASA center, authors, keywords, abstract) from the NASA Technical Reports Server (ntrs.nasa.gov) on radiation effects testing of electronics - single-event effects (SEE) and total ionizing dose (TID) - from 1984 to 2026. Text is as published by NTRS, including NTRS's own typos and formatting.
