# NASA Live Test Data for the FRIB LLM Wiki

Real public NASA data, pulled live on 2026-10-30, in the only two formats the system accepts: **CSV** and **Markdown**.

## What to feed the wiki

Upload **only `wiki_input/`**. Everything else stays out.

| Folder | Files | What it is |
|---|---|---|
| `wiki_input/datasets/` | 4 CSV | Measurement tables, header style `name [unit]` |
| `wiki_input/documents/` | 33 MD | 32 NASA technical-report records on radiation testing of electronics + `data_dictionary.md` |
| `answer_key/` | **do not ingest** | 50 test questions with computed answers, plus file checksums |
| `refresh/` | **do not ingest** | Script that re-pulls fresh numbers from NASA |

### Suggested upload order (smaller batches)
1. `documents/data_dictionary.md` (tells the wiki what the columns and units mean)
2. `datasets/power_frib_hourly.csv` and `power_frib_daily.csv` (weather at the FRIB site)
3. `datasets/jpl_fireballs.csv` and `jpl_close_approaches.csv` (space data)
4. `documents/NTRS-*.md`, in two batches of 16 if needed

## The datasets

| File | Rows | Source | Time column |
|---|---|---|---|
| `power_frib_hourly.csv` | 672 | NASA POWER, hourly, at MSU/FRIB (42.7245 N, 84.4746 W), Oct 1-28 2026 | `time_utc` (UTC) |
| `power_frib_daily.csv` | 393 | NASA POWER, daily, same point, Oct 2025 - Oct 2026 | `date` (local solar time) |
| `jpl_fireballs.csv` | 89 | NASA/JPL CNEOS fireball reports since 2024 | `time_utc` |
| `jpl_close_approaches.csv` | 204 | NASA/JPL asteroid close approaches within 0.02 au, Sep-Dec 2026 | `time_tdb` (TDB, not UTC) |

## Things that will stress-test the system (on purpose - this is real NASA data)

- **Fill values:** `-999` means "no data" in the POWER files (5 irradiance days, plus 2026-10-28 is all -999). A system that averages them gets wrong answers.
- **Unusual units** that a unit parser may not recognise: `au`, `mag`, `1e10 J`, `kt`, `deg`, `kWh/m^2/day`, `mm/day` vs `mm/h`.
- **Time-standard mismatch:** the hourly file is UTC, the daily file is local solar time, so "Oct 15 rainfall" differs between them (6.86 vs 14.15 mm). Neither file is wrong.
- **Blank cells:** 31 fireballs have no velocity; one has no location.
- **Look-alike documents:** two NTRS records share the exact title "HSYE-117RH ..." but describe different tests.
- **Name variants:** Michael Campola appears under 6 spellings across 11 documents.
- **Typos as published by NASA:** "Vix-11 Pro" (meaning Virtex-II Pro).
- **A hidden control character** (U+0002) and HTML tags in `NTRS-20250006729.md`.
- **Gaps:** nothing mentions FRIB itself; the only MSU record is about NSCL (FRIB's predecessor), 2004.

## Testing
Ask the wiki the questions in `answer_key/questions.csv` (or `.md`) and compare its answers. Each question lists a category (lookup, aggregation, unit conversion, data quality, contradictions, aliases, gaps), a difficulty, and the source file(s).

## Getting fresh numbers
On a Mac with internet access: `python3 refresh/refresh_nasa_data.py`. This overwrites the 4 CSVs with current data. Afterwards the numeric answers in the answer key no longer match, but the document questions still do.

## Notes
- Sources: NASA POWER (power.larc.nasa.gov), JPL SSD/CNEOS APIs (ssd-api.jpl.nasa.gov), NASA Technical Reports Server (ntrs.nasa.gov). All public, no API key needed.
- NASA's space-weather service (DONKI) was down at retrieval time, so solar-flare data is not included.
- `answer_key/checksums_sha256.csv` lets you confirm that the files weren't changed.
