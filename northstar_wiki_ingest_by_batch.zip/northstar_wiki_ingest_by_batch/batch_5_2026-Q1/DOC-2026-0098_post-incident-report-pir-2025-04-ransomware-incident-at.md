---
doc_id: DOC-2026-0098
title: Post-Incident Report PIR-2025-04 - Ransomware Incident at Riverbend (SI-2025-11)
doc_type: IT post-incident report
source_system: Corporate IT (Confluence export)
author: Nina Osei
date: 2026-01-08
revision: 1.0
status: final
sensitivity: confidential
related_ids: SI-2025-11; PRJ-2503; Meridian ERP; WrenchLog 7
---

# Post-Incident Report PIR-2025-04
**Incident:** SI-2025-11 - Ransomware on Riverbend file and application servers
**Author:** Nina Osei, IT Security Manager | **Approved:** Rebecca Tran, CIO, 2026-01-08
**Distribution:** Northstar leadership, Riverbend leadership, Corporate IT

## 1. Summary
On Monday 2025-11-24 at approximately 03:40 ET, ransomware encrypted the Riverbend file server FS-RB-02 and the Meridian ERP application server. Meridian was unavailable at Riverbend from 05:30 on 11/24 until 18:00 on 11/27 (about 84.5 hours). Riverbend production continued using paper procedures. WrenchLog 7 (maintenance) ran on a separate network segment and was not affected. No ransom was paid. No evidence of data exfiltration was found.

## 2. Initial access - corrected finding
Early in the response (11/24-11/26), the team suspected the Bridgewell Consulting remote-access account used for the Kestrel CMMS migration, because of a VPN session at 01:12 on 11/24. That account was disabled on 11/26 as a precaution.

**Forensic analysis disproved this.** The 01:12 session was the scheduled nightly asset-data synchronization job, consistent with the previous 46 nights, and touched only the Kestrel staging database. The actual initial access was:

- 2025-11-21 14:06: a Riverbend Finance office user received a phishing email impersonating the payroll portal.
- 14:09: the user entered credentials on the fake page and approved a multi-factor push prompt.
- 11/21-11/23: the attacker used the account to enumerate shares and staged tooling on FS-RB-02.
- 11/24 03:40: encryption launched.

## 3. Timeline (ET)
| Time | Event |
|---|---|
| 11/21 14:06 | Phishing email delivered |
| 11/21 14:09 | Credentials entered; MFA push approved |
| 11/23 22:00 | Last clean Meridian backup |
| 11/24 01:12 | Bridgewell sync job runs (benign) |
| 11/24 03:40 | Encryption begins on FS-RB-02 |
| 11/24 05:30 | Meridian offline |
| 11/24 06:10 | Plant switches to paper (G. Lawson) |
| 11/25 | First notice to insurer (Granite Shield, claim GS-CY-25-3381) |
| 11/26 | Bridgewell account disabled (precaution) |
| 11/27 18:00 | Meridian restored |
| 12/01 | Paper tickets keyed |
| 12/09 | Bridgewell account re-enabled with new controls |

## 4. Impact
- Production: no loss of output; reporting delayed. 14 duplicate production tickets and 6 duplicate shipments created during re-keying (Finance memo 12/03).
- Shipping: 19 manual BOLs.
- Projects: Bridgewell access was suspended 11/26-12/09. Kestrel migration rehearsal 2 slipped two weeks. This contributed to the decision to move Kestrel go-live off 2026-01-05 (see Kestrel lessons learned).
- Cost (preliminary): forensics, overtime, and rebuild about $186,000 before insurance.

## 5. What went well
- WrenchLog segmentation held.
- Paper fallback was in place within 40 minutes.
- Backups were clean and restorable.

## 6. What did not go well
- MFA push prompts could be approved without number matching.
- FS-RB-02 had a flat permission model; a Finance account could write to production shares.
- The Riverbend emergency plan had no IT-outage section.
- Duplicate re-keying, because two groups keyed the same paper.

## 7. Corrective actions
| # | Action | Owner | Due |
|---|---|---|---|
| 1 | Number-matching MFA for all users | R. Tran | 2025-12-15 (done) |
| 2 | Re-permission FS-RB-02 by role | G. Lawson | 2026-02-28 |
| 3 | Add IT-outage annex to EHS-EP-03 | N. Brooks / G. Lawson | 2026-03-31 |
| 4 | Single owner for post-outage re-keying (Finance) | M. Fairbanks | done |
| 5 | Phishing simulation quarterly | N. Osei | 2026-Q1 start |
| 6 | Vendor remote access via jump host with session recording | L. Pike | 2026-01-31 |

## 8. Open items
- Insurance claim GS-CY-25-3381 in progress.
- Identity of the Finance user is held by HR and Corporate IT and is not included in this report.
