---
doc_id: DOC-2026-0119
title: Plant Manager All-Hands - Notes (Feb 24, 2026)
doc_type: Meeting minutes
source_system: OneNote export
author: Lorraine Mbeki
date: 2026-02-24
revision: 
status: final
sensitivity: internal
related_ids: 
---

**All-hands, cafeteria, A/B shift overlap 14:30** - notes by L. Mbeki

Victor Lindqvist (Plant Manager, started 2/16) - first all-hands:
- Background: 20 years woven/nonwoven, last at a technical-textiles plant in the Midwest.
- First 90 days: listen; walk every shift; fix the top 3 "chronic" problems (asked supervisors to nominate).
- Thanked Denise for running the plant since October.
- Safety: "we got lucky with the fire in December and the forklift last May."
- Q: "Is Building 3 closing?" A: No. Knitting is growing (Tallgrass program).
- Q: "Will the new stenter really come in June?" A: Vireo says shipping on time; will confirm in March.
- Nominated chronic problems so far: Knitter 7, Old Blue pump seals, Stenter 1 chains.
