---
doc_id: DOC-2026-0114
title: Post-Storm Review Minutes - Ice Storm Jan 24-27
doc_type: Meeting minutes
source_system: OneNote export
author: Natalie Brooks
date: 2026-02-10
revision: 
status: final
sensitivity: internal
related_ids: EHS-EP-03
---

**Date:** 2/10/2026 | **Attendees:** D. Okafor, N. Brooks, G. Summers, C. Jimenez, K. Oduya, R. Delgado, B. Nash, G. Lawson, L. Mbeki

**What happened:** grid power lost 1/24 21:40, back 1/26 04:50 (about 31 h). Plant down 57 h total (restart A shift 1/27). No injuries. No permit issues - EQ tank peaked at 41%.

**Went well**
- Controlled shutdown done in 25 min.
- Shift status line reached about 80% of employees.

**Problems**
- WWTP has no standby generator. If the outage had lasted longer than about 40 h we would have had to stop drains for the whole plant on restart.
- Knitting oil-mist line on the restart checklist was not signed - nobody owns it.
- Cardinal replacement shipment slipped 3 days.
- No IT-outage section in EHS-EP-03 (also an action from the November IT incident).

**Actions**
| Action | Owner | Due |
|---|---|---|
| Quote rental generator agreement for WWTP | G. Summers | 3/15 |
| Add knitting owner to EP-03-F2 | H. Kowalski | 2/28 |
| IT-outage annex for EHS-EP-03 | N. Brooks / G. Lawson | 3/31 |

Note: Rev 6 of EHS-EP-03 not issued before Natalie's departure; carried to new EHS Manager.
