---
doc_id: DOC-2026-0136
title: PRJ-2503 Kestrel CMMS Migration - Lessons Learned
doc_type: Project closeout report
source_system: Corporate IT (Confluence export)
author: Leonard Pike
date: 2026-04-14
revision: 
status: final
sensitivity: internal
related_ids: PRJ-2503; SI-2025-11
---

# PRJ-2503 Kestrel CMMS - Lessons Learned
Leonard Pike, IT Program Manager | with Curtis Albright (site) and Rachel Imhoff (Bridgewell)

## Schedule
| Milestone | Plan | Actual |
|---|---|---|
| Asset hierarchy cleanup | 2025-10-31 | 2026-01-23 |
| Migration rehearsal 2 | 2025-12-01 | 2025-12-15 |
| Go-live | 2026-01-05 | 2026-03-02 |

## Why go-live moved
Two causes, both real:
1. **Asset hierarchy cleanup** took about 12 weeks longer than planned (1,900 asset records, 240 duplicates, missing locations for moved equipment). This was the main driver.
2. **The November ransomware incident** (SI-2025-11) suspended Bridgewell's remote access 11/26-12/09 and pulled Greg Lawson and Corporate IT onto recovery for most of December.

The site cutover email (2/27) mentions only the first cause.

## What we would do differently
- Physically verify asset locations before migration. At least one moved asset (cutting table 3, now at the DC) was migrated with its old location.
- Keep consultant access on a jump host from day one.
- Plan failure codes earlier; technicians were not trained on them until the week of go-live.

## Final cost
$192k vs $185k budget.
