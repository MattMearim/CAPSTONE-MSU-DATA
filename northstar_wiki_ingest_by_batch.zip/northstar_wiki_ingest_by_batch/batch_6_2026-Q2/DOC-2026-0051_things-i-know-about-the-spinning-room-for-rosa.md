---
doc_id: DOC-2026-0051
title: Things I know about the spinning room (for Rosa)
doc_type: Tribal knowledge note
source_system: Shared drive (Spinning folder)
author: Walt
date: unknown
revision: 
status: final
sensitivity: internal
related_ids: RB-SP-011..016; RB-UT-031
---

Rosa -

Some things that aren't written down anywhere, or are written down wrong. You know most of this already.

1. **Humidity.** The SOP says 52% +/- 3 in the ring room. Forget it in summer. Above about 80 F in the room you need 57-58% or your ends-down on frames 1-4 go through the roof. We figured this out in the 2023 humidity study with the Humitek guy. Winter, 52 is fine.
2. **Frames 5 and 6** are the newer ones (2017) and take the lighter travelers. Don't let anybody standardize them with 1-4. The spindle count is the same though, 1,008 each.
3. **Cards.** Since they rewired the cards last spring, card 3 runs heavier sliver weight on the same setting. Check it every Monday.
4. **Humidification plant 1** clogs nozzles when the water softener is regenerating. Gail knows.
5. Old Blue in the dyehouse isn't mine but since everybody asks - it came in the winter of '08, before Ken's time. Paid something like $285k for it back then.
6. Air-jet spinners hate low air pressure. If the compressors trip, they're the first thing that goes down. Since the new VSD compressor it's been better.
7. The Delta Crest bales from the western warehouse run shorter staple than the certs say. Test more of them.

It's been a good 32 years. Call me if you need me.

Walt
