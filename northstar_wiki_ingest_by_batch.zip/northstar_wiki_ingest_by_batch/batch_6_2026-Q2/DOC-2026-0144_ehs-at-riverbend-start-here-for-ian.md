---
doc_id: DOC-2026-0144
title: EHS at Riverbend - start here (for Ian)
doc_type: Onboarding guide
source_system: Shared drive (EHS folder)
author: Carla Jimenez
date: 2026-05-15
revision: 
status: final
sensitivity: internal
related_ids: IU-0447; NOV-PCWRA-2025-017; MOC-2025-031; INC-2025-014; INC-2025-031; EHS-EP-03
---

Ian - welcome. This is what I wish someone had written down for me. It isn't official; check Q-Ledger for the real procedures.

## People
- **Paul Garrity** at PCWRA (pretreatment coordinator). Call him before he hears about anything from someone else.
- **Sam Kwarteng** (Samuel, Corporate EHS) audits us every November. The 2025 report is in the portal; the 2024 one he still refers to ("F-07") was before my time in the portal migration - I've never seen a copy.
- **Gail** knows the boilers and the WWTP pumps better than anyone. **Omar** is the licensed boiler operator on most nights.
- **Capt. Ellery** at Calder Falls FD Station 2 came to the stenter fire. She wants a pre-incident plan walk-through this year.

## Permits
- Wastewater: **IU-0447**. pH 6.0-10.0, COD 2,500 mg/L, TSS 600 mg/L. We had pH 10.9 on 8/7/25 (NOV-PCWRA-2025-017) and a TSS exceedance 2/18/26 during the DAF tie-in. The upgrade (PRJ-2505) finished 4/17.
- Air: **AQ-5521-R2** (boilers + stenters). Annual report due March.

## Open items you inherit
1. MOC-2025-031 - duct fire protection, training records missing.
2. EHS-EP-03 Rev 6 - Natalie started it, never issued.
3. Forklift pre-use - closed in March, but watch it; it was a repeat finding.
4. Keystone temp HAZCOM orientation backlog.

## Things that bite
- Dyehouse drains: one jet at a time (SOP-DY-007 Rev 3). If two drain together, pH spikes.
- Probe cleaning on the pH system weekly. The 2025 exceedance was a fouled probe.
- "The Annex" = Building 4. Old-timers still say Annex.
