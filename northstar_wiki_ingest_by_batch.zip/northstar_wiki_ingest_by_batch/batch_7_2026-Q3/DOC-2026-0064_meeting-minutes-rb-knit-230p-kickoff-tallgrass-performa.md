---
doc_id: DOC-2026-0064
title: Meeting Minutes - RB-KNIT-230P Kickoff (Tallgrass Performance Pique)
doc_type: Meeting minutes
source_system: OneNote export
author: Aisha Bello
date: 2026-08-05
revision: 
status: final
sensitivity: internal
related_ids: PRJ-2509; RB-KNIT-230P; CUS-205
---

**Date:** 8/5/2026 | **Attendees:** H. Kowalski, O. Park, K. Oduya, S. Haddad, B. Castillo, T. Grant, A. Bello (notes), E. Foster, Tallgrass (2, by video)

**Discussion**
- Tallgrass confirmed FY27 volume ~22,000 kg/month from September, ramp to 30,000 kg by December.
- Knitters 7 and 8 (28G) are the only ones with the right gauge. Hannah: Knitter 7 has been solid since the cam box change in June.
- Yarn: 75D/72F PES from Brightline, spandex from Elastex. Ben to set up blanket PO.
- Heat-set: Stenter 2 until the new stenter is commissioned. Brianna worried about capacity in September when Stenter 1 comes out.
- Wicking test: Tallgrass method TG-W3, <= 3 s. Julia to set up in TestBench.

**Actions**
| Action | Owner | Due |
|---|---|---|
| Spec sheet Rev A | O. Park | 8/14 |
| Lab dip approval (8 colors) | S. Haddad | 8/21 |
| First bulk lot | H. Kowalski | 9/8 |
