$ErrorActionPreference='Stop'
$fribRoot=Split-Path -Parent $PSScriptRoot
$fribPython=Join-Path $fribRoot 'dependencies\venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $fribPython -PathType Leaf)) { Write-Output 'No installed workspace to stop.';exit 0 }
& $fribPython (Join-Path $fribRoot 'dependencies\run_frib.py') stop
exit $LASTEXITCODE
