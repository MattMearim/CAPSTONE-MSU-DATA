[CmdletBinding()]
param([Parameter(ValueFromRemainingArguments=$true)][string[]]$LauncherArguments)
$ErrorActionPreference='Stop'
$fribProjectRoot=[IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$fribDependencies=Join-Path $fribProjectRoot 'dependencies'
$fribTranscript=$false
$fribLock=$null
try {
    if (-not [Environment]::Is64BitOperatingSystem -or $env:OS -ne 'Windows_NT') { throw 'This launcher requires 64-bit Windows.' }
    if (-not (Test-Path -LiteralPath (Join-Path $fribProjectRoot 'FRIB_Final_Project\FRIB_Decision_Support\pyproject.toml'))) { throw 'Extract the entire ZIP into a normal writable folder before starting.' }
    if (Test-Path -LiteralPath $fribDependencies) {
        $fribEntry=Get-Item -LiteralPath $fribDependencies -Force
        if (-not $fribEntry.PSIsContainer -or ($fribEntry.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'The dependencies folder must be a normal local directory.' }
    }
    foreach ($fribChild in @('','logs','temp')) { New-Item -ItemType Directory -Path (Join-Path $fribDependencies $fribChild) -Force | Out-Null }
    try { $fribLock=[IO.File]::Open((Join-Path $fribDependencies 'setup.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
    catch [IO.IOException] { throw 'Setup or startup is already running. Wait for its window to finish.' }
    Start-Transcript -LiteralPath (Join-Path $fribDependencies 'logs\setup.log') -Append | Out-Null
    $fribTranscript=$true
    $env:TEMP=Join-Path $fribDependencies 'temp';$env:TMP=$env:TEMP
    $env:PYTHONUTF8='1';$env:PYTHONIOENCODING='utf-8'
    foreach ($fribFile in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'payload') -File) {
        if ($fribFile.Extension -in @('.py','.ps1','.cmd','.md','.txt')) {
            $fribTarget=Join-Path $fribDependencies $fribFile.Name
            if (Test-Path -LiteralPath $fribTarget) {
                $fribExisting=Get-Item -LiteralPath $fribTarget -Force
                if (($fribExisting.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $fribExisting.LinkType -eq 'HardLink') { throw 'Setup script paths must not redirect through links.' }
            }
            Copy-Item -LiteralPath $fribFile.FullName -Destination $fribTarget -Force
        }
    }
    $fribPython=Join-Path $fribDependencies 'venv\Scripts\python.exe'
    $fribEngine=Join-Path $fribDependencies 'ollama\ollama.exe'
    $fribReceipt=Join-Path $fribDependencies 'ai\real-ai-validation.json'
    $fribReady=(Test-Path -LiteralPath $fribPython -PathType Leaf) -and (Test-Path -LiteralPath $fribEngine -PathType Leaf) -and (Test-Path -LiteralPath $fribReceipt -PathType Leaf)
    if (-not $fribReady) {
        Write-Output 'First setup: installing everything into the dependencies folder.'
        Write-Output 'Internet is required. Keep this window open until setup finishes.'
        & (Join-Path $fribDependencies 'Setup-Workspace.ps1')
        if (-not ((Test-Path -LiteralPath $fribPython -PathType Leaf) -and (Test-Path -LiteralPath $fribEngine -PathType Leaf) -and (Test-Path -LiteralPath $fribReceipt -PathType Leaf))) { throw 'Setup did not create a complete verified installation.' }
    } else { Write-Output 'Reusing the installed dependencies and models.' }
    Write-Output 'Starting the workspace...'
    & $fribPython (Join-Path $fribDependencies 'run_frib.py') start @LauncherArguments
    if ($LASTEXITCODE) { throw "Workspace startup failed ($LASTEXITCODE)." }
} catch {
    Write-Host ('FRIB could not start: '+$_.Exception.Message) -ForegroundColor Red
    if ($fribTranscript) { Stop-Transcript | Out-Null;$fribTranscript=$false }
    exit 1
} finally {
    if ($fribTranscript) { Stop-Transcript | Out-Null }
    if ($fribLock) { $fribLock.Dispose() }
}
