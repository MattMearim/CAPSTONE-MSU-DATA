FRIB — ONE-CLICK WINDOWS EDITION

1. Extract the entire ZIP into a normal writable folder.
2. Double-click START_PROJECT.bat.
3. Wait for first setup to finish. The app opens automatically.

First launch requires internet and downloads several GB of tools and AI assets.
Everything is installed into the dependencies folder created beside the batch file.
Later launches reuse it. STOP_PROJECT.bat stops the workspace.

If setup fails, read dependencies/logs/setup.log and open START_PROJECT.bat again.
Do not move the folder after installation. Share this original lightweight ZIP
when giving the system to another person.
