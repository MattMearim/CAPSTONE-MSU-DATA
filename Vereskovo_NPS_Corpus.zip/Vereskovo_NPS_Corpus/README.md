# Vereskovo NPS test corpus (fictional, modeled on the 1986 Chernobyl accident)

A synthetic multi-document corpus for testing an LLM wiki. Built from `chernobyl_corpus_prompt.txt`.
Everything is fictional: the station, town, people, agencies and documents. The general sequence of events and the reactor physics follow a Chernobyl-type accident.

## What to feed the wiki

Only **Markdown (.md) and CSV (.csv)** files - 152 Markdown + 33 CSV = 185 documents dated 1985-1987 (plus a 1983 regulations extract and two year-end 1987 summaries filed in January 1988). The "current state" is December 1987.

Feed **`corpus_by_batch/` in order, batch_01 first** (same files as `corpus/`, grouped by date):

| Batch | Files | Dates |
|---|---|---|
| batch_01 | 24 | 1983-10-01 to 1986-02-20 |
| batch_02 | 24 | 1986-03-01 to 1986-05-17 |
| batch_03 | 24 | 1986-05-17 to 1986-05-21 |
| batch_04 | 24 | 1986-05-21 to 1986-06-20 |
| batch_05 | 24 | 1986-06-20 to 1986-09-10 |
| batch_06 | 24 | 1986-09-15 to 1986-12-20 |
| batch_07 | 24 | 1986-12-28 to 1987-08-25 |
| batch_08 | 17 | 1987-09-14 to 1988-01-20 |

`manifest.csv` lists every file with its date, type, author and (for CSVs) a description of the source - CSVs have no header block, so the manifest is their metadata. The manifest can be ingested too, but don't ingest anything else.

## Do NOT feed the wiki (grading only)

| File | What it is |
|---|---|
| `answer_key/evaluation_questions.csv` / `.md` | 134 questions with answers and supporting doc IDs |
| `answer_key/contradiction_ledger.md` | 33 seeded contradictions (4 genuinely unresolvable) with resolutions |
| `answer_key/supersession_ledger.md` | 25 facts that change over time (old -> new) |
| `answer_key/gaps_ledger.md` | 14 facts that are referenced but never documented |
| `answer_key/seeded_issues.md` | Typos, duplicates, header errors, rumours, numbers that don't add up |
| `answer_key/alias_ledger.md` | Every alias / spelling variant |
| `answer_key/entity_registry.md` | 71 people, 50 equipment items, 22 settlements, 24 organizations, materials, projects |
| `answer_key/timeline.md` | Master timeline |
| `world_bible.md` | The whole world definition and the planned document list |

## Main storylines

1. The turbine rundown safety test and its program revisions
2. The accident night - conflicting times and accounts
3. Radiation underestimated (meters at the top of their scale)
4. Firefighters and medical consequences
5. Evacuation - "temporary, three days" becomes permanent
6. Foreign detection before the official announcement
7. Root cause shifts from operator error (1986) to design flaws (1987)
8. Helicopter drops, the bubbler pool, the tunnel
9. Shelter construction, robots that fail
10. Liquidator dose records and the registry change
11. Trial
12. Units 1-3 restart dates slipping
13. Leadership changes
14. A chronic pump vibration problem

## Things in the CSVs that may stress your importer

- Unusual units: `[R/h]`, `[mR/h]`, `[Ci/km2]`, `[Ci/L]`, `[Bq/m3]`, `[MCi/day]`, `[kgf/cm2]`, `[rod equivalents]`, `[man-rem]`, `[um]`, `[thousand rubles]`
- Different time columns: `time_local`, `time_plant_computer`, `time_utc` (Varnland data)
- A column with no unit (`gross_beta`), blank cells, `>200` and `> scale` text in numeric columns, scientific notation (`6.1e-07`)
- A duplicated data row (helicopter drops) and a mistyped ID (`U4-MPC-03`)
