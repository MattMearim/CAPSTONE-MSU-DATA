# Supersession ledger

| ID | Fact | Old value | New value(s) | Documents |
|---|---|---|---|---|
| S01 | Evacuation / zone boundaries | town (18 May 1986) | 10-km (21 May) -> 30-km zone (23 May) -> Lisove (7 Jun) -> Kozhukhivka outside 30 km (14 Jun) -> Ruda Vereskivska strict control (Aug 1986), voluntary resettlement (Sep 1987) -> Vilshanka on resettlement list (Oct 1987) | DOC-1986-0032; DOC-1986-0056; DOC-1986-0059; DOC-1986-0071; DOC-1987-0028; DOC-1987-0027 |
| S02 | Dose limit for participants | 25 rem single limit (1986) | 10 rem per year from 1 Jan 1987 (station from 1 Feb 1987) | DOC-1986-0058; DOC-1986-0118; DOC-1987-0001 |
| S03 | Root cause of the accident | operator violations (Commission, 20 Jul 1986; Vienna briefing; verdict) | design deficiencies decisive, with operator actions (GNI working group, 20 Nov 1987); disputed by OKB-Kanal (10 Dec 1987) | DOC-1986-0091; DOC-1986-0098; DOC-1987-0022; DOC-1987-0032; DOC-1987-0035 |
| S04 | State of the reactor | 'being cooled' / intact (17 May, 03:45 and 11:00) | destroyed (Nikitin reconnaissance, 18 May 07:30) | DOC-1986-0024; DOC-1986-0027; DOC-1986-0038 |
| S05 | Death toll | 2 (press 20 May) | 31 official (Aug 1986 onward); 32 per internal medical summary (Dec 1986) | DOC-1986-0050; DOC-1986-0098; DOC-1986-0124 |
| S06 | Station director | V. S. Hrytsenko (to 2 Jul 1986) | S. L. Bondar temporarily (2-28 Jul) -> M. Yu. Belov acting (28 Jul) -> director (15 Sep 1986) | DOC-1986-0085; DOC-1986-0092; DOC-1986-0103 |
| S07 | Chief engineer | N. I. Savchenko (to 9 Jun 1986) | P. A. Orlov acting (9 Jun) -> chief engineer (6 Oct 1986) | DOC-1986-0072; DOC-1986-0112 |
| S08 | Minimum ORM | 15 rods (1983 regulations) | 30 rods (1986 revision, Units 1-3) | DOC-1983-0001; DOC-1986-0097; DOC-1987-0003 |
| S09 | Units 5-6 construction | active; Unit 5 commissioning planned 1988 | suspended 18 Jun 1986; terminated 31 Oct 1987 | DOC-1985-0001; DOC-1985-0009; DOC-1986-0076; DOC-1987-0029 |
| S10 | Unit 1 restart date | planned 1 Sep 1986 | permitted 29 Sep; minimum controlled power 1 Oct 1986; grid 4 Oct | DOC-1986-0107; DOC-1986-0108; DOC-1986-0114 |
| S11 | Unit 3 restart date | March 1987 / spring 1987 | Aug 1987 -> Q4 1987 -> actual 4 Dec 1987 | DOC-1986-0117; DOC-1986-0115; DOC-1987-0007; DOC-1987-0023; DOC-1987-0025; DOC-1987-0033 |
| S12 | Liquidator record IDs | L86-###### (1986 cards) | VR87-RR-NNNNN (all-union registry from 1 Mar 1987) | DOC-1987-0005; DOC-1987-0011 |
| S13 | Name of Unit 4 | Unit 4 / power unit No. 4 | 'Shelter object' (from 14 Dec 1986); press: 'sarcophagus' | DOC-1986-0121; DOC-1986-0123 |
| S14 | Fuel enrichment | 2.0% U-235 | 2.4% U-235 (1986 modification) | DOC-1985-0006; DOC-1986-0097 |
| S15 | Evacuation status | temporary, three days | permanent: town closed, town executive committee abolished (Jul 1987) | DOC-1986-0033; DOC-1986-0078; DOC-1987-0018; DOC-1987-0013 |
| S16 | Status of V. Ostapenko | missing (17 May 1986) | declared dead (12 Aug 1986); body not recovered | DOC-1986-0020; DOC-1986-0095 |
| S17 | Surname of the head of the cadres department | V. S. Kuzmina | V. S. Osipova (from 14 Feb 1987) | DOC-1986-0009; DOC-1987-0002; DOC-1987-0008 |
| S18 | Robot ROB-MRK2-01 | first MRK-2 unit (in service 22 Aug 1986) | destroyed 19 Sep 1986; ID reused for replacement (factory No. 0007) on 3 Oct 1986 | DOC-1986-0100; DOC-1986-0104; DOC-1986-0111 |
| S19 | Installation contractor name | Spetsmontazh Trust No. 3 | Spetsatomstroy-3 (from 1 Mar 1987) | DOC-1985-0009; DOC-1987-0006 |
| S20 | Shelter cost and completion target | 120 million rubles; October 1986 | 214 million to date + estimate 240 million; accepted 14 Dec 1986; final cost not determined (Dec 1987) | DOC-1986-0074; DOC-1986-0121; DOC-1987-0037 |
| S21 | Shelter steel quantity | about 7,000 t (design estimate, Jun 1986) | about 9,500 t (acceptance act, Dec 1986) | DOC-1986-0082; DOC-1986-0121 |
| S22 | Government Commission chairman | G. I. Zaitsev (17 May - 3 Jun 1986) | V. A. Demidov (from 3 Jun 1986) | DOC-1986-0017; DOC-1986-0069 |
| S23 | L. T. Golub | Major, head of Fire Unit No. 7 | Lt. Colonel, deputy head of regional fire directorate (1 Apr 1987) | DOC-1986-0019; DOC-1987-0009 |
| S24 | MCP vibration measure | velocity in mm/s (1985 log) | displacement in micrometres (from Jan 1986) | DOC-1985-0018; DOC-1986-0014; DOC-1986-0015 |
| S25 | Dosimetry head V. N. Morozov | Head of Dosimetry Service | Deputy Head, Radiation Safety Department (from 15 Jan 1987) | DOC-1986-0018; DOC-1987-0001 |
