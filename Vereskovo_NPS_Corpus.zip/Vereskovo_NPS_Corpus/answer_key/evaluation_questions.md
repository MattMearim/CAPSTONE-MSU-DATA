# Evaluation questions

134 questions. Answers reflect the state as of December 1987.

| Category | Count |
|---|---|
| Single-document lookup | 12 |
| Multi-document synthesis | 9 |
| Temporal state | 10 |
| Current vs historical | 7 |
| Contradiction resolution | 19 |
| Alias resolution | 14 |
| Aggregation | 12 |
| Causal chain | 9 |
| Gap identification | 12 |
| Provenance | 5 |
| Official vs internal | 5 |
| Unit conversion | 10 |
| Data quality | 8 |
| Cross-entity | 2 |

### Q001 - Single-document lookup (easy)

**Q:** What did the 1983 Technological Regulations require when the ORM fell to 15 rods?

**A:** Immediate shutdown of the reactor (p. 41).

*Supporting:* DOC-1983-0001

### Q002 - Single-document lookup (easy)

**Q:** How long did the Unit 4 diesel generators take to accept load in the April 1985 test?

**A:** 58-65 s (DG-1 58 s, DG-2 65 s, DG-3 61 s); rated speed in 13-15 s.

*Supporting:* DOC-1985-0004

### Q003 - Single-document lookup (easy)

**Q:** After how many seconds did the generator voltage collapse in the September 1985 rundown test on Unit 3?

**A:** 32 s.

*Supporting:* DOC-1985-0010

### Q004 - Single-document lookup (easy)

**Q:** Which three people opened bubbler pool drain valve 12, and when?

**A:** A. Shapoval, K. Babenko and I. Yakovenko, on 25 May 1986 at 14:30.

*Supporting:* DOC-1986-0062

### Q005 - Single-document lookup (easy)

**Q:** What was the text of the official statement of 19 May 1986 about the damaged reactor?

**A:** An accident occurred at Vereskovo NPS; one reactor was damaged; measures are being taken; aid is given; a government commission was set up.

*Supporting:* DOC-1986-0042

### Q006 - Single-document lookup (easy)

**Q:** What were the sentences handed down on 29 July 1987?

**A:** Hrytsenko 10, Savchenko 10, Zuev 10, G. A. Morozov 5, Sidorenko 3, Fedorov 2 years.

*Supporting:* DOC-1987-0022

### Q007 - Single-document lookup (easy)

**Q:** What dose was the max for military and civilian participants in 1986?

**A:** 25 rem (0.25 Sv) as a single exposure for the period of work.

*Supporting:* DOC-1986-0058

### Q008 - Single-document lookup (easy)

**Q:** Where was the high-range VR-1000 No. 0012 kept before the accident and when did it reach Unit 4?

**A:** In the safe of the Unit 1 dosimetry room; the key was at the dosimetry engineer's home; safe opened 03:40; instrument at Unit 4 at 03:50 on 17 May.

*Supporting:* DOC-1986-0018; DOC-1985-0007

### Q009 - Single-document lookup (easy)

**Q:** What did Academician Nikitin observe during the helicopter flight on 18 May?

**A:** Building destroyed above +35, upper plate tilted, core open, glow (burning graphite), graphite and fuel on roofs, 500 R/h at 200 m.

*Supporting:* DOC-1986-0038

### Q010 - Single-document lookup (easy)

**Q:** What is the estimated design life of the Shelter per the July 1987 assessment?

**A:** 20-30 years.

*Supporting:* DOC-1987-0020

### Q011 - Single-document lookup (easy)

**Q:** Who led the clearing of the Unit 3 roof and how many servicemen took part?

**A:** Capt. O. Panchenko; about 3,400 servicemen, 20 Sep - 1 Oct 1986.

*Supporting:* DOC-1986-0110; DOC-1986-0105

### Q012 - Single-document lookup (easy)

**Q:** When was the separation wall between Unit 3 and Unit 4 completed?

**A:** 30 July 1986.

*Supporting:* DOC-1986-0117

### Q013 - Multi-document synthesis (hard)

**Q:** Give the full maintenance history of U4-MCP-03 from 1984 to the accident.

**A:** Feb 1984 seal inspection; vibration rose from ~Jul 1985, above 7.1 mm/s (Sep balancing; Oct load limited); bearing housing batch 82-07 defect acknowledged by Severny (Jul 1985); bearing replaced 18-25 Nov 1985 (WP-85-1146) with improved type, 2.7 mm/s after; stable Jan-May 1986 (measured in um); running on the night; cavitation hypothesis examined and rejected; destroyed.

*Supporting:* DOC-1985-0014; DOC-1985-0013; DOC-1985-0008; DOC-1985-0018; DOC-1986-0014; DOC-1986-0015; DOC-1986-0048; DOC-1986-0091

### Q014 - Multi-document synthesis (hard)

**Q:** Reconstruct the sequence from the start of the power reduction to the explosions.

**A:** 15 May 23:00 start; 16 May 13:05 TG-7 off at 1,600 MW; 14:00 ECCS isolated, dispatcher hold; 23:10 resumed; 00:00 shift change; 00:28 drop to ~30 MW; 01:03 ~200 MW; 01:05 MCP-4 & -8 started; 01:22:30 ORM ~7; 01:23 trips blocked; 01:31:05 TG-8 valves closed; 01:31:41 AZ-5; 01:31:44 surge; ~01:31:45 and ~01:31:48 explosions.

*Supporting:* DOC-1986-0031; DOC-1986-0022; DOC-1986-0030; DOC-1986-0091; DOC-1987-0032

### Q015 - Multi-document synthesis (medium)

**Q:** What happened to the Unit 4 night shift (Shift 5) staff?

**A:** Tkachuk d. 2 Jun 1986; Lavrinenko d. 31 May; Kalinin d. 14 Jun; Melnyk ARS III, survived, retired on disability 31 Mar 1987; Ostapenko missing, declared dead 12 Aug 1986; Babych ARS I survived; Yakovenko opened valve 12, working.

*Supporting:* DOC-1986-0009; DOC-1986-0077; DOC-1986-0125; DOC-1987-0008; DOC-1986-0095; DOC-1986-0062

### Q016 - Multi-document synthesis (hard)

**Q:** Describe the efforts to deal with water and heat under the reactor in May-July 1986.

**A:** Fear of steam explosion; bubbler pool drained 25-26 May (valve 12, ~3,050 m3 pumped by PS-115F); nitrogen injection from 24 May (70 t); foundation temperature peaked ~271 C 28 May then fell; tunnel 136 m by miners (4 Jun-2 Jul) and heat-exchanger slab installed 2 Jul, never activated.

*Supporting:* DOC-1986-0060; DOC-1986-0062; DOC-1986-0063; DOC-1986-0084; DOC-1986-0070; DOC-1986-0086

### Q017 - Multi-document synthesis (medium)

**Q:** Summarize the use of robots on the roofs.

**A:** MRK-2 (NIIKRE) from 22 Aug, low productivity; Varnland R-40 arrived 29 Aug, failed 6 Sep (electronics, >1,000 R/h); MRK-2 unit 01 fell 19 Sep; soldiers cleared zones L and M 20 Sep-1 Oct; replacement MRK-2 (factory 0007) registered as ROB-MRK2-01 on 3 Oct.

*Supporting:* DOC-1986-0100; DOC-1986-0102; DOC-1986-0104; DOC-1986-0105; DOC-1986-0110; DOC-1986-0111

### Q018 - Multi-document synthesis (medium)

**Q:** What changes were made to the RBMK-type units after the accident?

**A:** Min ORM 30 rods, continuous ORM display, ban below 700 MW, 80 additional absorbers, 2.4% fuel, modified rods (no water column), EPS 12 s, no blocking of trips; restart limit 3,000 MWt.

*Supporting:* DOC-1986-0097; DOC-1986-0107; DOC-1987-0003

### Q019 - Multi-document synthesis (hard)

**Q:** Trace the history of the warning about the control-rod effect.

**A:** Observed Dnestrovsk 1983 (report not in corpus); NIIKRE memo 14 Oct 1985 (Yarosh) to OKB-Kanal and 3 stations incl. V-NPS; Levchenko reply 12 Nov 1985: 0.2-0.3 beta, no instructions; commission 1986 mentions design features only secondarily; memo raised at trial (17 Jul 1987), judge ruled design irrelevant; press Sep 1987; GNI revised analysis Nov 1987 makes it a decisive cause; OKB-Kanal disputes.

*Supporting:* DOC-1985-0011; DOC-1985-0012; DOC-1986-0091; DOC-1987-0021; DOC-1987-0024; DOC-1987-0032; DOC-1987-0035

### Q020 - Multi-document synthesis (medium)

**Q:** Who were the defendants and what were their positions on 17 May 1986?

**A:** Hrytsenko (director), Savchenko (chief engineer), Zuev (deputy chief engineer Units 3-4, led test), G. A. Morozov (station shift supervisor), Sidorenko (head reactor shop No. 2), Fedorov (resident GNI inspector, on leave 5-25 May).

*Supporting:* DOC-1986-0096; DOC-1987-0015; DOC-1986-0010

### Q021 - Multi-document synthesis (hard)

**Q:** What were the Shelter's design, construction and condition by mid-1987?

**A:** Variant 'cascade wall + girder' (30 Jun 1986); SU-219 formed 10 Jun; girder B1 installed 28 Oct; closed 9 Dec, accepted 14 Dec 1986; ~394,000 m3 concrete, ~9,500 t steel; sealing done 26 Feb 1987 except axes 46-50; Jul 1987: west wall unknown, openings 100-1,000 m2, fuel location uncertain, 24/32 sensors, life 20-30 y.

*Supporting:* DOC-1986-0082; DOC-1986-0074; DOC-1986-0122; DOC-1986-0120; DOC-1986-0121; DOC-1987-0004; DOC-1987-0020

### Q022 - Temporal state (medium)

**Q:** Who was in charge of Vereskovo NPS (performing the director's duties) on 15 July 1986?

**A:** S. L. Bondar, deputy director, temporarily performing the duties of director (2-28 Jul 1986).

*Supporting:* DOC-1986-0085; DOC-1986-0092

### Q023 - Temporal state (medium)

**Q:** Who was chief engineer of the station in August 1986?

**A:** P. A. Orlov as acting chief engineer (from 9 Jun; confirmed 6 Oct 1986).

*Supporting:* DOC-1986-0072; DOC-1986-0112

### Q024 - Temporal state (medium)

**Q:** Who chaired the Government Commission on 10 June 1986?

**A:** V. A. Demidov (from 3 Jun 1986).

*Supporting:* DOC-1986-0069

### Q025 - Temporal state (easy)

**Q:** Who was the station director in June 1986?

**A:** V. S. Hrytsenko (still director until 2 Jul 1986, although the Government Commission directed the work).

*Supporting:* DOC-1986-0085

### Q026 - Temporal state (medium)

**Q:** What was the dose limit for a seconded worker at the station on 20 January 1987?

**A:** Ministry limit was 10 rem/year from 1 Jan 1987, but the station order kept the 25-rem limit for persons whose 1986 cards were not closed until 1 Feb 1987 - answer depends on whether the card was closed.

*Supporting:* DOC-1986-0118; DOC-1987-0001

### Q027 - Temporal state (easy)

**Q:** What was the head of the cadres department's surname in December 1986?

**A:** Kuzmina (V. S. Kuzmina); became Osipova on 14 Feb 1987.

*Supporting:* DOC-1986-0088; DOC-1987-0002

### Q028 - Temporal state (medium)

**Q:** Which units of the station were operating in January 1987?

**A:** Units 1 and 2 (restarted 1 Oct and 5 Nov 1986); Unit 3 shut down until 4 Dec 1987; Unit 4 = Shelter.

*Supporting:* DOC-1986-0108; DOC-1986-0116; DOC-1987-0033; DOC-1988-0001

### Q029 - Temporal state (medium)

**Q:** What was the zone status of Ruda Vereskivska in September 1986 and in December 1987?

**A:** Sep 1986: strict control zone (from 1 Aug 1986), not evacuated. Dec 1987: still strict control zone with voluntary resettlement since 1 Sep 1987.

*Supporting:* DOC-1987-0028; DOC-1987-0027

### Q030 - Temporal state (easy)

**Q:** What position did L. T. Golub hold in May 1987?

**A:** Lt. Colonel, deputy head of the regional fire directorate (from 1 Apr 1987).

*Supporting:* DOC-1987-0009

### Q031 - Temporal state (medium)

**Q:** Who was Unit 4 shift supervisor on the evening shift of 16 May 1986?

**A:** I. Romanov (Shift 4), with SIUR M. Kalnysh.

*Supporting:* DOC-1986-0006; DOC-1986-0022

### Q032 - Current vs historical (hard)

**Q:** What is the current (Dec 1987) official position on the cause, and what did the 1986 report say?

**A:** 1986 commission and court: operator violations (six listed) main cause. Nov 1987 GNI working group: design deficiencies (positive void coefficient ~+4.5 beta, rod tip effect, no continuous ORM display) decisive in combination with personnel actions; several 'violations' were not prohibited. OKB-Kanal disputes (Dec 1987) - so contested; the most recent regulator analysis is the GNI report.

*Supporting:* DOC-1986-0091; DOC-1987-0022; DOC-1987-0032; DOC-1987-0035

### Q033 - Current vs historical (medium)

**Q:** What is the current ORM requirement for Units 1-3 and how did it change?

**A:** Not less than 30 rods, shutdown below 30, shown continuously (1986 revision); previously 15 rods (1983 regulations), with ORM given every 5-10 min.

*Supporting:* DOC-1983-0001; DOC-1986-0097; DOC-1987-0003

### Q034 - Current vs historical (medium)

**Q:** What is the current status of the Units 5-6 project?

**A:** Terminated 31 Oct 1987 (suspended 18 Jun 1986); directorate dissolved; ~0.62 billion rubles written off; staff to Lisogorsk.

*Supporting:* DOC-1987-0029; DOC-1986-0076; DOC-1987-0026

### Q035 - Current vs historical (easy)

**Q:** What is ROB-MRK2-01 today?

**A:** The replacement MRK-2 robot (factory No. 0007), registered under the ID of the robot that fell from the roof on 19 Sep 1986.

*Supporting:* DOC-1986-0104; DOC-1986-0111

### Q036 - Current vs historical (medium)

**Q:** Where do station staff live now, and what was promised in May 1986?

**A:** Rotation camp Berezovy Gai (15 days on/off); new town Lisogorsk under construction from Oct 1987. In May 1986 residents were told the evacuation was temporary (3 days).

*Supporting:* DOC-1986-0033; DOC-1986-0078; DOC-1987-0026

### Q037 - Current vs historical (medium)

**Q:** What is the current registry number format for liquidators and how does it relate to 1986 cards?

**A:** VR87-RR-NNNNN since 1 Mar 1987; 1986 L86-###### numbers kept as 'previous number'; 118,600 cards -> 104,300 records.

*Supporting:* DOC-1987-0005; DOC-1987-0011; DOC-1987-0012

### Q038 - Current vs historical (medium)

**Q:** What is the current number of monitoring sensors working in the Shelter, compared with earlier reports?

**A:** 24 of 32 (Jul 1987); 21 of 32 in Feb 1987.

*Supporting:* DOC-1987-0004; DOC-1987-0020

### Q039 - Contradiction resolution (medium)

**Q:** At what time did the explosion occur, and why do sources differ?

**A:** About 01:31:45 and 01:31:48 (two explosions). Log '01:32' is rounded; trial testimony approximate; Vega and seismic agree.

*Supporting:* DOC-1986-0022; DOC-1986-0031; DOC-1987-0032; DOC-1987-0019

### Q040 - Contradiction resolution (medium)

**Q:** What was the ORM just before the test?

**A:** About 7 rods (7.2 at 01:22:30), not 15-20 as Zuev stated.

*Supporting:* DOC-1986-0031; DOC-1986-0027; DOC-1986-0091

### Q041 - Contradiction resolution (medium)

**Q:** How many people died as a result of the accident by end-1986?

**A:** 32 by internal records (official 31, omitting a Kyiv hospital death).

*Supporting:* DOC-1986-0124; DOC-1986-0098

### Q042 - Contradiction resolution (easy)

**Q:** On what date was Hrytsenko dismissed?

**A:** 2 July 1986 (order No. 314-k); 30 June on the cadres card and 'end of June' in the press are wrong.

*Supporting:* DOC-1986-0085; DOC-1986-0088; DOC-1986-0087

### Q043 - Contradiction resolution (easy)

**Q:** When did Belov become director?

**A:** 15 Sep 1986 (acting from 28 Jul); his letter's 1 Sep is wrong.

*Supporting:* DOC-1986-0103; DOC-1986-0115

### Q044 - Contradiction resolution (medium)

**Q:** How many buses evacuated Vereskovsk?

**A:** 1,216 (dispatch record / Karpenko); 1,100 was the plan.

*Supporting:* DOC-1986-0046; DOC-1986-0041; DOC-1985-0002

### Q045 - Contradiction resolution (medium)

**Q:** When did Unit 3 restart, given the press says November 1987?

**A:** 4 Dec 1987, 06:40 (telegram, log).

*Supporting:* DOC-1987-0033; DOC-1987-0036; DOC-1987-0038

### Q046 - Contradiction resolution (hard)

**Q:** Was the Shelter completed 'ahead of schedule' as the press said?

**A:** No: original target Oct 1986; closed 9 Dec, accepted 14 Dec 1986, sealing to Feb 1987.

*Supporting:* DOC-1986-0123; DOC-1986-0074; DOC-1986-0121; DOC-1986-0120

### Q047 - Contradiction resolution (medium)

**Q:** What dose did Lt. Rudenko receive?

**A:** 8.6 Gy (biodosimetry, Clinic No. 4); 15 Gy in the award submission and >4 Gy initial estimate are not authoritative.

*Supporting:* DOC-1986-0125; DOC-1986-0106

### Q048 - Contradiction resolution (hard)

**Q:** Who decided to continue the test after the power drop?

**A:** Not determinable: log has no name; Zuev blames Tkachuk (deceased); Melnyk says Zuev insisted; Babych says nobody explicitly decided.

*Supporting:* DOC-1986-0101; DOC-1986-0053; DOC-1987-0031; DOC-1986-0022

### Q049 - Contradiction resolution (hard)

**Q:** Was AZ-5 pressed as a routine end of test or in reaction to a power rise?

**A:** Not established (GNI 1987 states this); testimony conflicts.

*Supporting:* DOC-1986-0101; DOC-1986-0053; DOC-1987-0031; DOC-1987-0032

### Q050 - Contradiction resolution (hard)

**Q:** How high did the power go?

**A:** Unknown: commission ~100x nominal, Varnland at least ~10x, GNI 1987 says cannot be determined.

*Supporting:* DOC-1986-0091; DOC-1986-0099; DOC-1987-0032

### Q051 - Contradiction resolution (medium)

**Q:** How many tests of the turbine rundown were done before 1986?

**A:** Three (1982, 1984, 1985) per commission; Zuev said two.

*Supporting:* DOC-1986-0091; DOC-1986-0101; DOC-1987-0019

### Q052 - Contradiction resolution (medium)

**Q:** When was Unit 4 commissioned?

**A:** Grid connection 22 Dec 1983 (first criticality Dec 1983); commercial operation 30 Mar 1984.

*Supporting:* DOC-1985-0001; DOC-1985-0005

### Q053 - Contradiction resolution (medium)

**Q:** What figure did the director's telegram give for dose rate on site?

**A:** 1,100 uR/s in the original (03:45); 1,000 in the 04:20 retransmission and in the commission minutes.

*Supporting:* DOC-1986-0024; DOC-1986-0025; DOC-1986-0017

### Q054 - Contradiction resolution (medium)

**Q:** When was the fire put out?

**A:** Roof fires: localized 02:20, extinguished 05:00, last hot spots 06:35 on 17 May. Graphite fire in the reactor: about 29 May.

*Supporting:* DOC-1986-0019; DOC-1986-0029; DOC-1986-0066; DOC-1986-0050

### Q055 - Contradiction resolution (medium)

**Q:** How many patients went to Kyiv?

**A:** 108 (71 + 37), not 95.

*Supporting:* DOC-1986-0051; DOC-1986-0036; DOC-1986-0124

### Q056 - Contradiction resolution (easy)

**Q:** Does the 15-rod ORM limit apply only at nominal power?

**A:** No - 'under all operating conditions' per the regulations.

*Supporting:* DOC-1983-0001; DOC-1986-0101

### Q057 - Contradiction resolution (medium)

**Q:** What is the population of Vereskovsk and why do figures differ?

**A:** 47,800 permanent (1 Jan 1986) + ~2,100 temporary; 44,600 evacuated by bus; 45,000 planning figure; ~49,000 Vienna.

*Supporting:* DOC-1986-0003; DOC-1985-0002; DOC-1986-0041; DOC-1986-0098

### Q058 - Alias resolution (easy)

**Q:** Is 'Gritzenko' in the foreign press the same person as V. S. Hrytsenko and 'Gritsenko'?

**A:** Yes - Ukrainian/Russian/foreign spellings of the director Viktor Semyonovich Hrytsenko (VNPS-00012).

*Supporting:* DOC-1986-0049; DOC-1986-0087

### Q059 - Alias resolution (hard)

**Q:** Who is the 'V. Morozov' who signed reconnaissance report No. 3 of 18 May?

**A:** Major Vasily I. Morozov, commander of the radiation reconnaissance battalion - not Vladimir N. Morozov, head of the station dosimetry service (who signed the 17 May report).

*Supporting:* DOC-1986-0039; DOC-1986-0018

### Q060 - Alias resolution (medium)

**Q:** Who is G. A. Morozov, and is he related to the dosimetry Morozov?

**A:** Grigory A. Morozov, station shift supervisor, convicted (5 years). Different person from V. N. Morozov (dosimetry) and Major V. I. Morozov; no relation documented.

*Supporting:* DOC-1986-0023; DOC-1987-0022

### Q061 - Alias resolution (easy)

**Q:** What is 'the third pump on the left side' / 'the noisy one'?

**A:** U4-MCP-03.

*Supporting:* DOC-1986-0004; DOC-1985-0014

### Q062 - Alias resolution (easy)

**Q:** Are 'Vega-M' and 'VPC-4/II' the same system?

**A:** Yes - the Unit 4 plant computer (station name vs design-institute designation).

*Supporting:* DOC-1985-0005

### Q063 - Alias resolution (easy)

**Q:** Is V. S. Kuzmina the same person as V. S. Osipova?

**A:** Yes - head of cadres department, surname changed on marriage 14 Feb 1987 (VNPS-00088).

*Supporting:* DOC-1987-0002

### Q064 - Alias resolution (easy)

**Q:** Are Melnik and Melnyk the same person?

**A:** Yes - Ivan Stepanovich Melnyk (Russian spelling Melnik), senior turbine control engineer.

*Supporting:* DOC-1986-0009; DOC-1987-0008

### Q065 - Alias resolution (medium)

**Q:** Who is 'M. K.', author of the notes for new SIURs, and who is 'Petro'?

**A:** Most likely Mikhail Kalnysh, Unit 4 SIUR (evening shift); 'Petro' is trainee Petro Babych. Inferred, not stated.

*Supporting:* DOC-1986-0004; DOC-1985-0016

### Q066 - Alias resolution (easy)

**Q:** What is 'the Shelter object' / 'the sarcophagus'?

**A:** The enclosure of destroyed Unit 4 (from 14 Dec 1986).

*Supporting:* DOC-1986-0121; DOC-1986-0123

### Q067 - Alias resolution (easy)

**Q:** Is Spetsatomstroy-3 a different supplier from Spetsmontazh Trust No. 3?

**A:** No - same trust, renamed 1 Mar 1987.

*Supporting:* DOC-1987-0006

### Q068 - Alias resolution (easy)

**Q:** Are Lisove and Lesnoye the same place?

**A:** Yes - the district center (SET-007), Ukrainian/Russian names.

*Supporting:* DOC-1986-0071

### Q069 - Alias resolution (medium)

**Q:** What is 'the Great Girder'?

**A:** Shelter main support girder B1 (SH-BEAM-B1), ~70 m span, ~165 t, installed 28 Oct 1986.

*Supporting:* DOC-1986-0082; DOC-1986-0120

### Q070 - Alias resolution (easy)

**Q:** What is 'the thousand meter'?

**A:** High-range dosimeter VR-1000 (No. 0012 kept in Unit 1 safe).

*Supporting:* DOC-1986-0004; DOC-1985-0007

### Q071 - Alias resolution (medium)

**Q:** Who is 'the Donetsk engineer' in the control room?

**A:** G. P. Kuzmin, Energoteststroy (Donetsk) electrical test engineer.

*Supporting:* DOC-1986-0057; DOC-1985-0010

### Q072 - Aggregation (medium)

**Q:** Total materials dropped by helicopter (correct total)?

**A:** 5,020 t (B4C 40, dolomite 800, sand/clay 1,800, lead 2,380) in 1,057 sorties.

*Supporting:* DOC-1986-0067; DOC-1986-0068

### Q073 - Aggregation (medium)

**Q:** How many people were evacuated in total, including Kozhukhivka?

**A:** 71,130 (official 70,461 as of 10 Jun + 669 from Kozhukhivka).

*Supporting:* DOC-1986-0089; DOC-1986-0073

### Q074 - Aggregation (medium)

**Q:** How many confirmed ARS cases by degree, and how many died?

**A:** 128: I 43, II 43, III 21, IV 21. 30 ARS deaths (IV 20, III 9, II 1).

*Supporting:* DOC-1986-0125; DOC-1986-0124

### Q075 - Aggregation (medium)

**Q:** How much concrete was placed in the Shelter (weekly records total)?

**A:** 394,300 m3.

*Supporting:* DOC-1986-0122; DOC-1986-0121

### Q076 - Aggregation (medium)

**Q:** Total collective dose of Shelter construction, July-December 1986 (weekly records)?

**A:** 366,464 man-rem (from the weekly table).

*Supporting:* DOC-1986-0122

### Q077 - Aggregation (medium)

**Q:** Station headcount on 1 Jan 1986 and 1 Dec 1987?

**A:** 5,943 and 4,111 (payroll; excludes contractors and military).

*Supporting:* DOC-1987-0034

### Q078 - Aggregation (medium)

**Q:** How many entries in the 1987 registry extract record exactly 25.0 rem?

**A:** 9 of 80.

*Supporting:* DOC-1987-0011

### Q079 - Aggregation (medium)

**Q:** Unit 4 gross generation in 1985?

**A:** 6,896.1 GWh (sum of monthly), load factor ~78.7%.

*Supporting:* DOC-1986-0001; DOC-1986-0002

### Q080 - Aggregation (medium)

**Q:** Total sorties flown over Unit 4 (corrected)?

**A:** 1,057 (raw CSV sum 1,175 double-counts 23 May).

*Supporting:* DOC-1986-0067; DOC-1986-0068

### Q081 - Aggregation (medium)

**Q:** How many people were evacuated from villages within 10 km (incl. Verbivka and Ostriv)?

**A:** 5,305.

*Supporting:* DOC-1986-0073; DOC-1986-0089

### Q082 - Aggregation (hard)

**Q:** How many ARS deaths occurred in Clinic No. 4 by 20 June 1986?

**A:** 20.

*Supporting:* DOC-1986-0077; DOC-1986-0125

### Q083 - Aggregation (medium)

**Q:** Total length of the tunnel under Unit 4?

**A:** 136 m.

*Supporting:* DOC-1986-0086

### Q084 - Causal chain (hard)

**Q:** Why was the test run at much lower power than planned?

**A:** Dispatcher held the unit at 1,600 MW for ~9 h, causing xenon buildup; the reduction resumed at 23:10; at 00:28 during regulator transfer power fell to ~30 MW; with xenon the operators could only raise it to ~200 MW by withdrawing rods, which also drove the ORM down.

*Supporting:* DOC-1986-0030; DOC-1986-0022; DOC-1986-0031; DOC-1986-0004; DOC-1987-0019

### Q085 - Causal chain (hard)

**Q:** Why was the radiation danger underestimated in the first hours?

**A:** RKS-4 meters saturated at 4 R/h; the high-range VR-1000 was locked in the Unit 1 safe until 03:50; the director reported 1,100 uR/s (~4 R/h, the scale top) as 'normal'; Zuev believed the reactor intact.

*Supporting:* DOC-1986-0018; DOC-1985-0007; DOC-1986-0024; DOC-1986-0027

### Q086 - Causal chain (hard)

**Q:** What was first suspected as the initiating event, and why was it rejected?

**A:** MCP cavitation (8 pumps, high flow, MCP-3 vibration history) - examined by the working group 20 May; rejected by recorded flows (commission Jul 1986, GNI 1987). Hydrogen explosion also suspected early.

*Supporting:* DOC-1986-0048; DOC-1986-0091; DOC-1987-0032; DOC-1986-0027

### Q087 - Causal chain (medium)

**Q:** Why was the rundown test needed at all?

**A:** Diesel generators took 58-65 s to accept load; rotor rundown energy was meant to bridge 45-60 s for MCPs and feedwater pumps.

*Supporting:* DOC-1985-0004; DOC-1986-0012

### Q088 - Causal chain (hard)

**Q:** How did the Varnland detection lead to the announcement?

**A:** Skarvik portal alarms 07:10 local (05:10 UTC) 19 May; own leak suspected then ruled out by 10:00; fuel nuclides; trajectory to the east; embassy inquiries from 14:00 Moscow time got 'no information'; official statement at 21:00.

*Supporting:* DOC-1986-0044; DOC-1986-0045; DOC-1986-0040; DOC-1986-0042

### Q089 - Causal chain (medium)

**Q:** Why was Unit 3 restart delayed repeatedly?

**A:** Central hall dose rates above norm; separate ventilation untested; GNI required Shelter monitoring completed; recontamination from Shelter roof in July 1987; ventilation accepted with remarks Sep 1987.

*Supporting:* DOC-1987-0007; DOC-1987-0023; DOC-1987-0025

### Q090 - Causal chain (medium)

**Q:** Why is lead now considered a bad choice?

**A:** Only part reached the shaft; high temperatures evaporated lead, adding toxic contamination on site and in Lisove district; release drop attributed mainly to fire exhaustion.

*Supporting:* DOC-1986-0093

### Q091 - Causal chain (hard)

**Q:** Why did Lisove have to be evacuated three weeks after the accident?

**A:** Soil sampling found Cs-137 up to 20-25 Ci/km2 in the NW part; decision No. 14 (6 Jun) -> evacuation 7 Jun.

*Supporting:* DOC-1986-0071; DOC-1986-0080

### Q092 - Causal chain (medium)

**Q:** Why was the Unit 3 roof cleared by soldiers instead of robots?

**A:** R-40 electronics failed 6 Sep in >1,000 R/h; MRK-2 fell from roof 19 Sep; decision No. 41 same day ordered manual clearing.

*Supporting:* DOC-1986-0100; DOC-1986-0104; DOC-1986-0105

### Q093 - Gap identification (medium)

**Q:** What does the Dnestrovsk 1983 start-up test report say?

**A:** Not documented - only referenced in the Yarosh memo.

*Supporting:* DOC-1985-0011

### Q094 - Gap identification (medium)

**Q:** What did the SIUR log say between 00:00 and 01:30?

**A:** Not documented - not recovered.

*Supporting:* DOC-1986-0048; DOC-1986-0091

### Q095 - Gap identification (medium)

**Q:** Who signed the agreement to isolate the ECCS?

**A:** Not documented - the line is blank.

*Supporting:* DOC-1986-0012

### Q096 - Gap identification (easy)

**Q:** What doses did the bus drivers receive during the evacuation?

**A:** Not documented.

*Supporting:* none (not documented)

### Q097 - Gap identification (medium)

**Q:** How much of the dropped material reached the reactor?

**A:** Not determined.

*Supporting:* DOC-1986-0093

### Q098 - Gap identification (medium)

**Q:** What was the final cost of the Shelter?

**A:** Not determined (214 million to 14 Dec 1986; estimate ~240 million).

*Supporting:* DOC-1987-0037; DOC-1986-0121

### Q099 - Gap identification (medium)

**Q:** What is the area of openings in the Shelter?

**A:** Unknown - estimates 100-1,000 m2.

*Supporting:* DOC-1987-0020; DOC-1986-0120

### Q100 - Gap identification (medium)

**Q:** What were the results of the 1984 rundown test?

**A:** Only that it gave a 'similar result' (voltage problem) per ETS-85-206; report ETS-84-117 is not in the corpus.

*Supporting:* DOC-1985-0010

### Q101 - Gap identification (easy)

**Q:** Where are V. Ostapenko's remains?

**A:** Not documented - MCP room under debris.

*Supporting:* DOC-1986-0095

### Q102 - Gap identification (medium)

**Q:** What were the thyroid doses of children in Vereskovsk?

**A:** Not documented ('in progress').

*Supporting:* DOC-1986-0079

### Q103 - Gap identification (medium)

**Q:** Did OKB-Kanal receive the test program?

**A:** Not established - no incoming registration found.

*Supporting:* DOC-1986-0013

### Q104 - Gap identification (easy)

**Q:** Do any documents mention FRIB?

**A:** No.

*Supporting:* none (not documented)

### Q105 - Provenance (medium)

**Q:** Which documents support the ORM value of about 7 rods?

**A:** Vega-M printout (01:22:30, 7.2), Commission report (6-8 rods), trial record (prosecutor ~7), Babych recollection ('seven, eight'), GNI 1987.

*Supporting:* DOC-1986-0031; DOC-1986-0091; DOC-1987-0019; DOC-1987-0031

### Q106 - Provenance (medium)

**Q:** Which documents show the director did not flee?

**A:** Station shift log (02:10 in bunker), telephone log (calls 02:10-09:00), his explanatory note.

*Supporting:* DOC-1986-0023; DOC-1986-0021; DOC-1986-0049

### Q107 - Provenance (medium)

**Q:** Which documents give the 237 hospitalized figure?

**A:** Hospital transfer list (CSV) and medical summary Dec 1986.

*Supporting:* DOC-1986-0051; DOC-1986-0124

### Q108 - Provenance (medium)

**Q:** What is the source for the 5,020 t total of dropped materials?

**A:** Helicopter group summary of 30 May 1986 (corrected); daily CSV.

*Supporting:* DOC-1986-0067; DOC-1986-0068

### Q109 - Provenance (medium)

**Q:** Which documents report the Kyiv ARS death?

**A:** Medical summary Dec 1986; ARS outcomes CSV (note).

*Supporting:* DOC-1986-0124; DOC-1986-0125

### Q110 - Official vs internal (medium)

**Q:** How did the official death toll differ from the internal medical count?

**A:** Official 31; internal 32 (Kyiv case excluded officially).

*Supporting:* DOC-1986-0124; DOC-1986-0098

### Q111 - Official vs internal (medium)

**Q:** What did the regional Party directive of 19 May forbid?

**A:** Publishing dose rates, contamination data and numbers of sick; evacuation to be called temporary precaution.

*Supporting:* DOC-1986-0043

### Q112 - Official vs internal (medium)

**Q:** How did the press describe the fire vs internal documents?

**A:** Press: extinguished within hours. Internal: roof fires out by 05:00 but graphite fire until ~29 May.

*Supporting:* DOC-1986-0050; DOC-1986-0066

### Q113 - Official vs internal (medium)

**Q:** How was the radiation situation described in the 03:45 telegram vs the dosimetry report?

**A:** Telegram: town normal, site up to 1,100 uR/s. Dosimetry: instruments off scale, up to 250 R/h, town 14 mR/h (~700x background).

*Supporting:* DOC-1986-0024; DOC-1986-0018

### Q114 - Official vs internal (hard)

**Q:** What did the 1986 Vienna briefing omit or understate compared with internal records?

**A:** Death toll (31 vs 32); ascribed cause to operators while design issues were known (Yarosh 1985 memo); hospitalized '~200' vs 237.

*Supporting:* DOC-1986-0098; DOC-1986-0124; DOC-1985-0011

### Q115 - Unit conversion (easy)

**Q:** Convert the 1986 dose limit of 25 rem to sieverts.

**A:** 0.25 Sv.

*Supporting:* DOC-1986-0058; DOC-1987-0003

### Q116 - Unit conversion (medium)

**Q:** Convert the telegram's 1,100 micro-roentgen per second to R/h.

**A:** 1,100 x 3.6 = 3,960 mR/h = about 4.0 R/h - the top of the RKS-4 scale.

*Supporting:* DOC-1986-0024; DOC-1987-0003

### Q117 - Unit conversion (medium)

**Q:** Convert 40 Ci/km2 of Cs-137 to kBq/m2.

**A:** 1 Ci/km2 = 37 kBq/m2 -> 1,480 kBq/m2.

*Supporting:* DOC-1987-0003

### Q118 - Unit conversion (medium)

**Q:** Drum separator pressure at 01:22:30 was 60.6 kgf/cm2. What is that in MPa?

**A:** 60.6 x 0.0981 = about 5.94 MPa.

*Supporting:* DOC-1986-0031; DOC-1987-0003

### Q119 - Unit conversion (medium)

**Q:** Express the 17 May release estimate (12 MCi/day) in becquerels per day.

**A:** 12 x 10^6 x 3.7 x 10^10 = 4.4 x 10^17 Bq/day.

*Supporting:* DOC-1986-0094; DOC-1987-0003

### Q120 - Unit conversion (medium)

**Q:** The temporary milk limit was 1.0e-7 Ci/L for I-131. What is that in Bq/L, and how does it compare with the 1987 Cs-137 limit?

**A:** 3,700 Bq/L for I-131 (1986); the 1987 Cs-137 limit is 370 Bq/L.

*Supporting:* DOC-1986-0083; DOC-1987-0017; DOC-1987-0003

### Q121 - Unit conversion (hard)

**Q:** Is the 1985 MCP vibration data (mm/s) comparable with the 1986 data (um)?

**A:** No - velocity vs displacement; different instrument (memo of 12 May 1986).

*Supporting:* DOC-1985-0018; DOC-1986-0015; DOC-1986-0014

### Q122 - Unit conversion (medium)

**Q:** Varnland air data is in UTC. What Moscow time was the first Skarvik detection?

**A:** 05:10 UTC = 09:10 Moscow summer time (UTC+4); 07:10 Varnland local.

*Supporting:* DOC-1986-0064; DOC-1986-0044

### Q123 - Unit conversion (easy)

**Q:** Rudenko's 8.6 Gy - what is that in rad and rem (gamma)?

**A:** 860 rad; approximately 860 rem for gamma.

*Supporting:* DOC-1986-0125; DOC-1987-0003

### Q124 - Unit conversion (medium)

**Q:** Per-pump coolant flow at 01:22:30 vs the 7,000 m3/h limit?

**A:** 56,900 / 8 = about 7,110 m3/h per pump - above the 7,000 limit.

*Supporting:* DOC-1986-0031; DOC-1983-0001

### Q125 - Data quality (medium)

**Q:** Which equipment ID in the vibration log is mistyped?

**A:** U4-MPC-03 (should be U4-MCP-03).

*Supporting:* DOC-1985-0018

### Q126 - Data quality (medium)

**Q:** Which settlement name is misspelled in the soil survey?

**A:** Kozhukivka (Kozhukhivka, SET-013).

*Supporting:* DOC-1986-0080

### Q127 - Data quality (medium)

**Q:** Why might doses of exactly 25.0 rem in the registry be unreliable?

**A:** The registry office suspects administrative entry of the limit value rather than dosimeter readings.

*Supporting:* DOC-1987-0012; DOC-1987-0011

### Q128 - Data quality (medium)

**Q:** Was the rumour that the director fled true?

**A:** No - he was in the station shelter from 02:10.

*Supporting:* DOC-1986-0055; DOC-1986-0021; DOC-1986-0023

### Q129 - Data quality (hard)

**Q:** Could dosimetrist T. Mironenko have signed the bubbler pool act on 27 May 1986?

**A:** Unlikely: he was flown to Clinic No. 4 in Moscow on 17 May (ARS I); the signature is inconsistent with the transfer list.

*Supporting:* DOC-1986-0062; DOC-1986-0051; DOC-1986-0125

### Q130 - Data quality (easy)

**Q:** Was a multi-megaton explosion possible?

**A:** No - Nikitin: physically impossible; the real risk was a steam explosion.

*Supporting:* DOC-1986-0060

### Q131 - Data quality (medium)

**Q:** Why does Rev. 0 of the test program look approved?

**A:** Header says approved, but signature lines are blank; it's a draft superseded by Rev. 1.

*Supporting:* DOC-1986-0007; DOC-1986-0012

### Q132 - Data quality (medium)

**Q:** What changed between Rev. 0 and Rev. 1 of the test program?

**A:** ECCS isolation '~4 hours' -> 'entire duration'; added safety clause; approved by Savchenko 22 Apr 1986; ECCS-agreement line blank.

*Supporting:* DOC-1986-0007; DOC-1986-0012

### Q133 - Cross-entity (medium)

**Q:** Which settlement had the highest Cs-137 soil contamination in June 1986?

**A:** Hlibove (SET-003), 140 Ci/km2.

*Supporting:* DOC-1986-0080

### Q134 - Cross-entity (medium)

**Q:** Which settlements outside the 30-km zone were affected, and how?

**A:** Kozhukhivka evacuated 14 Jun (hotspot 52 Ci/km2); Ruda Vereskivska strict control, voluntary resettlement; Petrivka and Novosilky milk/agri restrictions; Vilshanka added to resettlement Oct 1987.

*Supporting:* DOC-1987-0028; DOC-1987-0027; DOC-1987-0017; DOC-1986-0080

