# Master timeline

Times are local (= Moscow time). Accident-night entries follow the world bible; items marked in the contradiction ledger cannot be established exactly from any single document.

| When | Event | Source doc |
|---|---|---|
| 1983-12-22 | Unit 4 first criticality / grid connection | DOC-1985-0001 |
| 1984-03-30 | Unit 4 commercial operation | DOC-1985-0005 |
| 1985-04-17 | Diesel generator start test (58-65 s) | DOC-1985-0004 |
| 1985-09-19 | Rundown test on Unit 3 - voltage collapse after 32 s | DOC-1985-0010 |
| 1985-10-14 | Yarosh memo on rod-insertion positive reactivity | DOC-1985-0011 |
| 1985-11-12 | Levchenko reply - no instructions | DOC-1985-0012 |
| 1985-11-18/25 | MCP-3 bearing replaced | DOC-1985-0013 |
| 1985-12-10 | GNI act 85-37 | DOC-1985-0015 |
| 1986-03-14 | Test program Rev.0 (draft) | DOC-1986-0007 |
| 1986-04-22 | Test program Rev.1 approved by Savchenko | DOC-1986-0012 |
| 1986-05-15 23:00 | Power reduction of Unit 4 begins from 3,200 MWt for planned outage and TG-8 rundown test. | world bible |
| 1986-05-16 13:05 | Power 1,600 MWt; TG-7 disconnected. | world bible |
| 1986-05-16 14:00 | ECCS (SAOR) disconnected per test program; grid dispatcher (Ostrovsky) requests that Unit 4 keep generating; reduction halted at 1,600 MWt. | world bible |
| 1986-05-16 23:10 | Dispatcher permits reduction; power reduction resumes. | world bible |
| 1986-05-17 00:00 | Shift change: Shift 5 (Tkachuk, Lavrinenko, Kalinin, Melnyk) relieves Shift 4 (Romanov, Kalnysh). | world bible |
| 1986-05-17 00:28 | During transfer from local to global automatic control, power falls to about 30 MWt. | world bible |
| 1986-05-17 00:41 | Rods withdrawn to recover power; decision to continue taken (who decided is disputed). | world bible |
| 1986-05-17 01:03 | Power stabilized at about 200 MWt (planned 700-1,000 MWt). | world bible |
| 1986-05-17 01:05 | Additional MCPs started (U4-MCP-04 and U4-MCP-08); all eight pumps running. | world bible |
| 1986-05-17 01:22:30 | Vega-M printout: operating reactivity margin about 7 rod-equivalents (minimum 15). | world bible |
| 1986-05-17 01:31:05 | Test begins: TG-8 stop valves closed; rundown starts. | world bible |
| 1986-05-17 01:31:41 | AZ-5 (emergency protection) pressed. | world bible |
| 1986-05-17 01:31:44 | Power surge; instruments off scale. | world bible |
| 1986-05-17 01:31:45-48 | Two explosions; reactor and building destroyed; fires on turbine hall and Unit 3 roofs. | world bible |
| 1986-05-17 01:37 | Fire Unit No. 7 (Rudenko) arrives; Fire Unit No. 9 (Petrenko) arrives 01:42. | world bible |
| 1986-05-17 02:20 | Roof fires localized. | world bible |
| 1986-05-17 03:45 | Director's telegram to Goskomatom: reactor being cooled; radiation in town normal. | world bible |
| 1986-05-17 03:50 | VR-1000 high-range meter brought from Unit 1 safe; readings up to 200+ R/h near Unit 4; off scale near debris. | world bible |
| 1986-05-17 05:00 | Roof fires extinguished. | world bible |
| 1986-05-17 05:15 | Unit 3 shut down (Nazarenko). | world bible |
| 1986-05-17 06:00 | Shevchuk dies at MSU-41; Ostapenko missing | DOC-1986-0020 |
| 1986-05-17 20:40 | Government Commission (Zaitsev) arrives in Lisove. | world bible |
| 1986-05-17 21:30 | 129 patients flown to Moscow | DOC-1986-0051 |
| 1986-05-18 07:30 | Nikitin helicopter reconnaissance - reactor destroyed | DOC-1986-0038 |
| 1986-05-18 09:30 | Decision No. 2 - evacuate town | DOC-1986-0032 |
| 1986-05-18 13:10 | Evacuation announced on Vereskovsk radio; buses depart 14:00-16:40. | world bible |
| 1986-05-18 13:10-16:40 | Town evacuated (44,600; 1,216 buses) | DOC-1986-0037 |
| 1986-05-18 19:00 | First helicopter drops | DOC-1986-0068 |
| 1986-05-18 to 05-28 | Helicopter drops: approx. 5,020 t of materials. | world bible |
| 1986-05-19 | Ostriv evacuated | DOC-1986-0056 |
| 1986-05-19 09:10 | Skarvik plant (Varnland) detects contamination on workers' shoes (07:10 Varnland local time = 05:10 UTC; Moscow summer time = UTC+4). | world bible |
| 1986-05-19 21:00 | Terse official statement broadcast. | world bible |
| 1986-05-19 21:00 | Official statement | DOC-1986-0042 |
| 1986-05-21 | 10-km zone villages evacuated. | world bible |
| 1986-05-21 | 10-km villages evacuated | DOC-1986-0056 |
| 1986-05-22 | Dose limit 25 rem | DOC-1986-0058 |
| 1986-05-23 | 30-km zone established. | world bible |
| 1986-05-23 | 30-km zone | DOC-1986-0059 |
| 1986-05-25 14:30 | Valve 12 opened; pool drained 26 May 15:00 | DOC-1986-0062 |
| 1986-05-25/26 | Bubbler pool drained (valve 12 opened by Shapoval, Babenko, Yakovenko 25 May; pumping completed 26 May). | world bible |
| 1986-05-29 | Graphite fire judged extinguished / release falls sharply. | world bible |
| 1986-05-29 | Graphite fire considered extinguished | DOC-1986-0066 |
| 1986-06-03 | Demidov replaces Zaitsev; tunnel decision | DOC-1986-0069 |
| 1986-06-07 | Lisove evacuated | DOC-1986-0071 |
| 1986-06-09 | Savchenko out; Orlov acting chief engineer | DOC-1986-0072 |
| 1986-06-10 | SU-219 formed; evacuation total 70,461 | DOC-1986-0074 |
| 1986-06-14 | Kozhukhivka evacuated | DOC-1987-0028 |
| 1986-06-18 | Units 5-6 suspended | DOC-1986-0076 |
| 1986-07-02 | Hrytsenko dismissed; Bondar temporarily director; tunnel slab installed | DOC-1986-0085 |
| 1986-07-09 | ARS death in Kyiv hospital | DOC-1986-0125 |
| 1986-07-20 | Commission report on causes | DOC-1986-0091 |
| 1986-07-28 | Belov acting director | DOC-1986-0092 |
| 1986-08-12 | Ostapenko declared dead | DOC-1986-0095 |
| 1986-08-13/14 | Arrests | DOC-1986-0096 |
| 1986-08-20 | 1986 regulations revision (ORM 30) | DOC-1986-0097 |
| 1986-08-25/29 | Vienna INSF briefing | DOC-1986-0098 |
| 1986-09-06 | R-40 robot fails | DOC-1986-0100 |
| 1986-09-15 | Belov director | DOC-1986-0103 |
| 1986-09-19 | MRK-2 falls; manual roof clearing ordered | DOC-1986-0104 |
| 1986-09-20 - 10-01 | Roof clearing by ~3,400 servicemen | DOC-1986-0110 |
| 1986-10-01 03:15 | Unit 1 restart (grid 4 Oct) | DOC-1986-0108 |
| 1986-10-03 | Replacement robot registered as ROB-MRK2-01 | DOC-1986-0111 |
| 1986-10-06 | Orlov chief engineer | DOC-1986-0112 |
| 1986-10-28 | Girder B1 installed | DOC-1986-0120 |
| 1986-11-05 | Unit 2 restart | DOC-1986-0116 |
| 1986-12-09 | Shelter physically closed | DOC-1986-0120 |
| 1986-12-14 | Shelter accepted | DOC-1986-0121 |
| 1987-01-01 | 10 rem/year limit (station 1 Feb) | DOC-1986-0118 |
| 1987-02-14 | Kuzmina -> Osipova | DOC-1987-0002 |
| 1987-02-26 | Shelter sealing done | DOC-1987-0004 |
| 1987-03-01 | VR87 registry; Spetsatomstroy-3 rename | DOC-1987-0005 |
| 1987-03-31 | Melnyk retires | DOC-1987-0008 |
| 1987-07-06 - 07-29 | Trial in Lisove; verdict 29 Jul | DOC-1987-0022 |
| 1987-07-15 | Shelter engineering assessment | DOC-1987-0020 |
| 1987-09-01 | Ruda Vereskivska voluntary resettlement | DOC-1987-0027 |
| 1987-10-05 | Lisogorsk construction begins | DOC-1987-0026 |
| 1987-10-15 | Vilshanka added to resettlement | DOC-1987-0027 |
| 1987-10-31 | Units 5-6 terminated | DOC-1987-0029 |
| 1987-11-20 | GNI revised analysis | DOC-1987-0032 |
| 1987-12-04 06:40 | Unit 3 restart | DOC-1987-0033 |
| 1987-12-10 | OKB-Kanal disputes revised analysis | DOC-1987-0035 |
