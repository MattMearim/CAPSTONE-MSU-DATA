# Alias ledger

| Canonical | Type | Aliases / variants |
|---|---|---|
| Viktor Semyonovich Hrytsenko (P01) | person | Viktor Gritsenko, V. S. Hrytsenko, Gritsenko V.S., the Director, Gritzenko |
| Nikolai Ivanovich Savchenko (P02) | person | N. I. Savchenko, Mykola Savchenko, the chief engineer |
| Anatoly Grigorievich Zuev (P03) | person | A. G. Zuev, Zuyev, Anatolii Zuiev, Grigorich |
| Pavel Andreyevich Orlov (P04) | person | P. A. Orlov, Orlov P. |
| Mikhail Yurievich Belov (P05) | person | M. Yu. Belov, M. Belov, Mykhailo Bilov |
| Stepan Lukich Bondar (P06) | person | S. L. Bondar, Bondar S.L., Lukich |
| Yuri Mikhailovich Tkachuk (P07) | person | Yu. M. Tkachuk, Yurii Tkachuk, Yura |
| Andrei Viktorovich Lavrinenko (P08) | person | A. V. Lavrinenko, Andriy Lavrynenko, Andrei L. |
| Boris Fedorovich Kalinin (P09) | person | B. F. Kalinin, Kalinin B. |
| Ivan Stepanovich Melnyk (P10) | person | I. S. Melnik, Ivan Melnik, Melnyk I. |
| Grigory Aleksandrovich Morozov (P11) | person | G. A. Morozov, Hryhorii Moroz, Morozov G. |
| Vladimir Nikolaevich Morozov (P12) | person | V. N. Morozov, V. Morozov, Volodymyr Morozov |
| Vasily Ivanovich Morozov (P13) | person | Maj. V. Morozov, V. I. Morozov, Major Morozov |
| Oleg Dmitrievich Sidorenko (P14) | person | O. D. Sidorenko, Sydorenko |
| Konstantin Yegorovich Fedorov (P15) | person | K. Ye. Fedorov, Fyodorov, the inspector |
| Valery Ostapenko (P16) | person | V. Ostapenko, Valerii Ostapenko |
| Mykola Shevchuk (P17) | person | Nikolai Shevchuk, N. Shevchuk |
| Gennady Petrovich Kuzmin (P18) | person | G. P. Kuzmin, Hennadii Kuzmin, the Donetsk engineer |
| Dmitry Ivanovich Rudenko (P19) | person | Lt. Rudenko, D. I. Rudenko, Dmytro Rudenko |
| Leonid Tarasovich Golub (P20) | person | Maj. Golub, L. T. Golub, Holub |
| Sergei Petrenko (P21) | person | Lt. Petrenko, Serhii Petrenko, S. Petrenko |
| Volodymyr Chumak (P22) | person | Vladimir Chumak, Sgt. Chumak |
| Pyotr Usenko (P23) | person | Petro Usenko, Sgt. Usenko |
| Mykhailo Tsybulko (P24) | person | Mikhail Tsybulko, Sr. Sgt. Tsybulko |
| Lyudmila Pavlovna Gerasimova (P25) | person | Dr. Gerasimova, L. P. Gerasimova, Liudmyla Herasymova |
| Arkady Semyonovich Volkov (P26) | person | Prof. Volkov, A. S. Volkov |
| Gennady Ivanovich Zaitsev (P27) | person | G. I. Zaitsev, the commission chairman, Zaytsev |
| Viktor Arkadievich Demidov (P28) | person | V. A. Demidov |
| Yevgeny Borisovich Nikitin (P29) | person | Academician Nikitin, Ye. B. Nikitin, E. Nikitin |
| Aleksandr Ivanovich Karpenko (P30) | person | Col. Karpenko, O. I. Karpenko, Oleksandr Karpenko |
| Nadezhda Fyodorovna Makarenko (P31) | person | N. F. Makarenko, Nadiia Makarenko |
| Ivan Ivanovich Gordienko (P32) | person | I. I. Gordienko, Hordiienko |
| Irina Viktorovna Yarosh (P33) | person | I. V. Yarosh, Iryna Yarosh, Dr. Yarosh |
| Boris Kirillovich Levchenko (P34) | person | B. K. Levchenko, the chief designer |
| Aleksei Grigorievich Polishchuk (P35) | person | A. G. Polishchuk, Oleksii Polishchuk, the deputy chairman |
| Yevhen Nazarenko (P36) | person | Yevgeny Nazarenko, Ye. Nazarenko, Zhenya |
| Pavel Lukin (P37) | person | P. Lukin, Pavlo Lukin |
| Taras Mironenko (P38) | person | T. Myronenko, Taras Myronenko |
| Valentina Sergeyevna Osipova (P39) | person | V. S. Kuzmina, Valentina Kuzmina, V. Osipova |
| Ilya Konstantinovich Antonov (P40) | person | I. K. Antonov, the Chairman |
| Arkady Danilchenko (P41) | person | A. Danilchenko, Arkadii Danylchenko |
| Rostislav Kirillovich Demchenko (P42) | person | R. K. Demchenko |
| Larisa Pavlyuk (P43) | person | Larysa Pavliuk, L. Pavlyuk |
| Igor Stepanovich Golovko (P44) | person | I. S. Golovko, Ihor Holovko |
| Vadim Pavlovich Rybak (P45) | person | V. P. Rybak, Vadym Rybak |
| Mykola Prokopenko (P46) | person | Nikolai Prokopenko, N. Prokopenko |
| Vasily Klimenko (P47) | person | V. Klimenko, Vasyl Klymenko |
| Sergei Ivanovich Tarasov (P48) | person | S. I. Tarasov, Serhii Tarasov |
| Igor Romanov (P49) | person | I. Romanov, Ihor Romanov |
| Mikhail Kalnysh (P50) | person | M. Kalnysh, Mykhailo Kalnysh |
| Andriy Shapoval (P51) | person | Andrei Shapoval, A. Shapoval |
| Konstantin Babenko (P52) | person | K. Babenko, Kostia |
| Ihor Yakovenko (P53) | person | Igor Yakovenko, I. Yakovenko |
| Oleg Panchenko (P54) | person | Capt. Panchenko, O. Panchenko |
| Ruslan Trofimov (P55) | person | Pvt. Trofimov, R. Trofimov |
| Valentin Kharchenko (P56) | person | Col. Kharchenko, V. Kharchenko |
| Stanislav Ryabov (P57) | person | S. Ryabov, Stas |
| Gleb Arturovich Aksyonov (P58) | person | G. A. Aksyonov, Aksenov |
| Viktor Chernov (P59) | person | V. Chernov, Chernov V. |
| Henrik Aspelund (P60) | person | H. Aspelund, Mr. Aspelund |
| Maren Holt (P61) | person | Dr. Holt, M. Holt |
| Lars Ekvall (P62) | person | L. Ekvall |
| Per Dahlstrand (P63) | person | Counsellor Dahlstrand |
| Yuri Filatov (P64) | person | Yu. Filatov, Yurii Filatov |
| Galina Yakubovich (P65) | person | G. Yakubovich, Halyna Yakubovych |
| A. Ostrovsky (P66) | person | dispatcher Ostrovsky |
| Petro Babych (P67) | person | Pyotr Babich, P. Babych |
| Anatolii Lytvyn (P71) | person | Capt. A. Lytvyn, Anatoly Litvin |
| U4-RCT-01 | equipment | the reactor, the fourth unit reactor, Unit 4 |
| U4-CPS-01 | equipment | SUZ, CPS, the rods |
| U4-EPS-01 | equipment | AZ-5, the AZ button, EP-5, emergency protection |
| U4-MCP-01 | equipment | MCP-1, pump 1 |
| U4-MCP-02 | equipment | MCP-2 |
| U4-MCP-03 | equipment | MCP-3, the third pump on the left side, the noisy one, pump 3 |
| U4-MCP-04 | equipment | MCP-4 |
| U4-MCP-05 | equipment | MCP-5 |
| U4-MCP-06 | equipment | MCP-6 |
| U4-MCP-07 | equipment | MCP-7 |
| U4-MCP-08 | equipment | MCP-8 |
| U4-DS-01 | equipment | DS-1, drum 1 |
| U4-DS-02 | equipment | DS-2 |
| U4-DS-03 | equipment | DS-3 |
| U4-DS-04 | equipment | DS-4 |
| U4-FWP-01 | equipment | FWP-1 |
| U4-TG-07 | equipment | TG-7, turbine 7 |
| U4-TG-08 | equipment | TG-8, turbine 8, the eighth turbine |
| U4-DG-01 | equipment | DG-1 |
| U4-DG-02 | equipment | DG-2 |
| U4-ECCS-01 | equipment | SAOR, ECCS |
| U4-PC-01 | equipment | Vega, the computer, VPC-4/II (design institute designation), Vega-M |
| U4-ICM-01 | equipment | SVK, in-core monitoring |
| U4-BP-01 | equipment | the bubbler pool, the suppression pool, barbotage pool |
| U4-BP-V12 | equipment | valve 12 |
| U34-RFM-01 | equipment | RZM, the refueling machine |
| U34-VS-01 | equipment | the stack, the striped chimney |
| U3-RCT-01 | equipment | Unit 3 |
| U2-RCT-01 | equipment | Unit 2 |
| U1-RCT-01 | equipment | Unit 1 |
| U5-RCT-01 | equipment | Unit 5, the fifth unit |
| CP-PMP-01 | equipment | intake 1 |
| DOS-RKS4 | equipment | the 4-roentgen meters, RKS, the station meters |
| DOS-VR1000-0012 | equipment | the thousand meter, VR-1000, the high-range meter |
| DOS-DK02 | equipment | pencil dosimeters, DK |
| DOS-IMD21 | equipment | IMD, the army meters |
| FE-07-01 | equipment | engine 1/7 |
| FE-07-02 | equipment | the ladder truck |
| FE-07-PNS | equipment | PS truck, the pump truck |
| FE-09-01 | equipment | engine 1/9 |
| HEL-V8T | equipment | V-8, the eights |
| HEL-V26H | equipment | the heavy helicopter, V-26 |
| ROB-MRK2-01 | equipment | MRK-2, the Moscow robot |
| ROB-VR40-01 | equipment | the Varnland robot, R-40 |
| SH-BEAM-B1 | equipment | the Great Girder, B1, the big beam |
| SH-WALL-N | equipment | the cascade wall, the staircase wall |
| SH-SEP-01 | equipment | the dividing wall |
| SH-VENT-01 | equipment | Shelter ventilation |
| TUN-HX-01 | equipment | the cooling slab, the heat exchanger, the tunnel slab |
| LN2-INJ-01 | equipment | the nitrogen line |
| Vereskivsk (SET-001) | settlement | Vereskovsk |
| Ozerne (SET-002) | settlement | Ozernoye |
| Hlibove (SET-003) | settlement | Glebovo |
| Sosnivka (SET-004) | settlement | Sosnovka |
| Dubrova (SET-005) | settlement | Dubrova |
| Verbivka (SET-006) | settlement | Verbovka |
| Lisove (SET-007) | settlement | Lesnoye |
| Zhytnyky (SET-008) | settlement | Zhitniki |
| Kalynivka (SET-009) | settlement | Kalinovka |
| Moshchanka (SET-010) | settlement | Moshchanka |
| Bilyi Brid (SET-011) | settlement | Bely Brod |
| Staryi Hai (SET-012) | settlement | Stary Gai |
| Kozhukhivka (SET-013) | settlement | Kozhukhovka |
| Ruda Vereskivska (SET-014) | settlement | Ruda Vereskovskaya |
| Lypnyky (SET-015) | settlement | Lipniki |
| Horodyshche (SET-016) | settlement | Gorodishche |
| Petrivka (SET-017) | settlement | Petrovka |
| Zarichne (SET-018) | settlement | Zarechnoye |
| Novosilky (SET-019) | settlement | Novoselki |
| Kamianka (SET-020) | settlement | Kamenka |
| Ostriv (SET-021) | settlement | Ostrov |
| Vilshanka (SET-022) | settlement | Olshanka |
| State Committee for Atomic Power (Goskomatom) (ORG-0001) | organization | Goskomatom, the Committee, GKA |
| Republic Energy Directorate (Ukrenergo-R) (ORG-0002) | organization | the Directorate, Ukrenergo-R |
| Institute of Channel Reactor Engineering (NIIKRE) (ORG-0003) | organization | NIIKRE, the Institute, the design institute |
| Chief Designer's Bureau OKB-Kanal (ORG-0004) | organization | OKB-Kanal, the chief designer's bureau |
| State Nuclear Safety Inspectorate (GNI) (ORG-0005) | organization | GNI, Gosinspektsiya, the Inspectorate |
| Institute of Reactor Physics (IRP) (ORG-0006) | organization | IRP |
| Volzhsky Turbine Works (ORG-0007) | organization | VTZ, Volzhsky |
| Severny Pump Plant (ORG-0008) | organization | SNZ, Severny |
| Elektron-Pribor (Kyiv) (ORG-0009) | organization | Elektronpribor, EP-Kyiv |
| Atomnaladka Trust (ORG-0010) | organization | Atomnaladka, ANL |
| Energoteststroy (Donetsk) (ORG-0011) | organization | Energoteststroy, the Donetsk organization, ETS |
| Spetsmontazh Trust No. 3 (renamed Spetsatomstroy-3, Mar 1987) (ORG-0012) | organization | Spetsmontazh-3, Spetsatomstroy-3, Trust No. 3 |
| Construction Directorate SU-219 (ORG-0013) | organization | SU-219, the directorate |
| Uralgrafit Combine (ORG-0014) | organization | Uralgrafit |
| Fuel Assembly Plant No. 12 (ORG-0015) | organization | Plant No. 12, FAP-12 |
| Dniprostroimaterialy (ORG-0016) | organization | DSM |
| Svinets-Tsvetmet lead combine (ORG-0017) | organization | Svinets |
| Varnland Radiation Protection Institute (VRPI) (ORG-0018) | organization | VRPI, the Varnland institute |
| Aspelund Robotik (ORG-0019) | organization | Aspelund, the Varnland firm |
| Central Radiological Clinic No. 4 (ORG-0020) | organization | Clinic No. 4, the Moscow clinic, CRC-4 |
| Medical-Sanitary Unit No. 41 (ORG-0021) | organization | MSU-41, the medical unit, MSCh-41 |
| Republic Grid Dispatch Center (ORG-0022) | organization | grid dispatch, the dispatcher, Kyivenergo dispatch |
| Zarya Polesya (ORG-0023) | organization | Zarya Polesya, Zoria Polissia |
| Sovetsky Vestnik (ORG-0024) | organization | Sov. Vestnik |
| Unit 4 | place | the fourth unit, the Shelter object, Ukrytie-type 'Shelter', the sarcophagus |
| Rundown test | project | coast-down test, TG-8 test, the run-down, voltage-sustaining test |
| Liquidators | term | participants in the work, participants in the elimination of the consequences |
| 'V. Morozov' | AMBIGUOUS | Vladimir N. Morozov (dosimetry, VNPS-00145) on 17 May docs; Major Vasily I. Morozov (EXT-MIL-0213) in 18 May recon report and CSV from 18 May 07:00 |
| 'M. K.' | inferred | Mikhail Kalnysh (P50), author of the undated tribal-knowledge notes (inferred) |
