# Entity registry (state as of 1987-12-31)

Canonical records for all entities. NOT for ingestion.

## People

| ID | Name | Personnel No. | Organization / department | Roles (from - to) | Supervisor | Start | Expertise | Aliases | Status Dec 1987 |
|---|---|---|---|---|---|---|---|---|---|
| P01 | Viktor Semyonovich Hrytsenko | VNPS-00012 | Station management | Station Director (1979-03-01 - 1986-07-02) | P40 | 1970-11-02 | power-plant construction and management (thermal background) | Viktor Gritsenko, V. S. Hrytsenko, Gritsenko V.S., the Director, Gritzenko | Convicted 29 Jul 1987: 10 years |
| P02 | Nikolai Ivanovich Savchenko | VNPS-00031 | Station management | Chief Engineer (1983-12-01 - 1986-06-09) | P01 | 1972-04-17 | electrical engineering | N. I. Savchenko, Mykola Savchenko, the chief engineer | Convicted 29 Jul 1987: 10 years |
| P03 | Anatoly Grigorievich Zuev | VNPS-00057 | Station management | Deputy Chief Engineer for Operation (Units 3-4) (1982-06-01 - 1986-08-14) | P02 | 1973-09-03 | reactor physics, naval reactors before 1973 | A. G. Zuev, Zuyev, Anatolii Zuiev, Grigorich | Convicted 29 Jul 1987: 10 years; ARS (moderate) survivor |
| P04 | Pavel Andreyevich Orlov | VNPS-00058 | Station management | Deputy Chief Engineer for Operation (Units 1-2) (1981-02-01 - 1986-06-09)<br>Acting Chief Engineer (1986-06-09 - 1986-10-06)<br>Chief Engineer (1986-10-06 - present) | P01 | 1974-08-12 | RBMK operation, Units 1-2 | P. A. Orlov, Orlov P. | Working: Chief Engineer |
| P05 | Mikhail Yurievich Belov | VNPS-03311 | Station management | Acting Station Director (1986-07-28 - 1986-09-15)<br>Station Director (1986-09-15 - present) | P40 | 1986-07-28 | came from Dnestrovsk NPS (deputy chief engineer) | M. Yu. Belov, M. Belov, Mykhailo Bilov | Working: Station Director |
| P06 | Stepan Lukich Bondar | VNPS-00019 | Station management | Deputy Director (general matters) (1980-01-10 - present)<br>Deputy Director, temporarily performing the duties of Director (1986-07-02 - 1986-07-28) | P01 | 1971-05-20 | administration, supply | S. L. Bondar, Bondar S.L., Lukich | Working: Deputy Director |
| P07 | Yuri Mikhailovich Tkachuk | VNPS-00412 | Reactor shop / Unit 4 operations | Unit 4 Shift Supervisor (Shift 5) (1984-02-01 - 1986-05-17) | P11 | 1977-08-01 | unit operations | Yu. M. Tkachuk, Yurii Tkachuk, Yura | Deceased 2 Jun 1986 (ARS) |
| P08 | Andrei Viktorovich Lavrinenko | VNPS-00877 | Reactor shop | Senior Reactor Control Engineer (SIUR), Unit 4 (1985-11-15 - 1986-05-17) | P07 | 1983-08-29 | reactor control | A. V. Lavrinenko, Andriy Lavrynenko, Andrei L. | Deceased 31 May 1986 (ARS) |
| P09 | Boris Fedorovich Kalinin | VNPS-00654 | Reactor shop | Senior Unit Control Engineer (SIUB), Unit 4 (1982-03-01 - 1986-05-17) | P07 | 1979-09-10 | unit control, feedwater | B. F. Kalinin, Kalinin B. | Deceased 14 Jun 1986 (ARS) |
| P10 | Ivan Stepanovich Melnyk | VNPS-00702 | Turbine shop | Senior Turbine Control Engineer, Unit 4 (1981-06-01 - 1987-03-31) | P07 | 1978-02-14 | turbine operation | I. S. Melnik, Ivan Melnik, Melnyk I. | Retired on disability 31 Mar 1987; ARS survivor |
| P11 | Grigory Aleksandrovich Morozov | VNPS-00233 | Station shift | Station Shift Supervisor (1983-05-01 - 1986-08-14) | P02 | 1975-03-11 | station operations | G. A. Morozov, Hryhorii Moroz, Morozov G. | Convicted 29 Jul 1987: 5 years |
| P12 | Vladimir Nikolaevich Morozov | VNPS-00145 | Radiation safety / dosimetry service | Head of Dosimetry Service (1980-09-01 - 1987-01-15)<br>Deputy Head, Radiation Safety Department (1987-01-15 - present) | P04 | 1976-06-21 | health physics | V. N. Morozov, V. Morozov, Volodymyr Morozov | Working |
| P13 | Vasily Ivanovich Morozov | EXT-MIL-0213 | Civil defense chemical regiment (military) | Commander, radiation reconnaissance battalion (at V-NPS) (1986-05-18 - 1986-09-30) | P30 | 1986-05-18 | military radiation reconnaissance | Maj. V. Morozov, V. I. Morozov, Major Morozov | Transferred back to unit, Oct 1986 |
| P14 | Oleg Dmitrievich Sidorenko | VNPS-00160 | Reactor shop (Units 3-4) | Head of Reactor Shop No. 2 (Units 3-4) (1983-01-10 - 1986-08-14) | P03 | 1974-12-02 | reactor maintenance | O. D. Sidorenko, Sydorenko | Convicted 29 Jul 1987: 3 years |
| P15 | Konstantin Yegorovich Fedorov | EXT-GNI-0007 | State Nuclear Safety Inspectorate (GNI) | Resident State Inspector at V-NPS (1984-01-01 - 1986-08-14) | P42 | 1984-01-01 | nuclear regulation | K. Ye. Fedorov, Fyodorov, the inspector | Convicted 29 Jul 1987: 2 years |
| P16 | Valery Ostapenko | VNPS-01102 | Reactor shop | Main Circulation Pump Operator, Unit 4 (1984-07-01 - 1986-05-17) | P07 | 1984-07-01 | pump operation | V. Ostapenko, Valerii Ostapenko | Missing 17 May 1986; declared dead 12 Aug 1986 |
| P17 | Mykola Shevchuk | EXT-ANL-0044 | Atomnaladka Trust (contractor) | Automation Adjuster (contractor) (1985-02-01 - 1986-05-17) | - | 1985-02-01 | automation commissioning | Nikolai Shevchuk, N. Shevchuk | Deceased 17 May 1986 (burns, ARS) |
| P18 | Gennady Petrovich Kuzmin | EXT-ETS-0102 | Energoteststroy (Donetsk) - test contractor | Electrical Test Engineer (1985-06-01 - present) | - | 1985-06-01 | generator excitation and rundown testing | G. P. Kuzmin, Hennadii Kuzmin, the Donetsk engineer | Working at Energoteststroy; trial witness |
| P19 | Dmitry Ivanovich Rudenko | FIRE-07-011 | Paramilitary Fire Unit No. 7 (station) | Lieutenant, guard commander, Fire Unit No. 7 (1983-09-01 - 1986-05-17) | P20 | 1983-09-01 | firefighting | Lt. Rudenko, D. I. Rudenko, Dmytro Rudenko | Deceased 29 May 1986 (ARS) |
| P20 | Leonid Tarasovich Golub | FIRE-07-001 | Paramilitary Fire Unit No. 7 (station) | Major, Head of Fire Unit No. 7 (1982-01-15 - 1987-04-01)<br>Lt. Colonel, deputy head, regional fire directorate (1987-04-01 - present) | - | 1982-01-15 | fire service command | Maj. Golub, L. T. Golub, Holub | Working; ARS survivor |
| P21 | Sergei Petrenko | FIRE-09-007 | Paramilitary Fire Unit No. 9 (town) | Lieutenant, guard commander, Fire Unit No. 9 (1984-10-01 - 1986-05-17) | - | 1984-10-01 | firefighting | Lt. Petrenko, Serhii Petrenko, S. Petrenko | Deceased 25 May 1986 (ARS) |
| P22 | Volodymyr Chumak | FIRE-07-019 | Fire Unit No. 7 | Sergeant, firefighter (1984-03-01 - 1986-05-17) | P19 | 1984-03-01 | firefighting | Vladimir Chumak, Sgt. Chumak | Deceased 27 May 1986 (ARS) |
| P23 | Pyotr Usenko | FIRE-09-014 | Fire Unit No. 9 | Sergeant, firefighter (1985-01-10 - present) | P21 | 1985-01-10 | firefighting | Petro Usenko, Sgt. Usenko | Working; ARS survivor |
| P24 | Mykhailo Tsybulko | FIRE-07-022 | Fire Unit No. 7 | Senior Sergeant, driver (1982-05-01 - 1986-05-17) | P19 | 1982-05-01 | fire engine driver | Mikhail Tsybulko, Sr. Sgt. Tsybulko | Deceased 3 Jun 1986 (ARS) |
| P25 | Lyudmila Pavlovna Gerasimova | MSU41-0003 | Medical-Sanitary Unit No. 41 (station medical unit) | Head of Medical-Sanitary Unit No. 41 (1980-02-01 - present) | - | 1980-02-01 | occupational medicine | Dr. Gerasimova, L. P. Gerasimova, Liudmyla Herasymova | Working |
| P26 | Arkady Semyonovich Volkov | CRC4-0118 | Central Radiological Clinic No. 4, Moscow | Head, acute radiation injury department (1975-01-01 - present) | - | 1975-01-01 | radiation medicine | Prof. Volkov, A. S. Volkov | Working |
| P27 | Gennady Ivanovich Zaitsev | GOV-0001 | Council of Ministers | Chairman, Government Commission (1st shift) (1986-05-17 - 1986-06-03) | - | 1986-05-17 | energy administration | G. I. Zaitsev, the commission chairman, Zaytsev | Returned to Moscow |
| P28 | Viktor Arkadievich Demidov | GOV-0002 | Council of Ministers | Chairman, Government Commission (2nd shift) (1986-06-03 - 1986-07-15) | - | 1986-06-03 | construction ministry | V. A. Demidov | Returned to Moscow |
| P29 | Yevgeny Borisovich Nikitin | IRP-0009 | Institute of Reactor Physics (Moscow) | Scientific lead, Government Commission (1986-05-17 - 1986-09-20) | - | 1986-05-17 | reactor physics, chemistry | Academician Nikitin, Ye. B. Nikitin, E. Nikitin | Working in Moscow |
| P30 | Aleksandr Ivanovich Karpenko | CD-REG-0004 | Regional Civil Defense staff | Colonel, Chief of Staff, Regional Civil Defense (1983-01-01 - present) | - | 1983-01-01 | civil defense, evacuation planning | Col. Karpenko, O. I. Karpenko, Oleksandr Karpenko | Working |
| P31 | Nadezhda Fyodorovna Makarenko | ISP-VER-0001 | Vereskovsk Town Executive Committee | Chair, Vereskovsk Town Executive Committee (1982-03-01 - 1987-06-30) | - | 1982-03-01 | municipal administration | N. F. Makarenko, Nadiia Makarenko | Transferred to regional executive committee Jul 1987 |
| P32 | Ivan Ivanovich Gordienko | PARTY-VER-01 | Vereskovsk Town Party Committee | First Secretary, Vereskovsk Town Party Committee (1981-01-01 - 1986-12-31) | - | 1981-01-01 | Party work | I. I. Gordienko, Hordiienko | Moved to regional Party apparatus 1987 |
| P33 | Irina Viktorovna Yarosh | NIIKRE-0231 | Institute of Channel Reactor Engineering (NIIKRE) | Senior Researcher, core physics laboratory (1978-09-01 - 1987-02-01)<br>Head, safety analysis laboratory (1987-02-01 - present) | P34 | 1978-09-01 | core neutronics, control rod design | I. V. Yarosh, Iryna Yarosh, Dr. Yarosh | Working |
| P34 | Boris Kirillovich Levchenko | OKBK-0002 | Chief Designer's Bureau OKB-Kanal | Chief Designer, channel reactors (1979-01-01 - present) | - | 1979-01-01 | reactor design | B. K. Levchenko, the chief designer | Working |
| P35 | Aleksei Grigorievich Polishchuk | GKA-0003 | State Committee for Atomic Power (Goskomatom) | Deputy Chairman, Goskomatom (1983-01-01 - present) | - | 1983-01-01 | nuclear power administration | A. G. Polishchuk, Oleksii Polishchuk, the deputy chairman | Working |
| P36 | Yevhen Nazarenko | VNPS-00388 | Reactor shop / Unit 3 operations | Unit 3 Shift Supervisor (1983-10-01 - present) | P11 | 1976-07-12 | unit operations | Yevgeny Nazarenko, Ye. Nazarenko, Zhenya | Working |
| P37 | Pavel Lukin | VNPS-01244 | Dosimetry service | Shift dosimetrist (1982-05-04 - present) | P12 | 1982-05-04 | radiation monitoring | P. Lukin, Pavlo Lukin | Working |
| P38 | Taras Mironenko | VNPS-01251 | Dosimetry service | Dosimetrist (1983-03-01 - present) | P12 | 1983-03-01 | radiation monitoring | T. Myronenko, Taras Myronenko | Working; ARS (mild) survivor |
| P39 | Valentina Sergeyevna Osipova | VNPS-00088 | Cadres (personnel) department | Head, Cadres Department (1981-01-01 - present) | P01 | 1971-09-01 | personnel records | V. S. Kuzmina, Valentina Kuzmina, V. Osipova | Working (surname changed Kuzmina -> Osipova, Feb 1987) |
| P40 | Ilya Konstantinovich Antonov | GKA-0001 | State Committee for Atomic Power (Goskomatom) | Chairman, Goskomatom (1982-01-01 - present) | - | 1982-01-01 | administration | I. K. Antonov, the Chairman | Working |
| P41 | Arkady Danilchenko | VNPS-00099 | Training center | Head, Training Center (1980-01-01 - present) | P02 | 1974-02-11 | operator training | A. Danilchenko, Arkadii Danylchenko | Working |
| P42 | Rostislav Kirillovich Demchenko | GNI-0001 | State Nuclear Safety Inspectorate (GNI) | Head, Southern District, GNI (1984-01-01 - present) | - | 1984-01-01 | regulation | R. K. Demchenko | Working |
| P43 | Larisa Pavlyuk | VNPS-00172 | Chemical shop | Head, Chemical Shop (1982-01-01 - present) | P02 | 1975-10-01 | water chemistry | Larysa Pavliuk, L. Pavlyuk | Working |
| P44 | Igor Stepanovich Golovko | VNPS-00166 | Electrical shop | Head, Electrical Shop (1983-01-01 - present) | P02 | 1976-03-01 | electrical systems | I. S. Golovko, Ihor Holovko | Working |
| P45 | Vadim Pavlovich Rybak | VNPS-00163 | Turbine shop | Head, Turbine Shop (1982-01-01 - present) | P02 | 1975-01-01 | turbines | V. P. Rybak, Vadym Rybak | Working |
| P46 | Mykola Prokopenko | VNPS-00181 | Centralized repair shop | Head, Centralized Repair Shop (1984-04-01 - present) | P06 | 1977-04-01 | mechanical repair | Nikolai Prokopenko, N. Prokopenko | Working |
| P47 | Vasily Klimenko | VNPS-02001 | Construction directorate, Units 5-6 | Head, Construction Directorate Units 5-6 (1981-05-01 - 1987-10-31) | P01 | 1981-05-01 | construction | V. Klimenko, Vasyl Klymenko | Directorate dissolved Oct 1987; transferred to Lisogorsk town construction |
| P48 | Sergei Ivanovich Tarasov | VNPS-00129 | Nuclear safety department | Head, Nuclear Safety Department (1982-01-01 - present) | P02 | 1976-01-01 | core physics | S. I. Tarasov, Serhii Tarasov | Working |
| P49 | Igor Romanov | VNPS-00419 | Reactor shop / Unit 4 operations | Unit 4 Shift Supervisor (Shift 4, evening) (1984-02-01 - present)<br>Unit 1 Shift Supervisor (1986-09-01 - present) | P11 | 1978-05-01 | unit operations | I. Romanov, Ihor Romanov | Working |
| P50 | Mikhail Kalnysh | VNPS-00905 | Reactor shop | Senior Reactor Control Engineer (evening shift), Unit 4 (1984-06-01 - present) | P49 | 1981-08-01 | reactor control | M. Kalnysh, Mykhailo Kalnysh | Working (Unit 1) |
| P51 | Andriy Shapoval | VNPS-00744 | Turbine shop | Senior Engineer, Turbine Shop (1983-01-01 - present) | P45 | 1980-01-01 | valves and piping | Andrei Shapoval, A. Shapoval | Working |
| P52 | Konstantin Babenko | VNPS-00751 | Turbine shop | Engineer, Turbine Shop (1984-01-01 - present) | P45 | 1982-01-01 | pumps | K. Babenko, Kostia | Working |
| P53 | Ihor Yakovenko | VNPS-00763 | Reactor shop | Shift foreman, Reactor Shop (1985-01-01 - present) | P14 | 1980-09-01 | reactor auxiliaries | Igor Yakovenko, I. Yakovenko | Working |
| P54 | Oleg Panchenko | EXT-MIL-0388 | Army chemical defense unit (roof clearing) | Captain, roof-clearing company commander (1986-09-12 - 1986-10-10) | P13 | 1986-09-12 | chemical troops | Capt. Panchenko, O. Panchenko | Returned to unit |
| P55 | Ruslan Trofimov | EXT-MIL-1417 | Army chemical defense unit | Private, roof clearing (1986-09-12 - 1986-10-02) | P54 | 1986-09-12 | reservist | Pvt. Trofimov, R. Trofimov | Demobilized |
| P56 | Valentin Kharchenko | EXT-AV-0001 | Air force helicopter regiment | Colonel, commander of helicopter operations at V-NPS (1986-05-18 - 1986-06-20) | - | 1986-05-18 | helicopter aviation | Col. Kharchenko, V. Kharchenko | Returned to regiment |
| P57 | Stanislav Ryabov | EXT-MIN-0021 | Miners' brigade (coal ministry) | Foreman, tunneling brigade (1986-06-04 - 1986-07-02) | - | 1986-06-04 | tunneling | S. Ryabov, Stas | Returned to mine |
| P58 | Gleb Arturovich Aksyonov | SU219-0002 | Construction Directorate SU-219 (Shelter) | Chief Engineer, SU-219 (1986-06-10 - present) | - | 1986-06-10 | heavy construction | G. A. Aksyonov, Aksenov | Working |
| P59 | Viktor Chernov | NIIKRE-0412 | NIIKRE robotics laboratory | Engineer, robotics laboratory (1984-01-01 - present) | P33 | 1984-01-01 | remote handling | V. Chernov, Chernov V. | Working |
| P60 | Henrik Aspelund | EXT-VAR-0001 | Aspelund Robotik (Varnland) | Service engineer (on site) (1986-08-25 - 1986-09-20) | - | 1986-08-25 | industrial robots | H. Aspelund, Mr. Aspelund | Returned to Varnland |
| P61 | Maren Holt | EXT-VAR-0010 | Varnland Radiation Protection Institute (VRPI) | Duty physicist / later head of environmental monitoring (1979-01-01 - present) | - | 1979-01-01 | environmental monitoring | Dr. Holt, M. Holt | Working |
| P62 | Lars Ekvall | EXT-VAR-0022 | Skarvik Nuclear Plant (Varnland) | Radiation protection supervisor (1981-01-01 - present) | - | 1981-01-01 | radiation protection | L. Ekvall | Working |
| P63 | Per Dahlstrand | EXT-VAR-0050 | Embassy of Varnland, Moscow | Counsellor (science and technology) (1985-01-01 - present) | - | 1985-01-01 | diplomacy | Counsellor Dahlstrand | Working |
| P64 | Yuri Filatov | EXT-PRS-0001 | Zarya Polesya (regional newspaper) | Correspondent (1980-01-01 - present) | - | 1980-01-01 | journalism | Yu. Filatov, Yurii Filatov | Working |
| P65 | Galina Yakubovich | EXT-PRS-0002 | Sovetsky Vestnik (national newspaper) | Science correspondent (1982-01-01 - present) | - | 1982-01-01 | science journalism | G. Yakubovich, Halyna Yakubovych | Working |
| P66 | A. Ostrovsky | EXT-GRID-0003 | Republic Grid Dispatch Center (Kyiv) | Duty dispatcher (1980-01-01 - present) | - | 1980-01-01 | grid dispatch | dispatcher Ostrovsky | Working |
| P67 | Petro Babych | VNPS-01377 | Reactor shop | SIUR trainee (Unit 4); Unit 1 SIUR from Oct 1986 (1985-09-01 - present) | P07 | 1985-09-01 | reactor control (trainee) | Pyotr Babich, P. Babych | Working; ARS (mild) survivor |
| P71 | Anatolii Lytvyn | FIRE-07-002 | Fire Unit No. 7 | Captain, deputy head of Fire Unit No. 7 (acting head from 18 May 1986) (1984-01-01 - present) | P20 | 1984-01-01 | fire service | Capt. A. Lytvyn, Anatoly Litvin | Working |
| P68 | S. Danilov | VNPS-00401 | Reactor shop / Unit 4 operations | Unit 4 Shift Supervisor (Shift 1) (1983-01-01 - present) | P11 | 1976-01-01 | unit operations | - | Working (mentioned only in Order No. 56) |
| P69 | V. Kostenko | VNPS-00403 | Reactor shop / Unit 4 operations | Unit 4 Shift Supervisor (Shift 2) (1983-01-01 - present) | P11 | 1977-01-01 | unit operations | - | Working (mentioned only in Order No. 56) |
| P70 | A. Panasiuk | VNPS-00405 | Reactor shop / Unit 4 operations | Unit 4 Shift Supervisor (Shift 3) (1984-01-01 - present) | P11 | 1978-01-01 | unit operations | - | Working (mentioned only in Order No. 56) |

## Organizations

| ID | Name | Type | Location | Aliases |
|---|---|---|---|---|
| ORG-0001 | State Committee for Atomic Power (Goskomatom) | ministry | Moscow | Goskomatom, the Committee, GKA |
| ORG-0002 | Republic Energy Directorate (Ukrenergo-R) | republic directorate | Kyiv | the Directorate, Ukrenergo-R |
| ORG-0003 | Institute of Channel Reactor Engineering (NIIKRE) | design institute | Moscow | NIIKRE, the Institute, the design institute |
| ORG-0004 | Chief Designer's Bureau OKB-Kanal | chief designer | Moscow | OKB-Kanal, the chief designer's bureau |
| ORG-0005 | State Nuclear Safety Inspectorate (GNI) | regulator | Moscow/Kyiv | GNI, Gosinspektsiya, the Inspectorate |
| ORG-0006 | Institute of Reactor Physics (IRP) | research institute | Moscow | IRP |
| ORG-0007 | Volzhsky Turbine Works | turbine-generator manufacturer | Volgograd region | VTZ, Volzhsky |
| ORG-0008 | Severny Pump Plant | pump manufacturer | Leningrad region | SNZ, Severny |
| ORG-0009 | Elektron-Pribor (Kyiv) | instrumentation/dosimeters | Kyiv | Elektronpribor, EP-Kyiv |
| ORG-0010 | Atomnaladka Trust | commissioning contractor | Moscow | Atomnaladka, ANL |
| ORG-0011 | Energoteststroy (Donetsk) | electrical test contractor | Donetsk | Energoteststroy, the Donetsk organization, ETS |
| ORG-0012 | Spetsmontazh Trust No. 3 (renamed Spetsatomstroy-3, Mar 1987) | installation contractor | Kyiv | Spetsmontazh-3, Spetsatomstroy-3, Trust No. 3 |
| ORG-0013 | Construction Directorate SU-219 | Shelter builder | Berezovy Gai | SU-219, the directorate |
| ORG-0014 | Uralgrafit Combine | graphite supplier | Urals | Uralgrafit |
| ORG-0015 | Fuel Assembly Plant No. 12 | fuel supplier | Siberia | Plant No. 12, FAP-12 |
| ORG-0016 | Dniprostroimaterialy | sand, clay, concrete supplier | Zhitniki | DSM |
| ORG-0017 | Svinets-Tsvetmet lead combine | lead supplier | Kazakh SSR | Svinets |
| ORG-0018 | Varnland Radiation Protection Institute (VRPI) | foreign agency | Varnland | VRPI, the Varnland institute |
| ORG-0019 | Aspelund Robotik | foreign robot vendor | Varnland | Aspelund, the Varnland firm |
| ORG-0020 | Central Radiological Clinic No. 4 | hospital | Moscow | Clinic No. 4, the Moscow clinic, CRC-4 |
| ORG-0021 | Medical-Sanitary Unit No. 41 | station medical unit | Vereskovsk | MSU-41, the medical unit, MSCh-41 |
| ORG-0022 | Republic Grid Dispatch Center | grid dispatcher | Kyiv | grid dispatch, the dispatcher, Kyivenergo dispatch |
| ORG-0023 | Zarya Polesya | regional newspaper | Zhitniki | Zarya Polesya, Zoria Polissia |
| ORG-0024 | Sovetsky Vestnik | national newspaper | Moscow | Sov. Vestnik |

## Settlements

| ID | Name (Ukr.) | Russian / alt. | Type | Distance km | Direction | Population 1 Jan 1986 | Evacuated | Initial zone | Status 1987 | Cs-137 soil Jun 1986 (Ci/km2) |
|---|---|---|---|---|---|---|---|---|---|---|
| SET-001 | Vereskivsk | Vereskovsk | town | 3.5 | NW | 47800 | 1986-05-18 | 10 km | abandoned; exclusion zone | 62.0 |
| SET-002 | Ozerne | Ozernoye | village | 2.8 | S | 1120 | 1986-05-21 | 10 km | abandoned; exclusion zone | 95.0 |
| SET-003 | Hlibove | Glebovo | village | 6.0 | W | 860 | 1986-05-21 | 10 km | abandoned; exclusion zone | 140.0 |
| SET-004 | Sosnivka | Sosnovka | village | 9.0 | SW | 1410 | 1986-05-21 | 10 km | abandoned; exclusion zone | 48.0 |
| SET-005 | Dubrova | Dubrova | village | 8.0 | N | 640 | 1986-05-21 | 10 km | abandoned; exclusion zone | 71.0 |
| SET-006 | Verbivka | Verbovka | rail settlement | 5.0 | E | 520 | 1986-05-18 | 10 km | abandoned; rail siding in use for zone logistics | 33.0 |
| SET-007 | Lisove | Lesnoye | district center | 16.0 | SE | 12900 | 1986-06-07 | 30 km | evacuated; zone administration base | 21.0 |
| SET-008 | Zhytnyky | Zhitniki | regional center | 96.0 | S | 281000 | - | outside | inhabited | 0.4 |
| SET-009 | Kalynivka | Kalinovka | village | 14.0 | W | 980 | 1986-05-26 | 30 km | abandoned | 44.0 |
| SET-010 | Moshchanka | Moshchanka | village | 22.0 | NW | 1240 | 1986-05-30 | 30 km | abandoned | 37.0 |
| SET-011 | Bilyi Brid | Bely Brod | village | 18.0 | N | 760 | 1986-05-26 | 30 km | abandoned | 29.0 |
| SET-012 | Staryi Hai | Stary Gai | village | 27.0 | SW | 1530 | 1986-06-02 | 30 km | abandoned | 12.0 |
| SET-013 | Kozhukhivka | Kozhukhovka | village | 33.0 | W | 690 | 1986-06-14 | outside | evacuated (hotspot) | 52.0 |
| SET-014 | Ruda Vereskivska | Ruda Vereskovskaya | village | 41.0 | NW | 1050 | - | outside | strict control zone; voluntary resettlement from Sep 1987 | 18.0 |
| SET-015 | Lypnyky | Lipniki | village | 24.0 | E | 830 | 1986-05-30 | 30 km | abandoned | 15.0 |
| SET-016 | Horodyshche | Gorodishche | village | 29.0 | S | 2010 | 1986-06-02 | 30 km | abandoned | 9.5 |
| SET-017 | Petrivka | Petrovka | village | 31.0 | SE | 1760 | - | outside | inhabited; milk restrictions | 7.2 |
| SET-018 | Zarichne | Zarechnoye | village | 12.0 | NE | 410 | 1986-05-26 | 30 km | abandoned | 26.0 |
| SET-019 | Novosilky | Novoselki | village | 52.0 | NW | 2300 | - | outside | inhabited; agricultural restrictions | 6.1 |
| SET-020 | Kamianka | Kamenka | village | 7.0 | SE | 590 | 1986-05-21 | 10 km | abandoned; exclusion zone | 58.0 |
| SET-021 | Ostriv | Ostrov | village | 4.5 | NE | 270 | 1986-05-19 | 10 km | abandoned; exclusion zone | 88.0 |
| SET-022 | Vilshanka | Olshanka | village | 38.0 | N | 1180 | - | outside | added to resettlement list Oct 1987 | 16.5 |

## Equipment and systems

| ID | Name | Manufacturer | Model | Installed | Location | Rating | Aliases | Status 1987 |
|---|---|---|---|---|---|---|---|---|
| U4-RCT-01 | Unit 4 reactor (channel-type, graphite moderated) | OKB-Kanal / NIIKRE | RK-1000/4 | 1983-12-22 | Unit 4 reactor building | 3,200 MWt / 1,000 MWe | the reactor, the fourth unit reactor, Unit 4 | destroyed; enclosed in Shelter |
| U4-CPS-01 | Control and protection system (211 rods: manual, automatic, shortened absorbers, emergency) | NIIKRE | SUZ-K4 | 1983-12-22 | Unit 4 | full insertion 18-21 s | SUZ, CPS, the rods | destroyed |
| U4-EPS-01 | Emergency protection system (AZ-5 level) | NIIKRE | AZ-K | 1983-12-22 | Unit 4 control room | trip on 5 levels | AZ-5, the AZ button, EP-5, emergency protection | destroyed |
| U4-MCP-01 | Main circulation pump 1 (left loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, left | 8,000 m3/h | MCP-1, pump 1 | destroyed |
| U4-MCP-02 | Main circulation pump 2 (left loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, left | 8,000 m3/h | MCP-2 | destroyed |
| U4-MCP-03 | Main circulation pump 3 (left loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, left | 8,000 m3/h | MCP-3, the third pump on the left side, the noisy one, pump 3 | destroyed |
| U4-MCP-04 | Main circulation pump 4 (left loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, left | 8,000 m3/h | MCP-4 | destroyed |
| U4-MCP-05 | Main circulation pump 5 (right loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, right | 8,000 m3/h | MCP-5 | destroyed |
| U4-MCP-06 | Main circulation pump 6 (right loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, right | 8,000 m3/h | MCP-6 | destroyed |
| U4-MCP-07 | Main circulation pump 7 (right loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, right | 8,000 m3/h | MCP-7 | destroyed |
| U4-MCP-08 | Main circulation pump 8 (right loop) | Severny Pump Plant | MTsN-8K | 1983-10-01 | Unit 4 MCP room, right | 8,000 m3/h | MCP-8 | destroyed |
| U4-DS-01 | Drum separator 1 | Spetsmontazh Trust No. 3 | BS-2800 | 1983-08-15 | Unit 4 drum separator room | 70 kgf/cm2 nominal | DS-1, drum 1 | destroyed |
| U4-DS-02 | Drum separator 2 | Spetsmontazh Trust No. 3 | BS-2800 | 1983-08-15 | Unit 4 | 70 kgf/cm2 | DS-2 | destroyed |
| U4-DS-03 | Drum separator 3 | Spetsmontazh Trust No. 3 | BS-2800 | 1983-08-15 | Unit 4 | 70 kgf/cm2 | DS-3 | destroyed |
| U4-DS-04 | Drum separator 4 | Spetsmontazh Trust No. 3 | BS-2800 | 1983-08-15 | Unit 4 | 70 kgf/cm2 | DS-4 | destroyed |
| U4-FWP-01 | Feedwater pump 1 | Severny Pump Plant | FWN-1650 | 1983-09-01 | Unit 4 deaerator gallery level | 1,650 t/h | FWP-1 | destroyed |
| U4-TG-07 | Turbine-generator 7 | Volzhsky Turbine Works | VT-500-6K | 1983-11-01 | Turbine hall, Unit 4 section | 500 MWe | TG-7, turbine 7 | damaged; decommissioned |
| U4-TG-08 | Turbine-generator 8 | Volzhsky Turbine Works | VT-500-6K | 1983-11-01 | Turbine hall, Unit 4 section | 500 MWe | TG-8, turbine 8, the eighth turbine | damaged; decommissioned |
| U4-DG-01 | Diesel generator 1 (Unit 4) | Volgodiesel (fictional) | DGA-5600 | 1983-07-01 | Unit 4 diesel building | 5.6 MW; start-to-load 15 s (spec) | DG-1 | contaminated; out of service |
| U4-DG-02 | Diesel generator 2 (Unit 4) | Volgodiesel (fictional) | DGA-5600 | 1983-07-01 | Unit 4 diesel building | 5.6 MW | DG-2 | contaminated; out of service |
| U4-ECCS-01 | Emergency core cooling system | NIIKRE / Spetsmontazh | SAOR-K | 1983-12-01 | Unit 4 | - | SAOR, ECCS | destroyed |
| U4-PC-01 | Plant computer Vega-M (Unit 4) | Elektron-Pribor | Vega-M | 1983-11-15 | Unit 4 computer room | parameter scan approx. 1 s / ORM calc every 5-10 min | Vega, the computer, VPC-4/II (design institute designation), Vega-M | magnetic tapes recovered; equipment abandoned |
| U4-ICM-01 | In-core monitoring system | Elektron-Pribor | SVK-4 | 1983-11-15 | Unit 4 | 130 radial detectors | SVK, in-core monitoring | destroyed |
| U4-BP-01 | Bubbler (pressure suppression) pool | Spetsmontazh Trust No. 3 | - | 1983-08-01 | below Unit 4 reactor | approx. 3,000 m3 (upper tier) | the bubbler pool, the suppression pool, barbotage pool | drained 26 May 1986; entombed |
| U4-BP-V12 | Bubbler pool drain valve 12 | Spetsmontazh | - | 1983-08-01 | Unit 4, room 012/4 | - | valve 12 | opened 25 May 1986; entombed |
| U34-RFM-01 | Refueling machine (shared Units 3-4) | Spetsmontazh / NIIKRE | RZM-K | 1981-05-01 | Unit 3/4 central hall | - | RZM, the refueling machine | Unit 3 side decontaminated; returned to service Nov 1987 |
| U34-VS-01 | Ventilation stack Units 3-4 | Spetsmontazh | - | 1981-01-01 | between Units 3 and 4 | 150 m height | the stack, the striped chimney | in place; decontaminated partially |
| U3-RCT-01 | Unit 3 reactor | OKB-Kanal / NIIKRE | RK-1000/3 | 1981-12-03 | Unit 3 | 3,200 MWt | Unit 3 | restarted 4 Dec 1987 |
| U2-RCT-01 | Unit 2 reactor | OKB-Kanal / NIIKRE | RK-1000/2 | 1978-12-21 | Unit 2 | 3,200 MWt | Unit 2 | restarted 5 Nov 1986 |
| U1-RCT-01 | Unit 1 reactor | OKB-Kanal / NIIKRE | RK-1000/1 | 1977-09-26 | Unit 1 | 3,200 MWt | Unit 1 | restarted 1 Oct 1986 |
| U5-RCT-01 | Unit 5 reactor (under construction) | OKB-Kanal | RK-1000/5M | - | Units 5-6 site | 3,200 MWt (design) | Unit 5, the fifth unit | construction cancelled Oct 1987 |
| CP-PMP-01 | Cooling pond intake pump station 1 | Severny Pump Plant | OPV-11 | 1977-05-01 | cooling pond | 40,000 m3/h | intake 1 | operating |
| DOS-RKS4 | Station dosimeter type RKS-4 (fleet of 60) | Elektron-Pribor | RKS-4 | 1982-01-01 | dosimetry service | 0.05-4 R/h (two sub-ranges) | the 4-roentgen meters, RKS, the station meters | in use (fleet) |
| DOS-VR1000-0012 | High-range dosimeter VR-1000 No. 0012 | Elektron-Pribor | VR-1000 | 1984-03-01 | Unit 1 dosimetry safe (moved to Unit 4 bunker 17 May 03:50) | 1-1,000 R/h (passport); operators believed 500 R/h | the thousand meter, VR-1000, the high-range meter | decontaminated; in use |
| DOS-DK02 | Personal pocket dosimeters DKP-20 | Elektron-Pribor | DKP-20 | 1980-01-01 | issued to staff | 0-200 mR | pencil dosimeters, DK | in use |
| DOS-IMD21 | Military dosimeter RDV-21 (civil defense) | military | RDV-21 | 1979-01-01 | civil defense bunker / military units | 0.1-500 R/h | IMD, the army meters | in use |
| FE-07-01 | Fire engine (tanker) No. 1, Fire Unit 7 | fictional | TC-40F | 1980-01-01 | station fire depot | - | engine 1/7 | contaminated; buried at waste site 1986 |
| FE-07-02 | Fire engine (ladder) Fire Unit 7 | fictional | LT-30F | 1981-01-01 | station fire depot | 30 m ladder | the ladder truck | contaminated; buried |
| FE-07-PNS | Pump station truck PS-115F, Fire Unit 7 | fictional | PS-115F | 1982-01-01 | station fire depot | 110 L/s | PS truck, the pump truck | used for bubbler pool drainage; buried 1986 |
| FE-09-01 | Fire engine (tanker), Fire Unit 9 | fictional | TC-40F | 1979-01-01 | town fire depot | - | engine 1/9 | contaminated; buried |
| HEL-V8T | Transport helicopters type V-8T (group) | military | V-8T | - | Lisove airfield | payload approx. 3 t external | V-8, the eights | returned to regiment |
| HEL-V26H | Heavy-lift helicopter type V-26H | military | V-26H | - | Lisove airfield | payload approx. 18 t | the heavy helicopter, V-26 | returned to regiment |
| ROB-MRK2-01 | Remote robot MRK-2, unit 01 | NIIKRE robotics lab | MRK-2 | 1986-08-20 | Unit 3 roof | payload 200 kg | MRK-2, the Moscow robot | first unit fell from roof 19 Sep 1986; replacement given same ID 3 Oct 1986 |
| ROB-VR40-01 | Remote robot Aspelund R-40 | Aspelund Robotik | R-40 | 1986-08-29 | Unit 3 roof | - | the Varnland robot, R-40 | failed 6 Sep 1986 (electronics); abandoned |
| SH-BEAM-B1 | Shelter main support girder B1 | SU-219 | - | 1986-10-28 | Shelter roof | spans 70 m; 165 t | the Great Girder, B1, the big beam | in place |
| SH-WALL-N | Shelter northern cascade wall | SU-219 | - | 1986-11-20 | north side of Unit 4 | - | the cascade wall, the staircase wall | in place |
| SH-SEP-01 | Separation wall Unit 3 / Unit 4 | SU-219 | - | 1986-07-30 | deaerator gallery level | - | the dividing wall | in place |
| SH-VENT-01 | Shelter ventilation and filtration system | SU-219 | - | 1986-12-10 | Shelter | - | Shelter ventilation | operating with defects |
| TUN-HX-01 | Heat exchanger slab under Unit 4 foundation | Miners' brigade / SU-219 | - | 1986-07-02 | beneath Unit 4 | - | the cooling slab, the heat exchanger, the tunnel slab | installed, never activated |
| LN2-INJ-01 | Liquid nitrogen injection line | military | - | 1986-05-24 | under Unit 4 | - | the nitrogen line | dismantled |

## Materials and radionuclides

| ID | Name | Supplier | Use | Quantity / note |
|---|---|---|---|---|
| MAT-001 | Boron carbide (B4C) | Moscow Chemical Reagents Plant (fictional) | neutron absorber dropped on core | 40 t dropped |
| MAT-002 | Dolomite | Dniprostroimaterialy | dropped to generate CO2 and absorb heat | 800 t dropped |
| MAT-003 | Sand | Dniprostroimaterialy | dropped to smother fire and filter aerosols | 1,100 t dropped (incl. in 'sand and clay') |
| MAT-004 | Clay | Dniprostroimaterialy | dropped with sand | 700 t dropped |
| MAT-005 | Lead (ingots and shot) | Svinets-Tsvetmet | dropped to absorb heat by melting; later judged counterproductive (lead vapour) and of doubtful effect | 2,380 t dropped |
| MAT-006 | Liquid nitrogen | industrial gases trust | injected under reactor to cool and displace oxygen | - |
| MAT-007 | Potassium iodide tablets | republic pharmacy depot | thyroid blocking | distributed late (18-19 May) |
| MAT-008 | Decontamination solution SF-2U | fictional chemical works | surface decontamination | - |
| MAT-009 | Film-forming polymer PVA-K | fictional | dust suppression | - |
| MAT-010 | Concrete grade M-300 | Dniprostroimaterialy | Shelter construction | approx. 400,000 m3 (estimate) |
| MAT-011 | Structural steel | various | Shelter frame | approx. 7,000 t |
| MAT-012 | Lead sheet (shielding) | Svinets-Tsvetmet | personal shielding aprons, cabins | - |
| MAT-013 | Trisodium phosphate | fictional | decontamination additive | - |
| MAT-014 | Graphite blocks (spare) | Uralgrafit | core moderator (spares) | - |
| MAT-015 | Fuel assemblies 2.0% U-235 | Fuel Assembly Plant No. 12 | original core loading | - |
| MAT-016 | Fuel assemblies 2.4% U-235 | Fuel Assembly Plant No. 12 | post-accident modification | from Aug 1986 |
| NUC-I131 | Iodine-131 | - | half-life 8.02 d | - |
| NUC-CS137 | Caesium-137 | - | half-life 30.2 y | - |
| NUC-CS134 | Caesium-134 | - | half-life 2.06 y | - |
| NUC-SR90 | Strontium-90 | - | half-life 28.8 y | - |
| NUC-PU239 | Plutonium-239 | - | half-life 24,100 y | - |
| NUC-XE133 | Xenon-133 | - | half-life 5.25 d | - |
| NUC-TE132 | Tellurium-132 | - | half-life 3.2 d | - |
| NUC-RU106 | Ruthenium-106 | - | half-life 372 d | - |
| NUC-ZR95 | Zirconium-95 | - | half-life 64 d | - |

## Projects

| ID | Name | Owner | Budget | Start | End | State Dec 1987 |
|---|---|---|---|---|---|---|
| PRJ-01 | TG-8 rundown (coast-down) test | P03 | n/a | 1985-12-01 | 1986-05-17 | test program approved Apr 1986 (Rev.1); test performed 17 May 1986; ended in accident |
| PRJ-02 | Units 5-6 construction | P47 | 1.86 billion rubles (1985 estimate) | 1981-05-01 | 1987-10-31 | suspended Jun 1986; cancelled by Council of Ministers decision Oct 1987 |
| PRJ-03 | Control-rod and core modification (RBMK-type) | P33 | n/a | 1985-10-14 | 1987-12-31 | memo 1985; implemented on Units 1-3 Aug 1986 - Dec 1987: min ORM 30 rods, 2.4% fuel, faster EPS |
| PRJ-04 | Evacuation and resettlement | P30 | - | 1986-05-18 | - | ongoing; resettlement additions 1987 |
| PRJ-05 | Decontamination of Units 1-3 and site | P04 | ~ 380 million rubles (1987 estimate) | 1986-06-01 | - | ongoing |
| PRJ-06 | Shelter (enclosure of Unit 4) | P58 | estimates 120 -> 240 million rubles | 1986-06-10 | 1986-12-14 | acceptance act 14 Dec 1986; sealing works to Feb 1987; assessment Jul 1987 |
| PRJ-07 | Restart of Units 1-3 | P04 | - | 1986-06-15 | 1987-12-04 | U1 1 Oct 1986, U2 5 Nov 1986, U3 4 Dec 1987 |
| PRJ-08 | New town Lisogorsk for station staff | P47 | ~ 410 million rubles (estimate) | 1987-03-01 | - | construction started Oct 1987 |
| PRJ-09 | Health monitoring registry | P25 | - | 1986-07-01 | - | registry established; 1987 all-union format |
