# Other seeded issues

Typos, duplicates, header errors, rumours, non-reconciling numbers, ambiguity, censorship.

| ID | Type | Document | Text | Explanation |
|---|---|---|---|---|
| T01 | typo (equipment ID) | DOC-1985-0018 | U4-MPC-03 | Should be U4-MCP-03. |
| T02 | typo (settlement) | DOC-1986-0080 | Kozhukivka | Should be Kozhukhivka (SET-013). |
| T03 | OCR-like error | DOC-1986-0025 | VERESKOVO NP5 | NP5 = NPS. |
| D01 | near-duplicate (draft/final) | DOC-1986-0012 | entire duration of the test program | Rev.0 vs Rev.1 of the test program: ECCS isolation '~4 hours' -> 'entire duration'; Rev.1 adds safety clause and approval. |
| D02 | near-duplicate (retransmission with changed figure) | DOC-1986-0025 | 1000 MICRO | Repeat of telegram No. 1 with 1,100 -> 1,000. |
| D03 | near-duplicate (reprint with added text) | DOC-1986-0054 | Our correspondent Yu. Filatov | Regional reprint of the national article with a local paragraph. |
| D04 | near-duplicate (draft/final) | DOC-1986-0079 | 1.5 rem | Draft 3.3 rem vs final 1.5 rem. |
| D05 | duplicate data row | DOC-1986-0068 | resubmitted by 2nd squadron | 23 May row appears twice. |
| H01 | header error | DOC-1986-0007 | Approved: ___________ (chief engineer) | Header status 'approved' but the document is an unsigned draft (Rev.0). |
| H02 | header error | DOC-1983-0001 | 1983 edition | Header status 'approved' though superseded by the 1986 revision (Units 1-3). |
| R01 | rumour - later shown false | DOC-1986-0055 | the director ran away from the town the first night | Phone log and shift log place him in the shelter from 02:10; family left with the evacuation. |
| R02 | rumour - never confirmed | DOC-1986-0055 | red wine helps against the radiation | No document confirms. |
| R03 | rumour - shown false | DOC-1986-0060 | a nuclear explosion of several megatons | Physically impossible per Nikitin. |
| R04 | rumour - unverified | DOC-1986-0102 | deliberately made to fail | Denied by vendor; never confirmed. |
| R05 | rumour - false | DOC-1986-0055 | home by the holidays | Evacuation became permanent. |
| N01 | numbers do not reconcile | DOC-1986-0073 | 70,461 | Official total of 10 Jun excludes Kozhukhivka (evacuated 14 Jun); CSV total 71,130; Vienna '~71,000'. |
| N02 | numbers do not reconcile | DOC-1987-0012 | 104,300 | 118,600 cards -> 104,300 records (merges ~9,600, unmatched ~4,700). |
| N03 | numbers do not reconcile | DOC-1986-0036 | 95 patients | 129 + 95 = 224 vs 237 hospitalized. |
| N04 | suspicious data | DOC-1987-0011 | 25.0 | Many doses exactly at the 25-rem limit (administrative entries). |
| N05 | unit without unit | DOC-1987-0016 | gross_beta | gross_beta column has no unit in the header. |
| A01 | ambiguous initials | DOC-1986-0052 | Maj. Morozov | 'V. Morozov' = Vladimir N. Morozov (dosimetry head) on 17 May; Major Vasily I. Morozov (military) from 18 May; b_recon_0518 is signed 'V. Morozov' but is the Major. |
| H03 | signature after availability (deliberate error) | DOC-1986-0062 | dosimetrist T. Myronenko | T. Mironenko (P38) was transferred to Clinic No. 4, Moscow on 17 May 1986 (PT-0012, ARS I) yet appears as signatory of the 27 May act at the station. |
| CE1 | censorship / official vs internal | DOC-1986-0043 | are not to be published | Directive restricting publication; see also c_health_secrecy. |
