# Gaps ledger

Facts referenced or implied but deliberately not documented. Correct answer: 'not documented'.

| ID | Missing fact | Where referenced | Note |
|---|---|---|---|
| G01 | The 1983 Dnestrovsk NPS start-up test report on the positive rod-insertion effect | DOC-1985-0011 | Referenced ('reference available at OKB-Kanal'); not in the corpus. |
| G02 | Reports of the 1982 and 1984 rundown tests (incl. ETS-84-117) | DOC-1985-0010 | Referenced by the 1985 report and the commission; never provided. |
| G03 | SIUR (senior reactor control engineer) log of Unit 4 for 00:00-01:30 on 17 May | DOC-1986-0048 | Not recovered. |
| G04 | Location/remains of V. Ostapenko | DOC-1986-0095 | MCP room inaccessible; not documented. |
| G05 | Doses received by bus drivers during the town evacuation | - | No document gives them. |
| G06 | Amount of dropped material that actually reached the reactor shaft | DOC-1986-0093 | 'cannot be determined'. |
| G07 | Who agreed (signed) the isolation of the ECCS in the test program | DOC-1986-0012 | Signature line blank. |
| G08 | Final cost of the Shelter | DOC-1987-0037 | 'has not yet been determined'. |
| G09 | Total area of openings in the Shelter | DOC-1987-0020 | Estimates 100-1,000 m2; not measured. |
| G10 | Names of the ~3,400 servicemen who cleared the Unit 3 roof | DOC-1986-0110 | 'Lists ... are kept in the units' - only a 60-row extract exists. |
| G11 | Whether OKB-Kanal received the test program | DOC-1986-0013 | 'No incoming registration at OKB-Kanal has been found.' |
| G12 | Thyroid doses to children of Vereskovsk | DOC-1986-0079 | 'in progress' - never reported. |
| G13 | Number of residents who left Vereskovsk by private car before the evacuation | DOC-1986-0041 | 'number unknown'. |
| G14 | Reason the town dose estimate changed from 3.3 to 1.5 rem | DOC-1986-0079 | Not documented. |
