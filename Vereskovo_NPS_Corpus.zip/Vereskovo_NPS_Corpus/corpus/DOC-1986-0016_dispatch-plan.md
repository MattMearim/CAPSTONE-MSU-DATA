---
doc_id: DOC-1986-0016
title: Republic Grid Dispatch Center: daily plan, 15-16 May 1986 (extract)
doc_type: dispatch plan
source_system: Republic Grid Dispatch Center
author: A. Ostrovsky
date: 1986-05-14
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ORG-0022
---

# Republic Grid Dispatch Center: daily plan, 15-16 May 1986 (extract)

DAILY OPERATING PLAN - 15/16.05.1986 (extract)

Vereskovo NPS:
- Unit 4: reduction from 23:00 on 15.05 for planned outage; disconnection from grid on 16.05 (time - by agreement with the dispatcher).
- Units 1-3: base load.

Note: reserve in the evening peak of 16.05 is limited (a unit of another station in the system is under emergency repair). Changes to disconnection times only with permission of the duty dispatcher.
