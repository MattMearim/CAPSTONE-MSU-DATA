---
doc_id: DOC-1987-0019
title: Trial record, day 3 (extract): testimony of A. G. Zuev and witnesses
doc_type: trial transcript
source_system: Supreme Court, off-site session (Lisove)
author: court secretary
date: 1987-07-09
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P03; P10; P18; P67; P50
---

# Trial record, day 3 (extract): testimony of A. G. Zuev and witnesses

RECORD OF THE COURT SESSION - 09.07.1987 (extract)

Defendant Zuev: The test began at about 01:30. After the AZ-5 the power jumped. There was an explosion at approximately 01:30-01:31; I did not look at the clock. I was told by the SIUR that the margin was at least 15 rods. I did not see the printout.

Prosecutor: The printout at 01:22:30 shows about 7 rods. Did you not ask?
Zuev: I asked; Lavrinenko said "enough". He is dead and cannot confirm or deny.

Prosecutor: The test was carried out at the station in 1982, 1984 and 1985.
Zuev: I knew of 1984 and 1985. I did not know of 1982; I was not responsible for it.

Witness Melnyk: Repeats his statement of 21.05.1986: Zuev insisted on continuing; Lavrinenko pressed AZ-5 when he saw the power rising.

Witness Babych (SIUR trainee): I stood behind Lavrinenko. At 01:22 he took the printout and said something like "seven or eight". He showed it to Tkachuk. I did not hear what Tkachuk answered. When the test started, Lavrinenko was watching the power; I think he pressed the button because the test was ending, then the power jumped - but I cannot say exactly in which order.

Witness Kuzmin: The oscillograph started at 01:31:04 by my watch. I did not participate in the discussions.

Witness Kalnysh (SIUR, evening shift): At handover at 00:05 the ORM was 16 rods according to the printout of 23:58. I told Lavrinenko the reactor was "heavy" because of the xenon.
