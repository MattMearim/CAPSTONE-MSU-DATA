---
doc_id: DOC-1987-0027
title: Republic Council of Ministers decision on additional resettlement
doc_type: decision
source_system: republic Council of Ministers
author: republic Council of Ministers
date: 1987-10-15
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: SET-014; SET-022
---

# Republic Council of Ministers decision on additional resettlement

DECISION (extract)
15.10.1987

1. On the basis of the results of the 1987 radiological survey, the village of Vilshanka (Olshanka), 38 km north of the station, is included in the list of settlements subject to resettlement in 1988.

2. In the village of Ruda Vereskivska, voluntary resettlement with compensation has been carried out since 1 September 1987; the village remains in the strict control zone.

3. In Petrivka and Novosilky, restrictions on private milk continue.
