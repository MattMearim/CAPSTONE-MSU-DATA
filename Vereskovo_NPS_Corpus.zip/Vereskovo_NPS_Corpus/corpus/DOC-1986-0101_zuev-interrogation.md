---
doc_id: DOC-1986-0101
title: Record of interrogation of A. G. Zuev (extract)
doc_type: interrogation record
source_system: procurator's office
author: investigator in charge
date: 1986-09-10
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P03; P07; PRJ-01
---

# Record of interrogation of A. G. Zuev (extract)

RECORD OF INTERROGATION OF THE ACCUSED (extract)
10.09.1986

Question: Who decided to continue the test after the power fell at 00:28?
Answer: The decision was taken by the shift supervisor of the unit, Tkachuk. I approved it. Nobody objected.

Question: Did you know that the ORM was below 15 rods?
Answer: No. The SIUR did not report it. Besides, the requirement of 15 rods in the regulations applies to operation at nominal power; at low power there was no such requirement.

Question: Why was the AZ-5 pressed?
Answer: It was pressed as planned at the end of the test, to shut down the reactor. There was no emergency before that.

Question: Had the test been done before?
Answer: Yes, twice before, on Unit 3 in 1984 and 1985. Both times it was safe. The test concerns the electrical part.
