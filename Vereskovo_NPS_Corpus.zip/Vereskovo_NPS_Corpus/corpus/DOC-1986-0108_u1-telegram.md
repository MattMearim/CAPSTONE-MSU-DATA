---
doc_id: DOC-1986-0108
title: Telegram: Unit 1 brought to minimum controlled power
doc_type: telegram
source_system: station chancellery
author: M. Yu. Belov
date: 1986-10-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U1-RCT-01
---

# Telegram: Unit 1 brought to minimum controlled power

TELEGRAM
TO: GOSKOMATOM MOSCOW
01.10.86 07:00

REACTOR OF UNIT 1 BROUGHT TO MINIMUM CONTROLLED POWER TODAY AT 03:15. ORM 48 RODS. EQUIPMENT NORMAL. POWER ASCENSION ACCORDING TO SCHEDULE. SYNCHRONIZATION OF TG-1 PLANNED 04.10.
DIRECTOR BELOV
