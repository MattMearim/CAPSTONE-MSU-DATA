---
doc_id: DOC-1987-0004
title: Act on completion of the sealing works of the Shelter
doc_type: act
source_system: SU-219
author: G. A. Aksyonov
date: 1987-02-27
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-06; SH-VENT-01
---

# Act on completion of the sealing works of the Shelter

ACT
27.02.1987

The works on sealing the joints of the roof and walls of the Shelter, listed in the acceptance act of 14.12.1986, were completed on 26.02.1987, except for the openings between the roof pipes in the area of axes 46-50, which are inaccessible.

The ventilation system operates; filters were replaced in February. The monitoring system has 21 of 32 planned sensors working.

Chief engineer of SU-219   G. Aksyonov
