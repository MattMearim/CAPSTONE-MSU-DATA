---
doc_id: DOC-1986-0008
title: Town radio schedule note (Vereskovsk radio center)
doc_type: internal note
source_system: Vereskovsk radio center
author: radio center duty editor
date: 1986-03-20
original_language: Ukrainian (translated)
classification: unclassified
status: approved
related_ids: SET-001
---

# Town radio schedule note (Vereskovsk radio center)

Vereskivsk radio center - schedule changes from 1 April 1986

- Morning program 07:00-07:30 (news, station shift results)
- Daytime 13:00-13:15 (announcements of the town executive committee)
- Evening 19:00-19:30

Civil defense test of sirens and loudspeaker network: first Wednesday of each month at 12:00.
