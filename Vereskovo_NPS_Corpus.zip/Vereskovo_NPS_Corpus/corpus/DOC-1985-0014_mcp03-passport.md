---
doc_id: DOC-1985-0014
title: Equipment passport entry: MCP-3 Unit 4 (repair record)
doc_type: equipment passport
source_system: reactor shop
author: reactor shop mechanic
date: 1985-11-25
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-MCP-03
---

# Equipment passport entry: MCP-3 Unit 4 (repair record)

PASSPORT OF PUMP MTsN-8K, serial 82-07-03, position U4-MCP-03

Repair record:

| Date | Work | Signature |
|---|---|---|
| 14.02.1984 | Seal inspection | (signed) |
| 06.09.1985 | Vibration above 7.1 mm/s; balancing of coupling | (signed) |
| 25.11.1985 | Lower bearing assembly replaced (improved type). Vibration after repair 2.7 mm/s | (signed) |

Rated flow: 8,000 m3/h. Head: 200 m.
