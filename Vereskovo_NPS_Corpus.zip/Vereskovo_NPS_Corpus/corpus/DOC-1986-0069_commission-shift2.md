---
doc_id: DOC-1986-0069
title: Order on the change of the chairman of the Government Commission
doc_type: order
source_system: Council of Ministers
author: Council of Ministers secretariat
date: 1986-06-03
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P27; P28
---

# Order on the change of the chairman of the Government Commission

EXTRACT FROM ORDER
03.06.1986

1. Comrade V. A. Demidov is appointed chairman of the Government Commission on the accident at Vereskovo NPS from 3 June 1986, replacing Comrade G. I. Zaitsev, who returns to Moscow.

2. The commission will work in rotation; members serve for approximately two weeks.
