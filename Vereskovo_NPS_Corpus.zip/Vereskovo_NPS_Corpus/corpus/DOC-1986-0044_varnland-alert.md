---
doc_id: DOC-1986-0044
title: Skarvik Nuclear Plant: internal radiation alert report
doc_type: incident report
source_system: Skarvik Nuclear Plant (Varnland)
author: L. Ekvall
date: 1986-05-19
original_language: English
classification: unclassified
status: approved
related_ids: ORG-0018
---

# Skarvik Nuclear Plant: internal radiation alert report

SKARVIK NUCLEAR PLANT - RADIATION PROTECTION
Internal alert report 86-14
19 May 1986

At 07:10 local time an employee arriving for the morning shift triggered the portal monitor at the plant entrance. Contamination was found on his shoes. Within 30 minutes several more employees arriving from outside triggered the monitors.

Initial assumption: a release from our own plant. Plant management ordered a check of all systems and evacuated non-essential staff from the site at 08:30.

By 10:00 no leak had been found in any of our systems. Samples of grass and air outside the site show the same contamination. Gamma spectrometry shows iodine-131, caesium-137, caesium-134, tellurium-132, ruthenium-103 - a mixture typical of reactor fuel, not of our plant's effluents.

Conclusion: the source is outside the plant and outside Varnland. Information passed to VRPI at 09:15.

L. Ekvall, Radiation Protection Supervisor
