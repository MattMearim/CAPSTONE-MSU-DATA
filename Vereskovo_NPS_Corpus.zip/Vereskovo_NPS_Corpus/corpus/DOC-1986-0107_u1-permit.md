---
doc_id: DOC-1986-0107
title: Goskomatom decision: permission to restart Unit 1
doc_type: decision
source_system: Goskomatom / GNI
author: A. G. Polishchuk
date: 1986-09-29
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U1-RCT-01; PRJ-07; PRJ-03
---

# Goskomatom decision: permission to restart Unit 1

DECISION
29.09.1986

1. The restart of Unit 1 of Vereskovo NPS (originally planned for 1 September 1986) is permitted from 29 September 1986, the following conditions having been fulfilled:
- installation of additional absorbers and modification of the control rods;
- introduction of the 1986 revision of the Technological Regulations (ORM not less than 30 rods);
- decontamination of the premises of Unit 1 to the established levels;
- retraining and examination of the operating personnel.

2. The power of the unit shall not exceed 3,000 MW (thermal) until additional approval.
