---
doc_id: DOC-1986-0098
title: Briefing for the International Nuclear Safety Forum, Vienna, 25-29 August 1986 (slide text)
doc_type: briefing slides
source_system: Soviet delegation (English text distributed at the meeting)
author: Soviet delegation (head: Ye. B. Nikitin)
date: 1986-08-27
original_language: English
classification: unclassified
status: approved
related_ids: U4-RCT-01
---

# Briefing for the International Nuclear Safety Forum, Vienna, 25-29 August 1986 (slide text)

THE ACCIDENT AT THE VERESKOVO NPS AND ITS CONSEQUENCES
Information compiled for the INSF experts' meeting

Slide 3 - The plant
- 4 units RBMK-type, 1,000 MWe each; Unit 4 in operation since 1984
- town 3.5 km from plant; population ~49,000

Slide 7 - Cause
- test of turbine rundown
- extremely improbable combination of violations of procedures by operators
- six main violations (see report)

Slide 9 - Power excursion
- prompt criticality; power ~100 x nominal in ~4 s
- 2 explosions

Slide 12 - Health consequences
- 2 deaths at the site on the night
- ~200 persons hospitalized
- 128 cases of acute radiation sickness confirmed
- 29 deaths from ARS (status mid-August)
- total deaths: 31

Slide 14 - Protective measures
- evacuation of ~71,000 persons from the 30-km zone and adjacent areas
- 30-km zone

Slide 17 - Release
- ~3-4% of core inventory, excluding noble gases (estimate)
