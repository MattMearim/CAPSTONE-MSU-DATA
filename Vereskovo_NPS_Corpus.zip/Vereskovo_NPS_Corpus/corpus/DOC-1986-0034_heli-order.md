---
doc_id: DOC-1986-0034
title: Order on dropping materials onto Unit 4 by helicopters
doc_type: order
source_system: commission / helicopter group staff
author: Col. V. Kharchenko
date: 1986-05-18
original_language: Russian (translated)
classification: secret
status: approved
related_ids: HEL-V8T; MAT-001; MAT-002; MAT-003; MAT-004; MAT-005
---

# Order on dropping materials onto Unit 4 by helicopters

ORDER No. 1 of the commander of the helicopter group
18.05.1986, 12:00

In accordance with the decision of the Government Commission, from 19:00 on 18.05 begin dropping materials into the shaft of the reactor of Unit 4.

Materials: sand and clay in bags (loaded at Lisove airfield by volunteers and soldiers), boron carbide, dolomite, lead.

Altitude over the target 110-200 m, speed 40-60 km/h; target - the glowing opening of the reactor shaft. Approach from the side of the ventilation stack.

Dose control of crews: each crew records the dose; crews with 25 R are removed from flights.

Commander   Col. V. Kharchenko
