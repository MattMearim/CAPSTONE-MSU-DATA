---
doc_id: DOC-1986-0079
title: Assessment of doses to the population of Vereskovsk before evacuation
doc_type: dosimetry assessment
source_system: commission medical/dosimetry group
author: V. N. Morozov
date: 1986-06-25
original_language: Russian (translated)
classification: secret
status: approved
related_ids: SET-001
---

# Assessment of doses to the population of Vereskovsk before evacuation

ASSESSMENT OF EXTERNAL DOSES TO THE POPULATION OF VERESKOVSK
25.06.1986

1. Basis: dose rate measurements in the town on 17-18 May (dosimetry service, military reconnaissance), time of stay 36 hours from the accident to evacuation, shielding factor of buildings 0.5.

2. Average external dose to the population: 1.5 rem. Maximum (north part, Komsomolskaya Street, persons outdoors): up to 8 rem.

3. Thyroid doses to children: assessment requires measurements of iodine-131 in the thyroid (in progress).
