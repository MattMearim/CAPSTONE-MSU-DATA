---
doc_id: DOC-1986-0110
title: Report on the completion of clearing of the Unit 3 roof
doc_type: report
source_system: army chemical defense unit
author: Capt. O. Panchenko
date: 1986-10-02
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P54; P55; ROB-MRK2-01
---

# Report on the completion of clearing of the Unit 3 roof

REPORT
02.10.1986

The clearing of zones "L" and "M" of the roof of Unit 3 was carried out from 20 September to 1 October 1986.

About 3,400 servicemen took part. Each made one, rarely two, exits onto the roof. Time on the roof 40-120 s. Fragments of graphite and fuel assemblies were thrown into the Unit 4 shaft with shovels.

Doses: individual doses for the exits were recorded by unit dosimetrists; no person exceeded the established limit. Lists of personnel by company are kept in the units.

Commander   Capt. O. Panchenko
