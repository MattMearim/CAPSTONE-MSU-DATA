---
doc_id: DOC-1986-0076
title: Order on suspension of construction of Units 5-6
doc_type: order
source_system: Goskomatom
author: A. G. Polishchuk
date: 1986-06-18
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-02; U5-RCT-01; P47
---

# Order on suspension of construction of Units 5-6

ORDER No. 302   18.06.1986

1. Suspend the construction of the third stage of Vereskovo NPS (Units 5 and 6).

2. The construction directorate of Units 5-6 (V. Klimenko) shall transfer personnel and equipment to SU-219 and to decontamination works.

3. The question of continuing construction will be considered after the end of the work on the elimination of the consequences of the accident.
