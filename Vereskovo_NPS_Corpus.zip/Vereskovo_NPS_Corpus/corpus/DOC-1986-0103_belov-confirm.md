---
doc_id: DOC-1986-0103
title: Goskomatom order No. 412-k: director of Vereskovo NPS
doc_type: order
source_system: Goskomatom
author: I. K. Antonov
date: 1986-09-15
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P05
---

# Goskomatom order No. 412-k: director of Vereskovo NPS

ORDER No. 412-k   15.09.1986

M. Yu. Belov is appointed director of Vereskovo NPS from 15 September 1986.

Chairman of Goskomatom   I. Antonov
