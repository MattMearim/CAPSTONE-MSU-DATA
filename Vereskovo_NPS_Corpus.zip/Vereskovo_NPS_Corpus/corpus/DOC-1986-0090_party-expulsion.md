---
doc_id: DOC-1986-0090
title: Regional Party committee bureau: decision on V. S. Hrytsenko and others
doc_type: Party decision
source_system: regional Party committee
author: regional Party committee bureau
date: 1986-07-14
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P01; P02; P03; P32
---

# Regional Party committee bureau: decision on V. S. Hrytsenko and others

DECISION OF THE BUREAU (extract)
14.07.1986

1. For gross mistakes and shortcomings in work which led to the accident with grave consequences, V. S. Hrytsenko is expelled from the Party.

2. N. I. Savchenko and A. G. Zuev - the question is postponed until the end of the investigation.

3. I. I. Gordienko (first secretary of the town Party committee) - severe reprimand for insufficient control and late information of the population.
