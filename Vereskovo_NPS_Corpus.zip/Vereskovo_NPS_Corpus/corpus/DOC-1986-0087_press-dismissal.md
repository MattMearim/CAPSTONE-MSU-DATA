---
doc_id: DOC-1986-0087
title: Sovetsky Vestnik: 'Personal responsibility' (article)
doc_type: newspaper article
source_system: Sovetsky Vestnik
author: G. Yakubovich
date: 1986-07-04
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: P01
---

# Sovetsky Vestnik: 'Personal responsibility' (article)

PERSONAL RESPONSIBILITY

At the end of June the director of the Vereskovo NPS, V. Gritsenko, was removed from his post. As the Government Commission found, the management of the station had allowed gross violations of the rules of operation of the reactor. The station's chief engineer has also been relieved of his duties.

Who allowed an experiment to be conducted without proper coordination? Why were the warnings of the inspectors ignored? These questions will be answered by the investigation.
