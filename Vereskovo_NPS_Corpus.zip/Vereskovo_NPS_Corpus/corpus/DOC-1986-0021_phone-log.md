---
doc_id: DOC-1986-0021
title: Telephone log of the civil defense shelter (bunker), 17 May 1986
doc_type: telephone log
source_system: station communications center
author: duty telephone operator
date: 1986-05-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01; P35
---

# Telephone log of the civil defense shelter (bunker), 17 May 1986

TELEPHONE LOG - SHELTER No. 1 (administrative building)
17.05.1986

| Time | From | To | Content (short) |
|---|---|---|---|
| 02:10 | Hrytsenko (in shelter) | Station shift supervisor | arrived in shelter; asked for situation |
| 02:25 | Hrytsenko | Town Party committee (Gordienko) | informed of fire and explosion in turbine hall |
| 03:00 | Hrytsenko | Goskomatom duty officer, Moscow | first report by phone |
| 03:45 | Hrytsenko | Goskomatom (telegram dictated) | telegram text No. 1 |
| 04:30 | Hrytsenko | Polishchuk (Goskomatom, deputy chairman, at home) | report; Polishchuk asks about reactor - "being cooled" |
| 06:15 | Hrytsenko | regional Party committee | situation report |
| 07:40 | Hrytsenko | MSU-41 Gerasimova | number of patients |
| 09:00 | Polishchuk (Moscow) | Hrytsenko | government commission formed; arrival in the evening |
