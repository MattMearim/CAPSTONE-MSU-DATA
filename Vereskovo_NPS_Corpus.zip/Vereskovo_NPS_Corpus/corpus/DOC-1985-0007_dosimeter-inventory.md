---
doc_id: DOC-1985-0007
title: Dosimetry service: inventory of radiation monitoring instruments (extract)
doc_type: equipment inventory
source_system: dosimetry service
author: V. N. Morozov
date: 1985-07-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: DOS-RKS4; DOS-VR1000-0012; DOS-DK02; DOS-IMD21
---

# Dosimetry service: inventory of radiation monitoring instruments (extract)

INVENTORY OF RADIATION MONITORING INSTRUMENTS - as of 01.07.1985 (extract)

| Type | Quantity | Range (passport) | Location |
|---|---|---|---|
| RKS-4 portable dose rate meter | 60 | 0.05-1 R/h and 1-4 R/h (two sub-ranges) | dosimetry rooms of Units 1-4 |
| VR-1000 high-range dose rate meter | 2 (No. 0011, No. 0012) | 1-1,000 R/h | No. 0011 - civil defense store; No. 0012 - safe of Unit 1 dosimetry room |
| DKP-20 pocket dosimeters | 2,400 | 0-200 mR | issued to personnel |
| RDV-21 (civil defense) | 12 | 0.1-500 R/h | civil defense shelter No. 1 |

Note: the VR-1000 instruments are kept locked as "emergency" instruments; the key to the Unit 1 safe is held by the dosimetry engineer on duty (day shift).

Head of dosimetry service   V. N. Morozov
