---
doc_id: DOC-1986-0013
title: Covering letter: TG-8 rundown test program sent to OKB-Kanal
doc_type: letter
source_system: station chancellery (outgoing)
author: A. G. Zuev
date: 1986-04-28
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-01; ORG-0004
---

# Covering letter: TG-8 rundown test program sent to OKB-Kanal

To: OKB-Kanal, department of operation support
No. 03-588   28.04.1986

We send for your information the working program of the TG-8 rundown test (Rev. 1), approved by the chief engineer of the station on 22.04.1986. The test is planned for 16 May 1986.

Deputy Chief Engineer   A. Zuev

[Archive stamp: "Sent 29.04.86". No incoming registration at OKB-Kanal has been found.]
