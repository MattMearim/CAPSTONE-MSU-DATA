---
doc_id: DOC-1986-0111
title: Acceptance act: replacement robot MRK-2
doc_type: acceptance act
source_system: NIIKRE robotics laboratory
author: V. Chernov
date: 1986-10-03
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ROB-MRK2-01
---

# Acceptance act: replacement robot MRK-2

ACCEPTANCE ACT
03.10.1986

A robot MRK-2 (factory number 0007) was received from NIIKRE for work on the roofs. It is registered in the equipment list of the work under the existing number ROB-MRK2-01.

The robot will be used for the clearing of the roof of the ventilation block and for television inspection.
