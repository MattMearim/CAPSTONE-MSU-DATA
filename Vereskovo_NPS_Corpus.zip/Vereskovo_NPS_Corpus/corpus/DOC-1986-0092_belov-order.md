---
doc_id: DOC-1986-0092
title: Goskomatom order No. 349-k: acting director of Vereskovo NPS
doc_type: order
source_system: Goskomatom
author: A. G. Polishchuk
date: 1986-07-28
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P05; P06
---

# Goskomatom order No. 349-k: acting director of Vereskovo NPS

ORDER No. 349-k   28.07.1986

1. M. Yu. Belov, deputy chief engineer of Dnestrovsk NPS, is appointed acting director of Vereskovo NPS from 28 July 1986.

2. S. L. Bondar is released from temporarily performing the duties of director and continues in his post of deputy director.

Deputy Chairman   A. Polishchuk
