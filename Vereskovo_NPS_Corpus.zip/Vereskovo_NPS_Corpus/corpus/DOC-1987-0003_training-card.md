---
doc_id: DOC-1987-0003
title: Training center reference card: units and limits (for retraining of personnel)
doc_type: reference card
source_system: training center
author: A. Danilchenko
date: 1987-02-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-03
---

# Training center reference card: units and limits (for retraining of personnel)

REFERENCE CARD - RETRAINING 1987

Radiation units:
- 1 rem = 0.01 Sv (sievert); 1 rad = 0.01 Gy (gray)
- for gamma radiation, in practice 1 R (roentgen) is taken as about 1 rem (0.96 rem in soft tissue)
- 1 micro-roentgen per second (uR/s) = 3.6 milliroentgen per hour (mR/h)
- 1 Ci (curie) = 3.7 x 10^10 Bq (becquerel); 1 Ci/km2 = 37 kBq/m2

Pressure: 1 kgf/cm2 = 0.0981 MPa (approximately 1 atmosphere)

Limits (1987):
- annual dose limit for participants in work in the zone: 10 rem
- ORM of Units 1-3: not less than 30 rods (shutdown below 30)
- operation below 700 MW thermal prohibited except start-up and shutdown

Remember: the ORM is now shown continuously on the SIUR panel. If in doubt - shut down.
