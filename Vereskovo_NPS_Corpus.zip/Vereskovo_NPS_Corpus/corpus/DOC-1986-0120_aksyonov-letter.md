---
doc_id: DOC-1986-0120
title: Letter of G. A. Aksyonov to the deputy chairman of Goskomatom
doc_type: letter
source_system: SU-219
author: G. Aksenov
date: 1986-12-11
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-06; SH-BEAM-B1
---

# Letter of G. A. Aksyonov to the deputy chairman of Goskomatom

Aleksei Grigorievich,

I report informally before the official act. We closed the last opening of the roof on the 9th, late in the evening. The people are exhausted. The commission insists on signing the acceptance act on the 14th - the paperwork, measurements of the ventilation and the monitoring system will take until then.

The girder B1 stands well (installed 28 October). What worries me is the west wall of the unit: we rest on it and we do not know its condition inside. Also there are openings in the roof between the pipes that we could not seal - the total area I cannot tell you, we could not measure it. Some say a thousand square metres, I would not sign that number.

The final cost will be about twice the June estimate.

G. Aksyonov
