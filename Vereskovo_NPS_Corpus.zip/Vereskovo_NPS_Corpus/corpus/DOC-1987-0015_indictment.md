---
doc_id: DOC-1987-0015
title: Indictment in the case of the accident at Vereskovo NPS (summary)
doc_type: indictment
source_system: procurator's office
author: procurator
date: 1987-06-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01; P02; P03; P11; P14; P15
---

# Indictment in the case of the accident at Vereskovo NPS (summary)

INDICTMENT (summary)
20.06.1987

Accused:
1. V. S. Hrytsenko, former director;
2. N. I. Savchenko, former chief engineer;
3. A. G. Zuev, former deputy chief engineer;
4. G. A. Morozov, former station shift supervisor;
5. O. D. Sidorenko, former head of reactor shop No. 2;
6. K. Ye. Fedorov, former state inspector.

The accused are charged with violations of safety rules at an explosion-hazardous enterprise and with negligence, which resulted in the accident of 17 May 1986, the deaths of people and damage to the health of many persons.

The case is to be heard by the Supreme Court in an off-site session in Lisove from 6 July 1987.
