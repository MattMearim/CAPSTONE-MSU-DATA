---
doc_id: DOC-1986-0037
title: Town executive committee duty log, 18 May 1986
doc_type: duty log
source_system: Vereskovsk town executive committee
author: N. F. Makarenko
date: 1986-05-18
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: SET-001; SET-006
---

# Town executive committee duty log, 18 May 1986

DUTY LOG - 18.05.1986

09:50 Decision of the Government Commission - evacuation from 14:00.
11:30 Meeting of housing offices and school directors - lists of residents by building.
13:10 Announcement read on radio.
13:40 Announcement repeated.
14:00 First columns of buses at microdistricts 1 and 2.
15:20 Problem: not enough buses for microdistrict 4 - extra 60 buses from Zhitniki.
16:40 Last column left. Town empty except police, station staff, sick (hospital being evacuated separately).
17:30 Verbovka settlement - part of families left with the town columns, the remainder (approx. 40 people) remain - to be taken 21.05 with the villages.
