---
doc_id: DOC-1986-0011
title: Plan of the 1986 planned maintenance outage of Unit 4
doc_type: maintenance plan
source_system: production-technical department
author: A. G. Zuev
date: 1986-04-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-01; U4-RCT-01; U4-MCP-03
---

# Plan of the 1986 planned maintenance outage of Unit 4

PLAN - PLANNED MAINTENANCE OUTAGE OF UNIT 4, 1986

Start of power reduction: 23:00 on 15 May 1986
Shutdown of reactor: 16 May 1986 (after completion of the TG-8 rundown test)
Duration of outage: 42 days

Main works:
- inspection of the graphite stack and channel measurements (NIIKRE)
- repair of drum separator level gauges
- vibration diagnostics and inspection of MCP-1 to MCP-8
- installation of modified excitation regulator (before the test)
- calibration of in-core detectors

Tests before shutdown:
- TG-8 rundown test (program approved separately)
- vibration test of TG-8
