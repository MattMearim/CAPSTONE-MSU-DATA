---
doc_id: DOC-1986-0033
title: Text of the radio announcement to the population of Vereskovsk
doc_type: announcement
source_system: Vereskovsk radio center
author: town executive committee
date: 1986-05-18
original_language: Ukrainian (translated)
classification: unclassified
status: approved
related_ids: SET-001
---

# Text of the radio announcement to the population of Vereskovsk

Attention, attention! Dear comrades!

The town council of people's deputies announces that in connection with the accident at the Vereskovo nuclear power station an unfavourable radiation situation is developing in the town. Party and Soviet bodies and military units are taking the necessary measures.

To ensure complete safety of people, and first of all children, it is necessary to carry out a temporary evacuation of the residents of the town to nearby settlements of the region. For this purpose buses will be provided today, 18 May, from 14:00 to each residential building, accompanied by police officers and representatives of the town executive committee.

Take with you documents, the most necessary things and food for the first three days.

Comrades, when leaving your homes, do not forget to close the windows, turn off the electrical and gas appliances and close the water taps.

Please keep calm, organization and order during the temporary evacuation.

[Read on the town radio at 13:10, repeated at 13:40 and 14:10.]
