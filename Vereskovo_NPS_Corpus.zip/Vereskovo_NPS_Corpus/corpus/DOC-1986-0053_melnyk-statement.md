---
doc_id: DOC-1986-0053
title: Statement of I. S. Melnik (recorded in Clinic No. 4)
doc_type: witness statement
source_system: procurator's office (copy in commission files)
author: I. S. Melnik
date: 1986-05-21
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P10; P03; P07; P08
---

# Statement of I. S. Melnik (recorded in Clinic No. 4)

STATEMENT
Recorded 21.05.1986, Clinic No. 4, ward 8. Recorded by investigator of the procurator's office.

I am senior turbine control engineer of Unit 4. At about midnight we took over the shift. The power was being reduced. At the transfer of the regulator the power fell almost to zero. Lavrinenko said he could not hold it. Tkachuk said we should stop. The deputy chief engineer Zuev insisted that we continue and raise the power, he said if we do not do the test now we will wait another year. He was shouting.

They raised the power to about 200. At about 01:30 we started the test, I closed the stop valves of the eighth turbine on the command of the shift supervisor. After some seconds Lavrinenko shouted that the power was rising and pressed the AZ button. Then there was a shock, a second one, and the lights went out.

I did not see the printout of the margin. Lavrinenko said earlier that the margin was small, but I did not hear the number.
