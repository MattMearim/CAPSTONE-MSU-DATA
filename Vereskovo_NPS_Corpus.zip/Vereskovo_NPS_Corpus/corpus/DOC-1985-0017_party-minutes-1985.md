---
doc_id: DOC-1985-0017
title: Minutes of the station Party committee meeting, 27 December 1985
doc_type: meeting minutes
source_system: station Party committee
author: Party committee secretary
date: 1985-12-27
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01; P02; PRJ-02
---

# Minutes of the station Party committee meeting, 27 December 1985

MINUTES No. 24 of the meeting of the Party committee of Vereskovo NPS
27 December 1985

Present: 21 members. Invited: Comrade I. I. Gordienko (town Party committee).

1. On the results of 1985.
Comrade Hrytsenko V. S. reported: the plan for electricity generation will be fulfilled by 101%. Unit 4 lost output in November due to the repair of a main circulation pump.

Comrade Gordienko noted that the construction of the third stage is behind schedule and that the director must strengthen control over contractors.

Comrade Savchenko N. I. reported on the remarks of the State Inspectorate. Measures are being worked out. In the discussion it was said that some of the remarks are formal.

2. Decided:
- note the satisfactory fulfillment of the plan;
- oblige Comrade Hrytsenko to take personal control of the Units 5-6 schedule;
- oblige the chief engineer to complete the measures on the Inspectorate act by 1 March 1986.
