---
doc_id: DOC-1986-0006
title: Order No. 56 on the composition of operating shifts, Units 3-4
doc_type: order
source_system: station director's office
author: V. S. Hrytsenko
date: 1986-03-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P07; P49; P36; P11
---

# Order No. 56 on the composition of operating shifts, Units 3-4

ORDER No. 56   01.03.1986
On the composition of operating shifts of Units 3 and 4

1. Operation of Units 3 and 4 is carried out by five shifts working 8-hour watches according to the schedule (00:00-08:00, 08:00-16:00, 16:00-24:00).

2. Shift supervisors of Unit 4:
- Shift 1: S. Danilov
- Shift 2: V. Kostenko
- Shift 3: A. Panasiuk
- Shift 4: I. Romanov
- Shift 5: Yu. M. Tkachuk

3. Shift supervisor of Unit 3 (Shift 5): Ye. Nazarenko.

4. Station shift supervisor for shifts 4 and 5: G. A. Morozov.

5. Senior reactor control engineers of Unit 4: Shift 4 - M. Kalnysh; Shift 5 - A. V. Lavrinenko (from 15.11.1985).

Director   V. Hrytsenko
