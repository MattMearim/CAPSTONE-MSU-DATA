---
doc_id: DOC-1986-0091
title: Report of the Government Commission on the causes of the accident at Unit 4 (main conclusions)
doc_type: commission report
source_system: Government Commission
author: Government Commission (working group led by Ye. B. Nikitin)
date: 1986-07-20
original_language: Russian (translated)
classification: secret
status: approved
related_ids: U4-RCT-01; U4-CPS-01; U4-EPS-01; PRJ-01; U4-MCP-03
---

# Report of the Government Commission on the causes of the accident at Unit 4 (main conclusions)

REPORT ON THE CAUSES OF THE ACCIDENT AT UNIT 4 OF VERESKOVO NPS
(main conclusions) - 20.07.1986

1. The accident occurred on 17 May 1986 during the test of the rundown of turbine-generator No. 8, in the course of the shutdown of Unit 4 for planned maintenance.

2. Sequence (based on the Vega-M records, the logs and statements):
- 15.05, 23:00 - start of power reduction; 16.05, 13:05 - TG-7 disconnected at 1,600 MW; 14:00 - emergency core cooling system disconnected; the grid dispatcher delayed further reduction until 23:10;
- 17.05, 00:28 - when switching the automatic regulators, the power fell to about 30 MW (thermal);
- the operators withdrew rods; by 01:03 the power was stabilized at about 200 MW, well below the 700-1,000 MW required by the program;
- at 01:05 two additional main circulation pumps were started; total flow exceeded the regulations;
- at 01:22:30 the operating reactivity margin was 6-8 rods (Vega-M), half of the permitted minimum;
- at 01:31:05 the stop valves of TG-8 were closed; at 01:31:41 the AZ-5 button was pressed;
- at 01:31:44 the power rose sharply; at about 01:31:45 and about 01:31:48 two explosions occurred.

3. The power excursion was estimated to have reached about 100 times the nominal power within about 4 s.

4. The main cause of the accident was an extremely improbable combination of violations of the operating procedures by the personnel:
(1) operation with an operating reactivity margin below 15 rods;
(2) conducting the test at a power level lower than that specified in the program;
(3) connecting all main circulation pumps with excessive flow;
(4) disconnecting the emergency core cooling system;
(5) blocking the protection signals on drum separator level and pressure and on the shutdown of both turbines;
(6) continuing the test despite the deviation of conditions.

5. The rundown test program was of poor quality, was not agreed with the chief designer and the State Inspectorate, and had been carried out previously at the station in 1982, 1984 and 1985 without proper analysis.

6. The hypothesis of cavitation of the main circulation pumps as the initiating event was examined and not confirmed by the recorded flows.

7. The design of the reactor has features (positive void coefficient at the given burnup; the design of the control rods) that made the consequences of the violations more severe. Measures to improve the design are being developed (see separate decision).

8. The SIUR operating log for 00:00-01:30 was not recovered; the reconstruction is based on the computer records and other logs.
