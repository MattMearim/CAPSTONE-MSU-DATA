---
doc_id: DOC-1986-0035
title: Note on iodine prophylaxis in Vereskovsk
doc_type: medical note
source_system: Medical-Sanitary Unit No. 41
author: Dr. L. P. Gerasimova
date: 1986-05-18
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: MAT-007; SET-001
---

# Note on iodine prophylaxis in Vereskovsk

To: Government Commission (medical group)
18.05.1986

1. Potassium iodide tablets were issued to station personnel from 06:00 on 17.05.

2. In the town, distribution through the housing offices did not begin on 17.05. On 18.05 tablets were given in schools and kindergartens in the morning (about 6,000 children) and to residents at assembly points during the evacuation where stocks allowed.

3. Effectiveness of prophylaxis given more than 24 hours after the start of intake of iodine is considerably reduced.

Head of MSU-41   L. Gerasimova
