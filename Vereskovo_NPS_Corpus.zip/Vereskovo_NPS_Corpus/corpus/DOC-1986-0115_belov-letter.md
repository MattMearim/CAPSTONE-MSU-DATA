---
doc_id: DOC-1986-0115
title: Letter of the director M. Yu. Belov to the collective of the station
doc_type: letter
source_system: station director's office
author: M. Belov
date: 1986-10-20
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: P05
---

# Letter of the director M. Yu. Belov to the collective of the station

DEAR COMRADES!

Since my appointment as director of the station on 1 September, I have had the opportunity to meet many of you at the station and in Berezovy Gai.

Unit 1 is in operation. Unit 2 will follow in November. Unit 3 will require more time because of its proximity to the Shelter; we expect to restart it in the spring of next year.

I want to thank everyone who stayed at the station in the hardest days.

Director   M. Belov
