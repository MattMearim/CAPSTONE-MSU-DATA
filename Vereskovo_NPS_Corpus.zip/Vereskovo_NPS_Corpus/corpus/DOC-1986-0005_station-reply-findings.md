---
doc_id: DOC-1986-0005
title: Station response to Inspectorate act No. 85-37
doc_type: letter
source_system: chief engineer's office
author: N. I. Savchenko
date: 1986-02-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ORG-0005
---

# Station response to Inspectorate act No. 85-37

To: Resident State Inspector K. Ye. Fedorov
No. 01-412   20.02.1986

On act No. 85-37

1. Item 1: The cases of 8 and 23 October were caused by the delay of the computer calculation. Measured rod positions at the time showed a margin of 16-17 rods. Senior reactor control engineers have been instructed again. Item considered closed.

2. Item 2: The program of the rundown test for Unit 4 will be sent to the chief designer for information.

3. Item 3: Exercises on low-power operation will be included in the training program from 1987.

4. Item 4: Measures on diesel generators are under consideration together with the rundown test.

Chief Engineer   N. I. Savchenko
