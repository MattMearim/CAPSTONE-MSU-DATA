---
doc_id: DOC-1987-0005
title: Ministry of Health order on the all-union registry of persons exposed as a result of the accident
doc_type: order
source_system: Ministry of Health
author: Ministry of Health
date: 1987-03-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-09
---

# Ministry of Health order on the all-union registry of persons exposed as a result of the accident

ORDER (extract)
01.03.1987

1. An all-union registry of persons who took part in the elimination of the consequences of the accident at Vereskovo NPS and of evacuated persons is established.

2. Each person is assigned a registry number in the format VR87-RR-NNNNN, where RR is the code of the registering region.

3. Personal record cards issued in 1986 (format L86-######) are converted into the new registry by 30 June 1987. The 1986 number is recorded in the field "previous number".
