---
doc_id: DOC-1985-0008
title: Supplier evaluation: Severny Pump Plant (MTsN-8K main circulation pumps)
doc_type: supplier evaluation
source_system: centralized repair shop
author: N. Prokopenko
date: 1985-08-15
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ORG-0008; U4-MCP-03
---

# Supplier evaluation: Severny Pump Plant (MTsN-8K main circulation pumps)

EVALUATION OF SUPPLIER - SEVERNY PUMP PLANT
Period: 1983-1985

1. Supplied: main circulation pumps MTsN-8K for Units 3 and 4 (16 pumps), spare bearing assemblies.

2. Defects:
- Bearing housing of batch 82-07 (pumps of Unit 4, left loop) - increased vibration after 12-18 months of operation. Plant acknowledged the defect (letter 1258 of 03.07.85) and promises improved bearings in Q4 1985.
- Seal leakage on two pumps of Unit 3 (repaired under warranty).

3. Delivery discipline: satisfactory.

4. Conclusion: supplier remains approved. Improved bearing assemblies to be installed during the next repair of MCP-3 of Unit 4.

Head of the centralized repair shop   M. Prokopenko
