---
doc_id: DOC-1986-0026
title: Unit 3 shift handover note, 08:00, 17 May 1986
doc_type: handover note
source_system: Unit 3 control room
author: Ye. Nazarenko
date: 1986-05-17
original_language: Russian (translated)
classification: unknown
status: unknown
related_ids: U3-RCT-01; U34-VS-01
---

# Unit 3 shift handover note, 08:00, 17 May 1986

U3 handover 08:00 17/5 - Nazarenko -> Shift 1

- Reactor shut down 05:15 (manual, AZ). Cooling down normal. Pumps 2+2.
- Roof U3 - fire out (FU-7 says 06:35). Debris (graphite?) on roof near stack. DON'T go up.
- Ventilation U3 switched off 02:40 (air from U4 side).
- Dose CR U3: 0.6 R/h at 03:10, higher now. Asked for iodine at 02:00 - got it at 06:00.
- Staff: Babich and 3 others to MSU.
- Spoke to NSS Morozov - no orders on evacuating U3 staff yet.
- Log in book. Everything written.
