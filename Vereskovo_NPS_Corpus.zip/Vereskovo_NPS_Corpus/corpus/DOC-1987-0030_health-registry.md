---
doc_id: DOC-1987-0030
title: Health monitoring registry: annual report 1987 (summary)
doc_type: registry report
source_system: health monitoring registry
author: Dr. L. P. Gerasimova
date: 1987-11-02
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-09
---

# Health monitoring registry: annual report 1987 (summary)

ANNUAL REPORT 1987 (summary)

1. Persons in the registry (VR87 format): participants in the work - 104,300 converted from 1986 plus 41,200 registered in 1987; evacuated persons - 71,130.

2. Persons who had acute radiation sickness in 1986 (128): under annual examination; 98 surviving persons examined in 1987.

3. Thyroid examinations of children evacuated from the 30-km zone: 11,900 examined; follow-up continues.

4. The registry has no reliable dose data for about 6% of participants of 1986.
