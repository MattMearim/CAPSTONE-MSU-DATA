---
doc_id: DOC-1987-0035
title: OKB-Kanal: comments on the report of the GNI working group of 20.11.1987
doc_type: letter
source_system: OKB-Kanal
author: B. K. Levchenko
date: 1987-12-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-03; ORG-0004
---

# OKB-Kanal: comments on the report of the GNI working group of 20.11.1987

To: Chairman of the State Nuclear Safety Inspectorate
No. 4/2210   10.12.1987

The bureau does not agree with the conclusions of the working group.

1. The reactor was brought into a state not provided for by the design and the regulations; the decisive factor was the actions of the personnel, as established by the Government Commission and confirmed by the court.

2. The void coefficient values given in the report are the result of calculations with a model that has not been verified.

3. The improvements to the reactor introduced in 1986-1987 were made to increase the margins of safety, not because the design was faulty.

Chief Designer   B. Levchenko
