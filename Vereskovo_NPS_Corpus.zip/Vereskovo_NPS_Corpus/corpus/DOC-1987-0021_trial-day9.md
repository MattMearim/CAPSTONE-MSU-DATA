---
doc_id: DOC-1987-0021
title: Trial record, day 9 (extract): testimony of the designers
doc_type: trial transcript
source_system: Supreme Court, off-site session (Lisove)
author: court secretary
date: 1987-07-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P33; P34; PRJ-03
---

# Trial record, day 9 (extract): testimony of the designers

RECORD OF THE COURT SESSION - 17.07.1987 (extract)

Witness Levchenko (chief designer): The reactor is safe when operated according to the regulations. The personnel reduced the margin to 7 rods, against the minimum of 15. No reactor can be protected against such actions.

Defence counsel (for Zuev): Was the station informed of the positive effect of rod insertion?
Levchenko: The bureau considered the effect insignificant at the required margin.

Witness Yarosh (NIIKRE): In October 1985 our laboratory sent a memorandum on this effect to the chief designer and to three stations, including Vereskovo. The chief designer replied that no additional instructions were necessary.
Presiding judge: The court is examining the actions of the defendants, not the design of the reactor. Questions on design are not relevant.

Defence counsel: The memorandum is attached to the case file at the request of the defence.
