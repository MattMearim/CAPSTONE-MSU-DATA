---
doc_id: DOC-1986-0095
title: Cadres department: record on V. Ostapenko
doc_type: personnel record
source_system: cadres department
author: V. S. Kuzmina
date: 1986-08-12
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P16
---

# Cadres department: record on V. Ostapenko

RECORD (extract from personal file)
12.08.1986

Ostapenko Valery, personnel No. VNPS-01102, MCP operator of Unit 4, on duty on 17.05.1986.

Status: not found after the accident. The search in accessible rooms of Unit 4 gave no result. The MCP room (left side) is under the debris of the destroyed building and is inaccessible.

On the basis of the decision of the district court of 12.08.1986, V. Ostapenko is declared dead. The family receives the pension for loss of the breadwinner.
