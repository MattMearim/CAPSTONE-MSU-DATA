---
doc_id: DOC-1987-0032
title: Report of the GNI working group: analysis of the causes of the accident at Unit 4 (revised)
doc_type: commission report
source_system: State Nuclear Safety Inspectorate working group
author: GNI working group (lead author I. V. Yarosh)
date: 1987-11-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-RCT-01; U4-CPS-01; U4-EPS-01; U4-PC-01; PRJ-03; U4-MCP-03
---

# Report of the GNI working group: analysis of the causes of the accident at Unit 4 (revised)

ANALYSIS OF THE CAUSES OF THE ACCIDENT AT UNIT 4 OF VERESKOVO NPS
Report of the working group of the State Nuclear Safety Inspectorate
20.11.1987

1. Purpose. The working group re-examined the conclusions of the report of the Government Commission of 20.07.1986 on the basis of the decoded Vega-M records, new calculations and the materials of the trial.

2. Timing. The Vega-M clock and the record of the seismic station at Zhitniki (event at 01:31:46, local time) agree within 1 s. The two explosions occurred at about 01:31:45 and 01:31:48. The time "01:32" in the shift supervisor log is a rounded entry made after the event.

3. Design deficiencies:
3.1 Positive void coefficient. At the burnup of the Unit 4 core in May 1986, the void coefficient of reactivity was strongly positive (about +4.5 beta for complete voiding), several times larger than stated in the design documentation. At low power and high coolant flow, the core was close to boiling and highly sensitive to void formation.
3.2 Control rods. Rods withdrawn to the upper position had graphite displacers 4.5 m long with water columns of about 1.25 m below them. On insertion, the water was first displaced from the lower part of the core, adding positive reactivity. With the axial power peaked in the lower part of the core and very few rods inserted, the AZ-5 actuation added reactivity instead of removing it in the first seconds. This effect had been reported by NIIKRE in October 1985.
3.3 The ORM was not displayed continuously; the operators received it every 5-10 minutes on request. The regulations did not explain that the 15-rod limit was a condition of the effectiveness of the emergency protection.

4. Operator actions. Several of the "violations" listed in 1986 were not prohibited by the regulations in force (operation of eight main circulation pumps within the flow limits; operation below 700 MW was "not recommended", not prohibited). Operation with an ORM below 15 rods was a violation; however, its safety significance was not explained to the personnel.

5. Conclusion. The accident was caused by deficiencies of the reactor design, which made a power excursion possible under conditions that the personnel could reach, in combination with the actions of the personnel. The 1986 conclusion that the main cause was the violations of the personnel is not supported in full.

6. Not established:
6.1 The peak power cannot be determined; the instruments saturated. Estimates from 10 to more than 100 times nominal are found in the literature.
6.2 The nature of the second explosion (hydrogen-air, a second power excursion, or steam) is not established.
6.3 Whether the AZ-5 was pressed as a planned end of the test or in response to a rise of power is not established from the records.
6.4 Cavitation of the main circulation pumps did not play a decisive role.
