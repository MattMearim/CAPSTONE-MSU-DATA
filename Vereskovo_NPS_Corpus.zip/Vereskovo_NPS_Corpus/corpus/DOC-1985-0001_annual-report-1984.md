---
doc_id: DOC-1985-0001
title: Annual report of Vereskovo NPS for 1984 (summary section)
doc_type: annual report
source_system: station archive
author: V. S. Hrytsenko
date: 1985-01-28
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U1-RCT-01; U2-RCT-01; U3-RCT-01; U4-RCT-01; U5-RCT-01
---

# Annual report of Vereskovo NPS for 1984 (summary section)

VERESKOVO NUCLEAR POWER STATION
ANNUAL REPORT FOR 1984 - SUMMARY

1. The station generated 27.6 billion kWh in 1984, which is 104.1% of the plan. All four power units were in operation.

2. Unit 4 was commissioned in December 1983 and reached its design capacity in 1984. The unit was connected to the grid on 22 December 1983.

3. The socialist obligation of the collective for 1984 has been fulfilled. The station has been awarded the challenge banner of the Committee.

4. Construction of the third stage (Units 5 and 6) is under way. Commissioning of Unit 5 is scheduled for 1988 in accordance with the five-year plan. The general contractor and Spetsmontazh Trust No. 3 report lagging of 3-4 months on the reactor building of Unit 5.

5. Main tasks for 1985:
- fulfill the generation plan of 28.0 billion kWh;
- complete the planned maintenance of Units 1 and 4;
- carry out the turbine-generator rundown test program on Unit 3;
- improve discipline in the shifts.

Director of the station   V. S. Hrytsenko
