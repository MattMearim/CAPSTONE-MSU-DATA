---
doc_id: DOC-1987-0012
title: Registry office: report on the conversion of 1986 cards into the all-union registry
doc_type: registry report
source_system: registry office, Lisove
author: registry office
date: 1987-05-15
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-09
---

# Registry office: report on the conversion of 1986 cards into the all-union registry

REPORT
15.05.1987

1. Cards of 1986 (L86 format) received for conversion: 118,600.

2. Registry records created in the VR87 format: 104,300.

3. Differences:
- cards identified as duplicates of the same person and merged: about 9,600;
- cards that could not be matched to a person (illegible, no date of birth): about 4,700.

4. In a number of units the recorded doses are exactly 25.0 rem for many persons. Such records are suspected of having been entered administratively (the limit value) and not from dosimeter readings. They are marked for verification.
