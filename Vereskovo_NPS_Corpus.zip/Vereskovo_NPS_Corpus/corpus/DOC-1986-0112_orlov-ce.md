---
doc_id: DOC-1986-0112
title: Goskomatom order No. 431-k: chief engineer of Vereskovo NPS
doc_type: order
source_system: Goskomatom
author: A. G. Polishchuk
date: 1986-10-06
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P04
---

# Goskomatom order No. 431-k: chief engineer of Vereskovo NPS

ORDER No. 431-k   06.10.1986

P. A. Orlov is appointed chief engineer of Vereskovo NPS from 6 October 1986.

Deputy Chairman   A. Polishchuk
