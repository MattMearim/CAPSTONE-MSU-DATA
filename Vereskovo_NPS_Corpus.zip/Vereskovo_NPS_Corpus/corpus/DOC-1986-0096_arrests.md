---
doc_id: DOC-1986-0096
title: Procurator's office: information on the criminal case concerning the accident
doc_type: procurator's information
source_system: procurator's office
author: investigator in charge
date: 1986-08-14
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P01; P02; P03; P11; P14; P15
---

# Procurator's office: information on the criminal case concerning the accident

INFORMATION
14.08.1986

A criminal case was opened on 19.05.1986 under the articles on violation of safety rules at explosive enterprises and on negligence.

Arrested:
- 13.08.1986 - V. S. Hrytsenko, former director;
- 14.08.1986 - N. I. Savchenko, former chief engineer; A. G. Zuev, deputy chief engineer; G. A. Morozov, station shift supervisor; O. D. Sidorenko, head of reactor shop No. 2; K. Ye. Fedorov, state inspector.

Zuev is under guard in hospital treatment after acute radiation sickness.
