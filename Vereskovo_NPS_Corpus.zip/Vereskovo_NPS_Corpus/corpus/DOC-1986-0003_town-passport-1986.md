---
doc_id: DOC-1986-0003
title: Vereskovsk town executive committee: population on 1 January 1986
doc_type: municipal statistics
source_system: Vereskovsk town executive committee
author: N. F. Makarenko
date: 1986-02-05
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: SET-001
---

# Vereskovsk town executive committee: population on 1 January 1986

INFORMATION on the population of the town of Vereskivsk as of 1 January 1986

Permanent population: 47,800 people
of which children and adolescents under 18: 17,400
Temporary residents (construction workers in hostels): approx. 2,100 (not included above)

Chair of the town executive committee   N. Makarenko
