---
doc_id: DOC-1986-0124
title: Medical summary on persons affected in the accident (status 15 December 1986)
doc_type: medical summary
source_system: Medical-Sanitary Unit No. 41 (with Clinic No. 4)
author: Dr. L. P. Gerasimova
date: 1986-12-20
original_language: Russian (translated)
classification: secret
status: approved
related_ids: PRJ-09; ORG-0020; ORG-0021
---

# Medical summary on persons affected in the accident (status 15 December 1986)

SUMMARY - status 15.12.1986

1. Hospitalized from 17 to 19 May 1986: 237 persons (Clinic No. 4, Moscow: 129; Republic Radiology Hospital, Kyiv: 108).

2. Acute radiation sickness confirmed: 128 persons (degree I - 43, II - 43, III - 21, IV - 21).

3. Deaths from ARS: 30, of which 29 in Clinic No. 4 and 1 in the Kyiv hospital (9 July 1986). The official figure of 29 deaths from ARS does not include the Kyiv case, which was registered by the Kyiv hospital with a different primary diagnosis.

4. Deaths on the night of the accident: 2 (N. Shevchuk - died in MSU-41 at 06:00 on 17 May; V. Ostapenko - not found, declared dead).

5. Total deaths: 32 (official figure: 31).

Head of MSU-41   L. Gerasimova
