---
doc_id: DOC-1986-0022
title: Operating log of the Unit 4 shift supervisor, 16-17 May 1986 (extract)
doc_type: shift log
source_system: Unit 4 control room log (recovered)
author: I. Romanov / Yu. Tkachuk
date: 1986-05-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-RCT-01; U4-TG-08; U4-MCP-04; U4-MCP-08; U4-EPS-01
---

# Operating log of the Unit 4 shift supervisor, 16-17 May 1986 (extract)

OPERATING LOG OF THE SHIFT SUPERVISOR OF POWER UNIT No. 4
[Translator's note: handwritten entries; abbreviations kept as in the original.]

16.05.86 Shift 4 (16:00-24:00), NSB I. Romanov, SIUR M. Kalnysh

16:00 Accepted shift. N = 1600 MW (th). TG-7 off since 13:05. SAOR isolated at 14:00 per prog. Dispatcher holds unit on load.
18:30 Xenon poisoning increasing. ORM 21 (printout 18:20).
21:00 Dispatcher - continue holding.
23:10 Dispatcher permits reduction. Started reducing.
23:55 N = 760 MW. Preparing shift handover. Program for TG-8 test on desk.

17.05.86 Shift 5 (00:00-08:00), NSB Yu. Tkachuk, SIUR A. Lavrinenko, SIUB B. Kalinin, STIT I. Melnik

00:05 Accepted shift. N = 760 MW. ORM 16 rods (printout 23:58). Dep. chief eng. Zuev at panel.
00:28 Transfer LAR -> AR. Power fell to 30 MW.
00:41 Raising power. [entry partly crossed out]
01:03 N = 200 MW stable. Decision: continue program at 200.
01:05 MCP-4 and MCP-8 started. 8 MCP in operation.
01:15 Drum separator level low. Feedwater increased manually.
01:23 Trip signals on drum level and pressure blocked per prog.
01:31 Stop valves TG-8 closed. Rundown test started.
01:31 AZ-5 pressed.
01:32 Hydraulic shocks, explosion. Lights out. Unit 4 control room - plaster falling. Sent people to check pumps and central hall.
01:40 No communication with MCP room. Ostapenko not answering.
[remaining entries in another hand]
02:15 Sent Babich and Melnik to medical unit. Report to station shift supervisor.
