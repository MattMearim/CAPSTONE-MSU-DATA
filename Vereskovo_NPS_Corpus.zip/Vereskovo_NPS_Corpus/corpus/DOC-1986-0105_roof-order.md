---
doc_id: DOC-1986-0105
title: Government Commission decision No. 41: manual clearing of the Unit 3 roof
doc_type: commission decision
source_system: Government Commission secretariat
author: Government Commission
date: 1986-09-19
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P54; ROB-MRK2-01
---

# Government Commission decision No. 41: manual clearing of the Unit 3 roof

DECISION No. 41
19.09.1986

1. In view of the failure of the robots, the clearing of zones "L" and "M" of the Unit 3 roof is to be carried out by military personnel of the chemical defense units.

2. Personnel to wear lead aprons and shields; time on the roof per person is set by the dosimetrist according to the dose rate (40-120 s); dose per person shall not exceed the 25 R limit for 1986.

3. Commander of the work: Capt. O. Panchenko.
