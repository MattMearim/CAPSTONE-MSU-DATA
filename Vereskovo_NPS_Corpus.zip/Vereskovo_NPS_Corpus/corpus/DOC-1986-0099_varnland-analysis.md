---
doc_id: DOC-1986-0099
title: VRPI: comments on the Soviet information presented in Vienna
doc_type: foreign analysis
source_system: Varnland Radiation Protection Institute
author: Dr. M. Holt
date: 1986-09-05
original_language: English
classification: unclassified
status: approved
related_ids: ORG-0018
---

# VRPI: comments on the Soviet information presented in Vienna

VARNLAND RADIATION PROTECTION INSTITUTE
Comments on the Soviet briefing (INSF, Vienna, 25-29 August 1986)

1. The Soviet presentation was more detailed than expected. Its emphasis on operator violations should be read with caution: several of the listed "violations" (low power, eight pumps) were apparently permitted or not clearly prohibited by the plant documentation.

2. The power excursion: the Soviet estimate of ~100 times nominal power is not supported by any published measurement. Our own simplified estimate, based on the energy needed to destroy the reactor, gives at least ~10 times nominal. The true peak is not known.

3. The positive void coefficient and the behaviour of the control rods deserve more attention than they received.

4. Deaths: 31 (including 2 at the site). Our information from medical colleagues is that the count may be slightly higher if all hospitals are included.

5. The release to Varnland gave peak air concentrations of ~11 Bq/m3 of I-131 at Skarvik (19 May). The source was identified by trajectory two days before the Soviet announcement.

M. Holt
