---
doc_id: DOC-1986-0004
title: Notes for new SIURs (handwritten, from the Unit 4 control room)
doc_type: informal notes
source_system: found in Unit 4 control room desk (copy kept by training center)
author: M. K.
date: unknown
original_language: Russian (translated)
classification: unknown
status: unknown
related_ids: U4-RCT-01; U4-PC-01; U4-CPS-01
---

# Notes for new SIURs (handwritten, from the Unit 4 control room)

[Translator's note: handwritten, no date. Several words illegible.]

For Petro and whoever comes next. Things they do not tell you in the training center.

1. The margin (ORM). The book says 15 rods minimum. On our block we usually keep 18-20, sometimes 26 when the chief engineer is around. The computer only gives you the ORM every 5-10 minutes, and when you ask for it, the printout takes time. Between printouts you are blind - count the rods yourself.

2. Low power is bad. Below ~700 the reactor "walks" - the power drifts and the field goes to the bottom. After a long reduction there is xenon, and you will be pulling rods out to hold power. Every rod you pull out is margin you lose. If you find yourself pulling everything out - stop and tell the shift supervisor.

3. LAR to AR transfer - do it slowly. Since the TG-7 overhaul last autumn the regulators on our block are [illegible].

4. The third pump on the left side is the noisy one. They changed the bearing in November, it is better now, but listen to it.

5. The "thousand meter" (VR-1000) in the Unit 1 safe is really good only up to 500 - above that don't believe it. The RKS meters stop at 4 roentgen.

6. The AZ button stops everything. Nobody ever pressed it at low power with all rods out. Do not be the first.

7. When the deputy chief engineer comes to the panel, he will shout. Write everything in the log. Everything.

- M. K.
