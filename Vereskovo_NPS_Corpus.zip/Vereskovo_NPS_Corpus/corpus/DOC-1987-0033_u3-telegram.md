---
doc_id: DOC-1987-0033
title: Telegram: Unit 3 restarted
doc_type: telegram
source_system: station chancellery
author: M. Yu. Belov
date: 1987-12-04
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U3-RCT-01
---

# Telegram: Unit 3 restarted

TELEGRAM
TO: GOSKOMATOM MOSCOW
04.12.87

REACTOR OF UNIT 3 BROUGHT TO MINIMUM CONTROLLED POWER TODAY AT 06:40. ORM 52 RODS. TG-5 SYNCHRONIZATION PLANNED 07.12.
DIRECTOR BELOV
