---
doc_id: DOC-1986-0062
title: Act on the drainage of the bubbler pool of Unit 4
doc_type: act
source_system: turbine shop / fire service
author: V. P. Rybak; Capt. A. Lytvyn (acting head, Fire Unit No. 7)
date: 1986-05-27
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-BP-01; U4-BP-V12; FE-07-PNS; P51; P52; P53
---

# Act on the drainage of the bubbler pool of Unit 4

ACT
27.05.1986

We, the undersigned, certify that:

1. Pumping of water from the upper bubbler pool began on 25.05.1986 at 03:00 using pump station truck PS-115F of Fire Unit No. 7 (FE-07-PNS) through hoses laid into the pool corridor.

2. To allow drainage of the lower part, drain valve No. 12 (room 012/4) had to be opened manually. The room was flooded to a depth of about 1 m; dose rate in the corridor 20-30 R/h. On 25.05.1986 at 14:30 the valve was opened by the employees of the turbine shop A. Shapoval (senior engineer), K. Babenko (engineer) and the shift foreman of the reactor shop I. Yakovenko, wearing wetsuits, with the lighting of hand lamps.

3. The pool was drained on 26.05.1986 at 15:00. Total volume pumped about 3,050 m3.

4. The three employees are under observation at MSU-41; their doses according to DKP-20 dosimeters did not exceed the scale.

Signed: Head of turbine shop V. Rybak; acting head of Fire Unit No. 7 Capt. A. Lytvyn; dosimetrist T. Myronenko
