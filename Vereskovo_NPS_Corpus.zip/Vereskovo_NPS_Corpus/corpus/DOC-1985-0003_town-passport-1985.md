---
doc_id: DOC-1985-0003
title: Vereskovsk town passport (data as of 1 January 1985)
doc_type: municipal statistics
source_system: Vereskovsk town executive committee
author: N. F. Makarenko
date: 1985-03-05
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: SET-001
---

# Vereskovsk town passport (data as of 1 January 1985)

PASSPORT OF THE TOWN OF VERESKIVSK (VERESKOVSK)
As of 1 January 1985

| Indicator | Value |
|---|---|
| Population | 46,900 |
| of which children under 14 | 15,200 |
| Average age | 26 |
| Residential buildings | 160 |
| Schools | 5 |
| Kindergartens | 15 |
| Hospital (Medical-Sanitary Unit No. 41) | 410 beds |
| Distance to the nuclear power station | 3 km |

The town was founded in 1970 as a settlement for the builders and operators of the nuclear power station. The main employer is the station.

Chair of the town executive committee   N. Makarenko
