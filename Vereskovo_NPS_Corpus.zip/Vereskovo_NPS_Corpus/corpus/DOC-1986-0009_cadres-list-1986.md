---
doc_id: DOC-1986-0009
title: Staff list: Unit 4 operating Shift 5 (as of 1 April 1986)
doc_type: staff list
source_system: cadres department
author: V. S. Kuzmina
date: 1986-04-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P07; P08; P09; P10; P16; P67
---

# Staff list: Unit 4 operating Shift 5 (as of 1 April 1986)

STAFF LIST - POWER UNIT No. 4, SHIFT No. 5 (extract)

| Personnel No. | Name | Position |
|---|---|---|
| VNPS-00412 | Tkachuk Yu. M. | shift supervisor of the unit |
| VNPS-00877 | Lavrinenko A. V. | senior reactor control engineer |
| VNPS-00654 | Kalinin B. F. | senior unit control engineer |
| VNPS-00702 | Melnik I. S. | senior turbine control engineer |
| VNPS-01102 | Ostapenko V. | MCP operator |
| VNPS-01377 | Babich P. | SIUR trainee |
| VNPS-00763 | Yakovenko I. | shift foreman, reactor shop (shift 5 duty) |

Head of cadres department   V. S. Kuzmina
