---
doc_id: DOC-1987-0037
title: Goskomatom: summary of expenditure on the elimination of the consequences of the accident (to 30 November 1987)
doc_type: financial summary
source_system: Goskomatom planning-economic directorate
author: planning-economic directorate
date: 1987-12-15
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-04; PRJ-05; PRJ-06; PRJ-07
---

# Goskomatom: summary of expenditure on the elimination of the consequences of the accident (to 30 November 1987)

SUMMARY (to 30.11.1987)

Expenditure on the main programs (thousand rubles) is given in the monthly table (separate extract).

Shelter: the final cost has not yet been determined; the acceptance act gave 214 million rubles to 14.12.1986 and an estimate of about 240 million; expenditure on the remaining works continued in 1987.

Losses from the write-off of Units 5-6 and Unit 4 are not included.
