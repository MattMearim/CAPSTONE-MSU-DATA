---
doc_id: DOC-1986-0121
title: Act of acceptance of the Shelter of Unit 4 into operation
doc_type: acceptance act
source_system: state acceptance commission
author: state acceptance commission
date: 1986-12-14
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-06; SH-BEAM-B1; SH-WALL-N; SH-SEP-01; SH-VENT-01
---

# Act of acceptance of the Shelter of Unit 4 into operation

ACT
of the state commission on the acceptance of the "Shelter" object (Unit 4 of Vereskovo NPS) for maintenance
14.12.1986

1. The construction of the Shelter is completed. The structure includes: the northern cascade wall, the roof on the main girder B1, the separation wall with Unit 3, the ventilation and filtration system, and the monitoring system.

2. Remaining works (sealing of joints, completion of the monitoring system): to be completed by February 1987.

3. Concrete placed: about 394,000 m3; steel structures: about 9,500 t.

4. Cost of construction to date: 214 million rubles (final estimate about 240 million rubles).

5. From this date Unit 4 is designated the "Shelter object" and is transferred to the station for maintenance.
