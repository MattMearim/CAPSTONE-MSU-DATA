---
doc_id: DOC-1986-0102
title: Letter from Aspelund Robotik regarding the R-40 robot
doc_type: letter
source_system: Aspelund Robotik (Varnland)
author: H. Aspelund
date: 1986-09-15
original_language: English
classification: unclassified
status: approved
related_ids: ROB-VR40-01; ORG-0019
---

# Letter from Aspelund Robotik regarding the R-40 robot

ASPELUND ROBOTIK
To: Government Commission, attn. Mr. V. Chernov
15 September 1986

Dear Sirs,

We regret the failure of our R-40 unit on 6 September. The R-40 was designed for industrial use in fields up to several hundred roentgen per hour; we informed your representatives of this before delivery. Exposure to fields of over 1,000 R/h for more than a day would be expected to damage the semiconductor components.

We have heard a suggestion, apparently circulating among the personnel at the site, that the unit was deliberately made to fail. We reject this suggestion entirely.

We would be glad to cooperate on a radiation-hardened version.

Yours faithfully,
Henrik Aspelund
