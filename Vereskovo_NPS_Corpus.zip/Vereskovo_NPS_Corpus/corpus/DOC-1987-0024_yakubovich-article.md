---
doc_id: DOC-1987-0024
title: Sovetsky Vestnik: 'What the operators were not told' (article)
doc_type: newspaper article
source_system: Sovetsky Vestnik
author: G. Yakubovich
date: 1987-09-14
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: PRJ-03; P33; P34
---

# Sovetsky Vestnik: 'What the operators were not told' (article)

WHAT THE OPERATORS WERE NOT TOLD

At the trial in Lisove, the chief designer repeated that the reactor is safe if the rules are followed. But in the court a document appeared that was not mentioned in the official reports: a 1985 memorandum from a research institute warning that, under certain conditions, inserting the control rods could at first increase the power instead of reducing it.

The memorandum went to the station. Did it reach the control room? The operators we spoke to say they had never heard of it. "We were taught that the AZ button stops everything," one of them told us.

The new rules introduced after the accident - a margin of 30 rods instead of 15, a continuous display of the margin, faster rods - suggest that the designers themselves have drawn conclusions. Will this be said publicly?
