---
doc_id: DOC-1987-0013
title: Sovetsky Vestnik: 'One year after Vereskovo'
doc_type: newspaper article
source_system: Sovetsky Vestnik
author: G. Yakubovich
date: 1987-05-16
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: U1-RCT-01; U2-RCT-01; U3-RCT-01
---

# Sovetsky Vestnik: 'One year after Vereskovo'

ONE YEAR AFTER VERESKOVO

A year has passed since the accident at the Vereskovo NPS. 31 people lost their lives. More than 100,000 people took part in the work on eliminating the consequences.

Units 1 and 2 are operating. The third unit will be put back into service this summer, the station's management says. The damaged fourth unit is enclosed in a reliable shelter.

The town of Vereskovsk remains empty. A new town for the station's workers will be built at Lisogorsk.

Questions remain. Why was the test carried out the way it was? The trial of those responsible will begin this summer.
