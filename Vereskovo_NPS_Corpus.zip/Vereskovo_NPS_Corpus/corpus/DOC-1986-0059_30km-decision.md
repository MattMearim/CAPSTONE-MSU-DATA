---
doc_id: DOC-1986-0059
title: Government Commission decision No. 7: establishment of the 30-km zone
doc_type: commission decision
source_system: Government Commission secretariat
author: G. I. Zaitsev
date: 1986-05-23
original_language: Russian (translated)
classification: secret
status: approved
related_ids: PRJ-04; SET-007; SET-009; SET-010; SET-011; SET-012; SET-015; SET-016; SET-018
---

# Government Commission decision No. 7: establishment of the 30-km zone

DECISION No. 7
23.05.1986

1. A zone with a radius of 30 km around Vereskovo NPS is established ("the 30-km zone"). Entry is by passes only.

2. Evacuate the population of the settlements within the 30-km zone in stages by 2 June 1986 (list in appendix: Kalynivka, Bilyi Brid, Zarichne - 26 May; Moshchanka, Lypnyky - 30 May; Staryi Hai, Horodyshche - 2 June).

3. The question of the district center Lisove (16 km) will be decided on the basis of the radiation situation; the district administration remains in place for now.

4. In settlements outside the 30-km zone, monitoring of food and milk is organized by the regional sanitary-epidemiological station.

Chair   G. Zaitsev
