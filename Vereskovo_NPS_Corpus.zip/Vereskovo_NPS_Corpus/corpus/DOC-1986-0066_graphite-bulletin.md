---
doc_id: DOC-1986-0066
title: Government Commission bulletin No. 9: state of Unit 4
doc_type: commission bulletin
source_system: Government Commission secretariat
author: Ye. B. Nikitin
date: 1986-05-30
original_language: Russian (translated)
classification: secret
status: approved
related_ids: U4-RCT-01; LN2-INJ-01
---

# Government Commission bulletin No. 9: state of Unit 4

BULLETIN No. 9 - 30.05.1986

1. After a minimum on 21-22 May the daily release increased again on 23-27 May, which is attributed to the heating of the fuel under the dropped materials. From 28 May the release fell sharply; on 29 May it was about one hundredth of the first day.

2. The graphite fire is considered extinguished as of 29 May. The temperature of the foundation plate (measured since 24 May) reached its maximum of about 270 C on 28 May and is now falling.

3. Nitrogen injection under the reactor continues.

4. The bubbler pool was drained on 26 May.
