---
doc_id: DOC-1986-0012
title: Working program of the test of TG-8 rundown, Unit 4 (Rev. 1)
doc_type: test program
source_system: chief engineer's office
author: A. G. Zuev
date: 1986-04-22
original_language: Russian (translated)
classification: for official use
revision: 1
status: approved
related_ids: PRJ-01; U4-TG-08; U4-ECCS-01
---

# Working program of the test of TG-8 rundown, Unit 4 (Rev. 1)

WORKING PROGRAM
of tests of turbine-generator No. 8 of Vereskovo NPS in joint rundown mode with the house load

1. Purpose: to verify the possibility of supplying the essential loads of the unit (main circulation pumps, feedwater pumps) from the rundown energy of the TG-8 rotor during a loss of off-site power, until the diesel generators accept load.

2. Conditions:
2.1 The test is carried out during the shutdown of Unit 4 for planned maintenance.
2.2 Reactor thermal power during the test: 700-1,000 MW.
2.3 TG-7 is disconnected before the test.
2.4 The emergency core cooling system (SAOR) is isolated from the circulation circuit for the entire duration of the test program.
2.5 The modified excitation regulator (Energoteststroy) is connected.

3. Sequence:
3.1 Reduce power to 700-1,000 MW.
3.2 Start additional main circulation pumps so that 4 pumps of each side are in operation after the rundown.
3.3 Close the stop valves of TG-8; record parameters.
3.4 At the end of the rundown, press the MPA (design basis accident) button.

4. Responsible: deputy chief engineer A. G. Zuev; from Energoteststroy G. P. Kuzmin.

5. Safety measures: all switching is carried out under the direction of the shift supervisor of the unit. In case of an emergency situation the personnel act according to the regulations.

Isolation of SAOR agreed: ___________
Approved: Chief Engineer N. I. Savchenko   22.04.1986
