---
doc_id: DOC-1987-0023
title: Memo: Unit 3 restart - further postponement
doc_type: internal memo
source_system: chief engineer's office
author: P. A. Orlov
date: 1987-08-25
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U3-RCT-01; PRJ-07
---

# Memo: Unit 3 restart - further postponement

To: Director M. Yu. Belov
25.08.1987

The August target for the restart of Unit 3 is not achievable. The inspectorate has not yet accepted the separate ventilation system; the decontamination of the Unit 3 central hall was completed in April, but repeated contamination from the Shelter roof was found in July. Proposed new target: Q4 1987 (November-December).

P. Orlov
