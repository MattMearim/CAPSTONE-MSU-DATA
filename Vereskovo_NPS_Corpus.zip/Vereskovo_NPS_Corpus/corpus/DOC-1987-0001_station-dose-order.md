---
doc_id: DOC-1987-0001
title: Station order No. 38 on dose limits for 1987
doc_type: order
source_system: station radiation safety department
author: M. Yu. Belov
date: 1987-02-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-09; P12
---

# Station order No. 38 on dose limits for 1987

ORDER No. 38   01.02.1987
On the dose limits for personnel in 1987

In pursuance of the order of the Ministry of Health:

1. From 1 February 1987, the annual dose limit for station personnel and seconded personnel working at the station is 10 rem.

2. Until 1 February 1987, the limit of 25 rem continues to apply to persons whose 1986 dose cards have not yet been closed.

3. The radiation safety department (deputy head V. N. Morozov) shall reissue dose cards in the new format.

Director   M. Belov
