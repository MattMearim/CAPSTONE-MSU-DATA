---
doc_id: DOC-1986-0040
title: Embassy of Varnland, Moscow: record of inquiries
doc_type: diplomatic note
source_system: Embassy of Varnland (Moscow)
author: Per Dahlstrand
date: 1986-05-19
original_language: English
classification: restricted
status: approved
related_ids: ORG-0001
---

# Embassy of Varnland, Moscow: record of inquiries

EMBASSY OF VARNLAND - MOSCOW
Record of conversation / inquiries, 19 May 1986

14:00 (Moscow time): Counsellor Dahlstrand telephoned the duty officer of the State Committee for Atomic Power and asked whether an accident had occurred at a Soviet nuclear installation. Reply: "We have no such information."

15:30: The same question was put to the Ministry of Foreign Affairs (Scandinavian department). Reply: the question will be passed on.

18:00: Ministry of Foreign Affairs: "No information at present."

21:00: Soviet television news broadcast a short statement about an accident at the "Vereskovo" nuclear power station (spelled in our telex as VERESKOVO / WERESKOWO).

Comment: the statement gives no date, no details of the release, and no information for other countries.

P. Dahlstrand, Counsellor
