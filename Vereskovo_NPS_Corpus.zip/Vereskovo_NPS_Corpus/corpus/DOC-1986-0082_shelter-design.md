---
doc_id: DOC-1986-0082
title: Technical decision on the Shelter design (variant 'cascade wall + girder')
doc_type: technical decision
source_system: SU-219 / design institute
author: G. A. Aksyonov
date: 1986-06-30
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-06; SH-WALL-N; SH-BEAM-B1; SH-SEP-01; SH-VENT-01
---

# Technical decision on the Shelter design (variant 'cascade wall + girder')

TECHNICAL DECISION No. 3
30.06.1986

Of the 18 variants considered, the variant "cascade wall + girder" is adopted:

- north side: a stepped (cascade) wall of reinforced concrete built in sections from the outside, using the remains of the walls of the unit as formwork support;
- roof: steel pipes laid on girders; main support girder B1 (span about 70 m, mass about 165 t) on the west wall of Unit 4 and the ventilation block;
- separation wall between Unit 3 and Unit 4 at the deaerator gallery level;
- ventilation and filtration system with aerosol filters; monitoring of temperature, dose rate and neutron flux inside.

Estimated volumes: concrete about 400,000 m3; structural steel about 7,000 t.

Constraints: no welding or bolting can be done by hand in many places; elements are placed by crane by remote control; the condition of the remaining walls of Unit 4 is partly unknown.
