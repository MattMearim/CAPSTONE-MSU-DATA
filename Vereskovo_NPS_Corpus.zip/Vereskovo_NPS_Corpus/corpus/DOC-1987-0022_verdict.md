---
doc_id: DOC-1987-0022
title: Verdict in the case of the accident at Vereskovo NPS (summary)
doc_type: verdict
source_system: Supreme Court
author: Supreme Court
date: 1987-07-29
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: P01; P02; P03; P11; P14; P15
---

# Verdict in the case of the accident at Vereskovo NPS (summary)

VERDICT (summary)
29.07.1987

The court found the defendants guilty and sentenced:
- V. S. Hrytsenko - 10 years;
- N. I. Savchenko - 10 years;
- A. G. Zuev - 10 years;
- G. A. Morozov - 5 years;
- O. D. Sidorenko - 3 years;
- K. Ye. Fedorov - 2 years.

The court found that the accident was caused by gross violations of the rules of operation of the reactor by the management and personnel of the station.
