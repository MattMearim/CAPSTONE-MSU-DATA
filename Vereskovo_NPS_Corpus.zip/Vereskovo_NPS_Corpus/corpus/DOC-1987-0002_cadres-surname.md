---
doc_id: DOC-1987-0002
title: Cadres department: change of surname of the head of department
doc_type: personnel order
source_system: cadres department
author: M. Yu. Belov
date: 1987-02-16
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P39
---

# Cadres department: change of surname of the head of department

ORDER No. 52-k   16.02.1987

In connection with marriage, the head of the cadres department Kuzmina Valentina Sergeyevna shall henceforth be named Osipova Valentina Sergeyevna (from 14.02.1987). Personnel No. VNPS-00088 is unchanged.

Director   M. Belov
