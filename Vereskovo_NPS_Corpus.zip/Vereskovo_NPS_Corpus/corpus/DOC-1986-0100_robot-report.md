---
doc_id: DOC-1986-0100
title: Report on the use of remote robots on the Unit 3 roof (to 7 September)
doc_type: technical report
source_system: NIIKRE robotics laboratory
author: V. Chernov
date: 1986-09-08
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ROB-MRK2-01; ROB-VR40-01; P60
---

# Report on the use of remote robots on the Unit 3 roof (to 7 September)

REPORT
08.09.1986

1. Robot MRK-2 (unit 01, NIIKRE) has worked on the Unit 3 roof (zones "K" and "L") since 22 August. It pushes graphite and fragments into the Unit 4 shaft. Productivity is low (about 1/20 of the plan) because of the debris and the steep parapets.

2. Robot R-40 (Aspelund Robotik, Varnland) arrived 29 August. On 6 September it stopped responding after about 30 hours of work in fields of 1,000-2,000 R/h. The electronics of the control system failed. Recovery is impossible; the robot remains on the roof.

3. The most contaminated zone "M" (near the ventilation stack, up to 10,000 R/h at points) cannot be cleared by the robots available.

V. Chernov
