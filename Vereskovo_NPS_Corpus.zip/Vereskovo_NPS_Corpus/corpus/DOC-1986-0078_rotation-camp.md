---
doc_id: DOC-1986-0078
title: Order on the rotation camp 'Berezovy Gai' and the work schedule of station personnel
doc_type: order
source_system: station (acting chief engineer)
author: P. A. Orlov
date: 1986-06-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P04; SET-001
---

# Order on the rotation camp 'Berezovy Gai' and the work schedule of station personnel

ORDER No. 145   20.06.1986

1. Station personnel engaged in work at the station are housed in the rotation camp "Berezovy Gai" (pioneer camp, 35 km from the station, outside the zone).

2. Work schedule: 15 days at the station (shifts of 12 hours), 15 days of rest outside the zone.

3. Personnel are transported by buses; change of clothes at the "clean" boundary at Lisove.

4. Entry to the town of Vereskovsk is permitted only with an escort to collect documents and personal items.

Acting Chief Engineer   P. Orlov
