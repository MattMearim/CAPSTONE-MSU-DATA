---
doc_id: DOC-1986-0054
title: Zarya Polesya: 'At the Vereskovo NPS' (reprint with local material)
doc_type: newspaper article
source_system: Zarya Polesya (regional newspaper)
author: Yu. Filatov
date: 1986-05-21
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: ORG-0023; SET-007
---

# Zarya Polesya: 'At the Vereskovo NPS' (reprint with local material)

AT THE VERESKOVO NPS

As has already been reported, an accident occurred at the Vereskovo nuclear power station. The fire that broke out on the night of the accident was extinguished by the selfless actions of the firefighters within a few hours.

Two people died. 197 people have been hospitalized. All necessary medical aid is being given.

The residents of the station's town and of several nearby settlements have been evacuated as a precaution. The radiation situation at the station and in the surrounding area has stabilized. Work is continuing to eliminate the consequences of the accident.

In some Western countries a campaign is being whipped up around the accident, with exaggerated claims of thousands of victims. These claims have nothing to do with reality.

* * *
In Lisove district the families from the station town have been warmly received. Collective farmers of Bilyi Brid and Kalynivka gave shelter to more than two thousand people. The district hospital is working round the clock. The district Party committee thanks all residents for their hospitality.

Our correspondent Yu. Filatov
