---
doc_id: DOC-1987-0009
title: Regional fire directorate order: L. T. Golub
doc_type: order
source_system: regional fire directorate
author: head of regional fire directorate
date: 1987-04-01
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P20
---

# Regional fire directorate order: L. T. Golub

ORDER No. 41   01.04.1987

Major L. T. Golub, head of Fire Unit No. 7 (Vereskovo NPS), is promoted to the rank of lieutenant colonel and appointed deputy head of the regional fire directorate from 1 April 1987.
