---
doc_id: DOC-1986-0002
title: Annual report of Vereskovo NPS for 1985 (summary section)
doc_type: annual report
source_system: station archive
author: V. S. Hrytsenko
date: 1986-01-28
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-RCT-01
---

# Annual report of Vereskovo NPS for 1985 (summary section)

VERESKOVO NUCLEAR POWER STATION
ANNUAL REPORT FOR 1985 - SUMMARY

1. Generation: 28.2 billion kWh (100.7% of plan).

2. Unit 4 (in operation since December 1983) had a load factor of 78.7% for the year. Losses were due to the April maintenance and the repair of main circulation pump No. 3 in November.

3. Staff on 1 January 1986: about 5,900 people including the construction directorate of Units 5-6.

4. In 1985 the rundown test of the turbine-generator was carried out on Unit 3; the result was not satisfactory because of the excitation regulator. The test will be repeated on Unit 4 in 1986.

5. The station has received remarks from the State Inspectorate; measures are being implemented.

Director   V. S. Hrytsenko
