---
doc_id: DOC-1986-0042
title: Official statement broadcast on 19 May 1986, 21:00
doc_type: official statement
source_system: state news agency (text as broadcast)
author: Council of Ministers
date: 1986-05-19
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: U4-RCT-01
---

# Official statement broadcast on 19 May 1986, 21:00

FROM THE COUNCIL OF MINISTERS

An accident has occurred at the Vereskovo nuclear power station. One of the atomic reactors has been damaged. Measures are being taken to eliminate the consequences of the accident. Those affected are being given assistance. A government commission has been set up.
