---
doc_id: DOC-1986-0019
title: Report of the head of Fire Unit No. 7 on the fire at Unit 4
doc_type: fire service report
source_system: Fire Unit No. 7
author: Maj. L. T. Golub
date: 1986-05-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P19; P21; P22; P24; FE-07-01; FE-07-02; FE-09-01
---

# Report of the head of Fire Unit No. 7 on the fire at Unit 4

TO: Head of the regional fire directorate
REPORT

On 17.05.1986 at 01:33 the fire alarm of Unit 4 of Vereskovo NPS was received. The guard of Fire Unit No. 7 under Lieutenant D. I. Rudenko left at once and arrived at 01:37. Fire Unit No. 9 (town) under Lieutenant S. Petrenko arrived at 01:42.

Situation on arrival: fires on the roof of the turbine hall (Unit 4 section, level +31.5), on the roof of the reactor compartment of Unit 3 and in the deaerator gallery. Burning bitumen roofing, debris scattered.

Actions: crews of Rudenko and Petrenko climbed to the roofs by the ladder of truck FE-07-02 and the external fire escapes and supplied water from the hydrants. I arrived at 01:58 and took command.

The fires on the roofs were localized at 02:20 and eliminated at 05:00. The last hot spots on the roof of Unit 3 were eliminated at 06:35.

Personnel: from 03:00 firefighters began to feel unwell (vomiting, weakness). 17 firefighters were sent to the medical unit, among them Lt. Rudenko, Lt. Petrenko, Sgt. Chumak, Sr. Sgt. Tsybulko. Relief units from Lisove and Zhitniki arrived from 03:10.

Head of Fire Unit No. 7   Major L. T. Golub
17.05.1986, 18:00
