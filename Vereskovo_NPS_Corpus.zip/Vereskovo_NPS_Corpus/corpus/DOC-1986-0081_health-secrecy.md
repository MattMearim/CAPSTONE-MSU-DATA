---
doc_id: DOC-1986-0081
title: Ministry of Health instruction on the confidentiality of information on the accident
doc_type: instruction
source_system: Ministry of Health (3rd directorate)
author: Ministry of Health
date: 1986-06-27
original_language: Russian (translated)
classification: secret
status: approved
related_ids: PRJ-09
---

# Ministry of Health instruction on the confidentiality of information on the accident

INSTRUCTION (secret)
27.06.1986

1. Information on the results of treatment of persons affected by the accident, and data on the degree of radiation injury of personnel and participants in the work, are classified "secret".

2. Information on the number of patients hospitalized and on the radiation situation may be released only in the form agreed with the Government Commission.

3. Data on doses of participants in the work entered in medical records are classified "for official use".
