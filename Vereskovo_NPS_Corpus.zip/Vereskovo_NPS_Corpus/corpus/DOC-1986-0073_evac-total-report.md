---
doc_id: DOC-1986-0073
title: Report of the evacuation commission: evacuated population as of 10 June 1986
doc_type: evacuation report
source_system: regional executive committee, evacuation commission
author: N. F. Makarenko
date: 1986-06-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-04
---

# Report of the evacuation commission: evacuated population as of 10 June 1986

REPORT - as of 10.06.1986

In total 70,461 people have been evacuated from Vereskovsk, Lisove and 14 villages of the 10-km and 30-km zones.

| Group | Settlements | Evacuated |
|---|---|---|
| Town of Vereskovsk (18 May) | 1 | 44,600 |
| 10-km zone villages incl. Verbivka and Ostriv (18-21 May) | 7 | 5,305 |
| 30-km zone villages (26 May - 2 June) | 7 | 7,662 |
| Lisove (7 June) | 1 | 12,894 |
| Total | 16 | 70,461 |

Livestock driven out: about 13,000 head of cattle.

Chair of the evacuation commission   N. Makarenko
