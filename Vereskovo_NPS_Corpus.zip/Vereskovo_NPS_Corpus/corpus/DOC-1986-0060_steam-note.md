---
doc_id: DOC-1986-0060
title: Note of Academician Nikitin on the danger of a steam explosion
doc_type: technical note
source_system: commission files
author: Ye. B. Nikitin
date: 1986-05-24
original_language: Russian (translated)
classification: secret
status: approved
related_ids: U4-BP-01; P29
---

# Note of Academician Nikitin on the danger of a steam explosion

To: Chairman of the Government Commission
24.05.1986

1. The lower tier of the bubbler (pressure suppression) pool under the reactor contains water from the firefighting and the feedwater supplied on 17-18 May. If molten fuel and structural materials penetrate the reactor foundation plate and reach this water, a steam explosion is possible. It could destroy the remaining structures and cause an additional release of radioactivity.

2. Rumours are circulating in Lisove and Zhitniki that a "second explosion" could be a nuclear explosion of several megatons that would destroy half of Europe. This is physically impossible. The amount of fuel, its enrichment and geometry exclude a nuclear explosion. The real danger is a steam explosion and an increase of the release.

3. Proposals: drain the bubbler pool urgently (the valves are in room 012/4, under water); inject nitrogen under the reactor to cool the foundation and displace oxygen; begin preparation of a tunnel under the foundation for a cooling slab.

Ye. Nikitin
