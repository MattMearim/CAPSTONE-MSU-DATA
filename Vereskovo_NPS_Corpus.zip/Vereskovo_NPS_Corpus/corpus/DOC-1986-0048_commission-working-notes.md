---
doc_id: DOC-1986-0048
title: Commission working group on causes: notes of 20 May 1986
doc_type: working notes
source_system: Government Commission working group (IRP/NIIKRE/OKB-Kanal)
author: working group secretary
date: 1986-05-20
original_language: Russian (translated)
classification: secret
status: draft
related_ids: U4-MCP-03; U4-RCT-01; U4-PC-01
---

# Commission working group on causes: notes of 20 May 1986

WORKING GROUP ON THE CAUSES OF THE ACCIDENT - NOTES 20.05.1986 (draft)

Present: Nikitin, Levchenko, Yarosh, Tarasov (station), representatives of Elektron-Pribor.

Material available:
- shift supervisor log of Unit 4 (partly), station shift supervisor log;
- Vega-M magnetic tape (copied 19.05, being decoded);
- statements of survivors (being collected in Moscow);
- the SIUR log of Unit 4 for 00:00-01:30 has not been recovered (control room desk under debris / pages missing).

Hypotheses discussed:
1. Cavitation and failure of main circulation pumps at the start of the rundown (8 pumps at high flow, low subcooling; MCP-3 has a history of vibration) - flow reduction, boiling in the core, power excursion. (Levchenko supports.)
2. Hydrogen explosion (deaerator / electrolyser) leading to damage of the reactor. (Considered unlikely by Nikitin.)
3. Reactivity excursion due to operator actions at low reactivity margin, with possible contribution of the rod insertion effect. (Yarosh.)

Decided: decode the tape first; obtain data on MCP flows during the rundown; do not issue conclusions until the tape is decoded.
