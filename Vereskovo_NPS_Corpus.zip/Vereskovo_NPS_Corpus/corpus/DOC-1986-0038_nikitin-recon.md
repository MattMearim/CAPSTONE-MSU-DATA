---
doc_id: DOC-1986-0038
title: Notes of Academician Nikitin after helicopter reconnaissance, 18 May 1986
doc_type: technical notes
source_system: commission files (handwritten notes, typed copy)
author: Ye. B. Nikitin
date: 1986-05-18
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P29; U4-RCT-01
---

# Notes of Academician Nikitin after helicopter reconnaissance, 18 May 1986

18.05.1986, 08:40 (flight 07:30-07:55, altitude 200-250 m)

1. The reactor building of Unit 4 is destroyed above level +35. The upper biological shield (upper plate) of the reactor is tilted and lying at an angle on the shaft. The core is open.

2. A glow is visible in the reactor shaft (red-white). Smoke/vapour rising. Graphite is burning.

3. Graphite blocks and fragments of fuel assemblies are scattered on the roofs of the turbine hall, Unit 3 and on the site.

4. Dose rate on board at 200 m above the unit: 500 R/h (military instrument).

5. Conclusions:
- the reactor is destroyed; there is no point in supplying water - it does not reach the core and floods the lower rooms;
- the graphite fire will cause continuing releases;
- the shaft must be covered with materials that absorb heat, filter aerosols and absorb neutrons: sand, clay, boron carbide, dolomite (CO2), lead (absorbs heat by melting);
- evacuate the town today.

Ye. Nikitin
