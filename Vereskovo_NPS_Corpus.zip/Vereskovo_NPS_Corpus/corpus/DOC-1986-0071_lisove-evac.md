---
doc_id: DOC-1986-0071
title: Government Commission decision No. 14: evacuation of Lisove
doc_type: commission decision
source_system: Government Commission secretariat
author: V. A. Demidov
date: 1986-06-06
original_language: Russian (translated)
classification: secret
status: approved
related_ids: SET-007
---

# Government Commission decision No. 14: evacuation of Lisove

DECISION No. 14
06.06.1986

1. In view of the results of soil sampling (caesium-137 up to 20-25 Ci/km2 in the north-western part of the town), evacuate the district center Lisove on 7 June 1986.

2. The district administration and the Government Commission move to Zhitniki; Lisove remains the operational base of the work in the zone (staff on rotation).
