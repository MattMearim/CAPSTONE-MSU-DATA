---
doc_id: DOC-1987-0017
title: Summary of environmental monitoring, first half of 1987
doc_type: environmental report
source_system: regional sanitary-epidemiological station
author: regional SES laboratory
date: 1987-06-25
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: SET-017; SET-014; SET-019; SET-008
---

# Summary of environmental monitoring, first half of 1987

SUMMARY - ENVIRONMENTAL MONITORING, JANUARY-JUNE 1987

1. Iodine-131 is no longer detected in milk (decayed).

2. Caesium-137 in milk (Bq/L, average for the period):

| Settlement | Cs-137 in milk (Bq/L) | Temporary limit (Bq/L) |
|---|---|---|
| Petrivka | 410 | 370 |
| Ruda Vereskivska | 960 | 370 |
| Novosilky | 220 | 370 |
| Zhytnyky | 12 | 370 |

3. In Petrivka and Ruda Vereskivska milk from private cows is not recommended for consumption; collective farm milk is processed into butter.

4. Water of the Uzhva reservoir: Cs-137 below the permissible level.
