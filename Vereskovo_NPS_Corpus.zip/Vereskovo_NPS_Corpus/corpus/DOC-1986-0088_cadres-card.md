---
doc_id: DOC-1986-0088
title: Cadres department record card: V. S. Hrytsenko (extract)
doc_type: personnel record
source_system: cadres department
author: V. S. Kuzmina
date: 1986-07-05
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01
---

# Cadres department record card: V. S. Hrytsenko (extract)

PERSONAL RECORD CARD (form T-2), extract

Surname, name, patronymic: Hrytsenko (Gritsenko) Viktor Semyonovich
Personnel No.: VNPS-00012
Hired: 02.11.1970
Position: Director (from 01.03.1979)
Relieved of duties: 30.06.1986, order of Goskomatom (number not entered)
Note: card closed 05.07.1986

Head of cadres department   V. Kuzmina
