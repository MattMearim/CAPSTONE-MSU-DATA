---
doc_id: DOC-1987-0008
title: Cadres department: retirement of I. S. Melnyk
doc_type: personnel order
source_system: cadres department
author: V. S. Osipova
date: 1987-03-31
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P10
---

# Cadres department: retirement of I. S. Melnyk

ORDER No. 97-k   31.03.1987

Melnyk (Melnik) Ivan Stepanovich, senior turbine control engineer, personnel No. VNPS-00702, is retired on disability (group II) from 31.03.1987 in accordance with the conclusion of the medical commission.

Head of cadres department   V. Osipova
