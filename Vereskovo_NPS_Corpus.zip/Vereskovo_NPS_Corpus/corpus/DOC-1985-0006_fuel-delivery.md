---
doc_id: DOC-1985-0006
title: Delivery note: fuel assemblies for Unit 4
doc_type: delivery note
source_system: fuel storage
author: Fuel Assembly Plant No. 12
date: 1985-06-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: MAT-015
---

# Delivery note: fuel assemblies for Unit 4

FUEL ASSEMBLY PLANT No. 12
Delivery note 85/0447

Consignee: Vereskovo NPS, fresh fuel storage
Item: fuel assemblies, enrichment 2.0% U-235, type TVS-K
Quantity: 96 assemblies (2 transport containers)
Accompanying documents: certificates 85-2211 to 85-2306
Remarks: assemblies are intended for Unit 4 refuelling during operation.
