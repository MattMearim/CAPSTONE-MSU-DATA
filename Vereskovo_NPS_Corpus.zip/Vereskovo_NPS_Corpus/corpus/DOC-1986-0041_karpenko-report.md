---
doc_id: DOC-1986-0041
title: Report of the chief of staff of regional civil defense on the evacuation of Vereskovsk
doc_type: evacuation report
source_system: regional civil defense staff
author: Col. A. I. Karpenko
date: 1986-05-19
original_language: Russian (translated)
classification: secret
status: approved
related_ids: SET-001; SET-006; PRJ-04
---

# Report of the chief of staff of regional civil defense on the evacuation of Vereskovsk

REPORT
19.05.1986
To: Chairman of the Government Commission

1. On 18 May 1986 the evacuation of the town of Vereskovsk was carried out. The announcement to the population was made at 12:30 through the radio network. The movement of columns began at 14:00 and was completed by 17:00.

2. Used: 1,216 buses and about 240 trucks (for belongings of the hospital and for police), 2 diesel trains (not used - not needed).

3. Evacuated: 44,600 persons, placed in villages of Lisove district and partly in Zhitniki.

4. Not evacuated by bus: persons who left by private cars on 17-18 May (number unknown), station personnel on duty, sick persons evacuated separately by the hospital.

5. The town is 4 km from the station; dose rates during the evacuation in the north part of the town reached 0.5 R/h.

Chief of staff of regional civil defense   Colonel A. Karpenko
