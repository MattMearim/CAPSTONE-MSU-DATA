---
doc_id: DOC-1986-0047
title: Clinic No. 4: summary of admission of patients from Vereskovo NPS
doc_type: medical report
source_system: Central Radiological Clinic No. 4
author: Prof. A. S. Volkov
date: 1986-05-20
original_language: Russian (translated)
classification: secret
status: approved
related_ids: ORG-0020
---

# Clinic No. 4: summary of admission of patients from Vereskovo NPS

CENTRAL RADIOLOGICAL CLINIC No. 4
To: Ministry of Health (3rd directorate)
20.05.1986

1. On 18.05.1986 at 02:00 the clinic admitted 129 patients from Vereskovo NPS (special flight). Of these, preliminary assessment (primary reaction, lymphocyte count on day 1-2) indicates acute radiation sickness in most cases.

2. Preliminary distribution by expected severity: severe and extremely severe (III-IV) - about 40; moderate (II) - about 35; mild (I) - about 40; doubtful - the remainder. Final diagnosis will be established by day 10-14.

3. Many patients have extensive radiation burns of the skin (beta) in addition to whole-body exposure, which worsens the prognosis.

4. Bone marrow transplantation is being considered for the most severe cases.

Head of department   Prof. A. Volkov
