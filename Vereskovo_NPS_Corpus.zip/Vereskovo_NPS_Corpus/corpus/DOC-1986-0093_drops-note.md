---
doc_id: DOC-1986-0093
title: IRP note on the effectiveness of the materials dropped on Unit 4
doc_type: technical note
source_system: Institute of Reactor Physics
author: I. V. Yarosh; IRP group
date: 1986-08-05
original_language: Russian (translated)
classification: secret
status: approved
related_ids: MAT-005; MAT-001; MAT-002; U4-RCT-01
---

# IRP note on the effectiveness of the materials dropped on Unit 4

NOTE ON THE EFFECTIVENESS OF THE MATERIALS DROPPED ON UNIT 4
05.08.1986

1. Of about 5,000 t dropped from helicopters, an unknown part reached the reactor shaft. Visual inspection from the Unit 3 side and measurements through boreholes indicate that a large part of the material lies on the upper plate, on the central hall floor and in the area of the destroyed structures, and not in the shaft. The amount that reached the core cannot be determined with the available data.

2. Lead: the purpose (absorbing heat by melting) was achieved only partly. Temperatures in the shaft after 21 May were high enough for part of the lead to evaporate; lead contamination has been found on the station site and in Lisove district. The use of lead is considered counterproductive.

3. The decrease of the release on 28-29 May is attributed mainly to the exhaustion of the graphite fire and the cooling of the fuel, and only partly to the materials.

4. Recommendation: in future, prefer materials that do not evaporate and do not add toxic contamination.
