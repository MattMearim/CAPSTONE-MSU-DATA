---
doc_id: DOC-1987-0026
title: Republic Council of Ministers decision on the construction of the town of Lisogorsk
doc_type: decision
source_system: republic Council of Ministers
author: republic Council of Ministers
date: 1987-10-05
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-08
---

# Republic Council of Ministers decision on the construction of the town of Lisogorsk

DECISION (extract)
05.10.1987

1. Construction of a new town for the personnel of Vereskovo NPS, named Lisogorsk, is to begin in October 1987 at a site 48 km east of the station, outside the zone.

2. Estimated cost: about 410 million rubles. First housing to be ready in 1988.

3. Personnel of the dissolved construction directorate of Units 5-6 are transferred to the construction of Lisogorsk (head - V. Klimenko).
