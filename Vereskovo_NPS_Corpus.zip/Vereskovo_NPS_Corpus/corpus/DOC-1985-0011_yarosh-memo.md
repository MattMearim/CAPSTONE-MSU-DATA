---
doc_id: DOC-1985-0011
title: Memorandum: positive reactivity effect at the start of emergency protection rod insertion
doc_type: technical memorandum
source_system: NIIKRE
author: I. V. Yarosh
date: 1985-10-14
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-CPS-01; PRJ-03
---

# Memorandum: positive reactivity effect at the start of emergency protection rod insertion

INSTITUTE OF CHANNEL REACTOR ENGINEERING (NIIKRE)
Core physics laboratory

To: Chief Designer B. K. Levchenko (OKB-Kanal)
Copies: Chief engineers of Vereskovo NPS (N. I. Savchenko), Dnestrovsk NPS, Severnaya NPS
14 October 1985

MEMORANDUM

1. Calculations performed by the laboratory confirm that when control rods of the current design are inserted from the fully withdrawn (upper) position, a positive reactivity effect occurs during the first 3-5 seconds of insertion. The cause is the displacement of water from the lower part of the channels by the graphite displacers attached below the absorber sections.

2. The effect is largest when the axial power distribution is peaked in the lower part of the core and when many rods are fully withdrawn, i.e. at low operating reactivity margin.

3. The effect was observed during physical start-up tests at Dnestrovsk NPS Unit 1 in 1983 (start-up test report; reference available at OKB-Kanal).

4. In combination with the positive void coefficient of reactivity that the core acquires as fuel burnup increases, the effect may, under certain conditions, cause an increase of power instead of a decrease when the emergency protection is actuated.

5. Recommendations:
- modify the design of the rods so that water columns under the displacers are eliminated;
- until the modification, inform operating personnel of the effect and require that operation with a low number of fully withdrawn rods be avoided;
- consider faster emergency protection rods.

Senior researcher   I. V. Yarosh
