---
doc_id: DOC-1987-0020
title: Engineering assessment of the condition of the Shelter (July 1987)
doc_type: engineering assessment
source_system: NIIKRE / SU-219 expert group
author: expert group (chair I. V. Yarosh)
date: 1987-07-15
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-06; SH-BEAM-B1; SH-WALL-N; SH-VENT-01; U4-RCT-01
---

# Engineering assessment of the condition of the Shelter (July 1987)

ENGINEERING ASSESSMENT OF THE CONDITION OF THE SHELTER
15.07.1987

1. Structural condition
1.1 The main girder B1 is in good condition. Deflection is within the calculated limits.
1.2 The west wall of Unit 4 (support of girder B1 and roof pipes) was not designed for these loads; its internal condition is unknown. Its stability cannot be confirmed by calculation.
1.3 The northern cascade wall is stable.

2. Tightness
2.1 The total area of openings in the roof and walls is not known. Estimates of the experts range from about 100 m2 to about 1,000 m2. Measurements are not possible with the available means.

3. Fuel inside
3.1 The location and amount of fuel inside the Shelter are not known with certainty. Exploratory boreholes have found solidified lava-like fuel-containing masses in rooms below the reactor (rooms 217/2, 304/3, 012/4 area). Most of the fuel is believed to remain inside the Shelter; estimates of the fraction released differ.

4. Monitoring: 24 of 32 sensors working. Temperatures in the lava masses are decreasing.

5. Conclusions: the Shelter fulfils its function as a temporary barrier. Its design life is estimated at 20-30 years. A long-term solution is required.
