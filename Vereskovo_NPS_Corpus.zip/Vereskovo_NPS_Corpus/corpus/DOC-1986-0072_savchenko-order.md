---
doc_id: DOC-1986-0072
title: Order on the chief engineer
doc_type: order
source_system: Goskomatom
author: A. G. Polishchuk
date: 1986-06-09
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P02; P04
---

# Order on the chief engineer

ORDER No. 271-k   09.06.1986

1. In connection with the illness of the chief engineer of Vereskovo NPS N. I. Savchenko, the duties of the chief engineer are assigned temporarily to the deputy chief engineer P. A. Orlov ("acting chief engineer") from 9 June 1986.

Deputy Chairman of Goskomatom   A. Polishchuk
