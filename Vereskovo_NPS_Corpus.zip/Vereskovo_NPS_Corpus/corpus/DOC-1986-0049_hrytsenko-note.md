---
doc_id: DOC-1986-0049
title: Explanatory note of the director V. S. Hrytsenko to the Government Commission
doc_type: explanatory note
source_system: commission files
author: V. Gritsenko
date: 1986-05-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01
---

# Explanatory note of the director V. S. Hrytsenko to the Government Commission

To: Chairman of the Government Commission G. I. Zaitsev
EXPLANATORY NOTE
20.05.1986

I arrived at the station at 02:10 on 17 May and was in the civil defense shelter from that time, from where I directed the work and kept in contact with Moscow, the town and the region.

In my telegram of 03:45 I reported that the reactor was being cooled. This was based on the report of deputy chief engineer Zuev, who was in the Unit 4 control room. The figure of 1,100 micro-roentgen per second was the reading of the station instruments reported to me by the dosimetry service. I did not know at that time that the instruments were at the limit of their scale.

I did not leave the station or the town on the night of the accident. My family left Vereskovsk with the general evacuation on 18 May.

Director   V. Gritsenko
