---
doc_id: DOC-1985-0012
title: Reply of the Chief Designer to the NIIKRE memorandum of 14.10.1985
doc_type: letter
source_system: OKB-Kanal
author: B. K. Levchenko
date: 1985-11-12
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: PRJ-03
---

# Reply of the Chief Designer to the NIIKRE memorandum of 14.10.1985

OKB-KANAL
No. 4/1183   12.11.1985

To: Director of NIIKRE
Copy: I. V. Yarosh

On the memorandum of 14.10.1985

The effect described is known to the bureau. According to our estimates its magnitude under normal operating conditions does not exceed 0.2-0.3 beta and does not affect the efficiency of the emergency protection when the operating reactivity margin required by the Technological Regulations (not less than 15 rods) is maintained.

Changes to the design of the control rods will be considered in the next design cycle together with the improvement of the fuel. We do not consider it necessary to send additional instructions to the stations at this time.

Chief Designer   B. K. Levchenko
