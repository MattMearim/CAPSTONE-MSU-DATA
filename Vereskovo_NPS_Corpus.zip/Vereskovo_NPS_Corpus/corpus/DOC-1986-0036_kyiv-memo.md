---
doc_id: DOC-1986-0036
title: Republic Ministry of Health: note on reception of patients in Kyiv
doc_type: medical memo
source_system: Republic Ministry of Health
author: deputy minister (medical aid)
date: 1986-05-18
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: ORG-0021
---

# Republic Ministry of Health: note on reception of patients in Kyiv

TO: Minister
18.05.1986, 20:00

The Republic Radiology Hospital received today 71 patients from the area of Vereskovo NPS (station personnel, firefighters of relief units, construction workers). A further 24 persons are expected tomorrow. In total therefore 95 patients will be accommodated in Kyiv.

Patients with severe forms were sent to Moscow (Clinic No. 4) yesterday by special flight - 129 persons.
