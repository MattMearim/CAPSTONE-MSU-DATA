---
doc_id: DOC-1985-0005
title: Equipment passport: Unit 4 reactor and computer (extract)
doc_type: equipment passport
source_system: station technical archive
author: production-technical department
date: 1985-06-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U4-RCT-01; U4-PC-01; U4-ICM-01
---

# Equipment passport: Unit 4 reactor and computer (extract)

EQUIPMENT PASSPORT - POWER UNIT No. 4 (extract, reissued 10.06.1985)

Reactor: channel-type, graphite-moderated, boiling water cooled, model RK-1000/4
Designer: OKB-Kanal. Scientific supervisor: NIIKRE.
Rated thermal power: 3,200 MW. Rated electrical power: 1,000 MW (2 x VT-500-6K turbine-generators, Volzhsky Turbine Works).
First criticality: December 1983.
Put into commercial operation: 30 March 1984.

Control and protection system: 211 rods (manual control, automatic control, shortened absorbers, emergency protection). Insertion speed 0.4 m/s.

Computer: information-computing system VPC-4/II ("Vega-M"), manufacturer Elektron-Pribor (Kyiv). Calculates the operating reactivity margin with a cycle of 5-10 min.

In-core monitoring: SVK-4, 130 radial detectors.

Main circulation pumps: 8 x MTsN-8K, Severny Pump Plant, rated flow 8,000 m3/h each.
