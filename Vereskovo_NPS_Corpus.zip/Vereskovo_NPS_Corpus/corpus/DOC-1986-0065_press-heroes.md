---
doc_id: DOC-1986-0065
title: Sovetsky Vestnik: 'The feat of the firefighters' (article)
doc_type: newspaper article
source_system: Sovetsky Vestnik
author: G. Yakubovich
date: 1986-05-28
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: P19; P21; P20
---

# Sovetsky Vestnik: 'The feat of the firefighters' (article)

THE FEAT OF THE FIREFIGHTERS

On that night the firefighters of the guards of Lieutenants Dmitry Rudenko and Sergei Petrenko were the first to arrive. Without thinking of themselves they climbed onto the burning roof and did not allow the fire to spread to the neighbouring unit.

Major Leonid Golub, the head of the unit, arrived from home and led the fight. "My boys did not retreat a single step," he says.

The heroes are now being treated in one of the best clinics of the capital. Some of them are in serious condition, and the doctors are doing everything possible. Lieutenant Petrenko, unfortunately, could not be saved.

The whole country is proud of them.
