---
doc_id: DOC-1986-0057
title: Statement of G. P. Kuzmin (Energoteststroy)
doc_type: witness statement
source_system: procurator's office (copy in commission files)
author: G. P. Kuzmin
date: 1986-05-22
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P18; PRJ-01
---

# Statement of G. P. Kuzmin (Energoteststroy)

STATEMENT
22.05.1986, Lisove

I am an engineer of Energoteststroy (Donetsk) responsible for the electrical part of the rundown test. I was in the Unit 4 control room from 23:30 on 16 May at the desk with the oscillograph.

I did not hear the conversation about whether to continue the test after the power fell. I am an electrical engineer and was busy with my equipment. I remember that the power was about 50 MW after the fall, and later it was about 200.

The oscillograph was started at 01:31:04 by my watch. The rundown proceeded normally for about 35 seconds. Then the AZ-5 was pressed (I heard the command), and after a few seconds there was a strong shock.
