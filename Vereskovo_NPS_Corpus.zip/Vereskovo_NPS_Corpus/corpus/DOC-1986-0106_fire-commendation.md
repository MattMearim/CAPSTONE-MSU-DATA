---
doc_id: DOC-1986-0106
title: Submission for state award (posthumous): Lt. D. I. Rudenko
doc_type: award submission
source_system: regional fire directorate
author: Lt. Col. (regional fire directorate)
date: 1986-09-25
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P19; P20
---

# Submission for state award (posthumous): Lt. D. I. Rudenko

SUBMISSION FOR STATE AWARD (posthumous)

Rudenko Dmitry Ivanovich, lieutenant of the internal service, guard commander of Fire Unit No. 7.

On the night of 17 May 1986 Lieutenant Rudenko led the first guard to the fire at Unit 4 of Vereskovo NPS. He personally climbed onto the roof of the turbine hall and directed the extinguishing of the fire at the most dangerous section, preventing its spread to Unit 3.

He received a dose of over 15 Gy (1,500 rem). He died in hospital on 29 May 1986.

Initial assessment of the station medical unit on 17 May: "dose over 4 Gy, severe".

Head of the regional fire directorate
