---
doc_id: DOC-1986-0023
title: Station shift supervisor log, night of 17 May 1986 (extract)
doc_type: shift log
source_system: station shift supervisor log
author: G. A. Morozov
date: 1986-05-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P11; P01; U3-RCT-01
---

# Station shift supervisor log, night of 17 May 1986 (extract)

STATION SHIFT SUPERVISOR - OPERATING LOG (extract)
17.05.1986, night shift, NSS G. A. Morozov

01:33 Alarm from Unit 4. Loss of power supply to section 4. Fire alarm turbine hall. Called fire unit (01:33).
01:38 Nazarenko (Unit 3) reports - roof of Unit 3 on fire, debris on roof.
01:50 Called director and chief engineer at home.
02:10 Director Hrytsenko arrived, went to bunker (civil defense shelter, admin building).
02:30 Zuev reports to bunker: reactor intact, feeding water. Requested more feedwater pumps.
03:00 Chief engineer Savchenko arrived.
03:30 Dosimetrists report: their instruments at end of scale. Asked for VR-1000 from Unit 1 safe.
03:50 VR-1000 brought to Unit 4 area (V. N. Morozov).
05:15 Unit 3 shut down by Nazarenko.
06:00 Shift handed over to shift 1 (partially - many staff to medical unit).
