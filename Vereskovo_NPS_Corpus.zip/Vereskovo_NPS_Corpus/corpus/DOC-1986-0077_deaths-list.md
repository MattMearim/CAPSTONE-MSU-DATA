---
doc_id: DOC-1986-0077
title: Clinic No. 4: list of deceased patients from Vereskovo NPS as of 20 June 1986
doc_type: medical list
source_system: Central Radiological Clinic No. 4
author: Prof. A. S. Volkov
date: 1986-06-20
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P07; P08; P09; P19; P21; P22; P24
---

# Clinic No. 4: list of deceased patients from Vereskovo NPS as of 20 June 1986

LIST OF DECEASED (as of 20.06.1986) - internal

| No. | Name / code | Position | Date of death |
|---|---|---|---|
| 1 | Petrenko S. | lieutenant, Fire Unit No. 9 | 25.05.1986 |
| 2 | Chumak V. | sergeant, Fire Unit No. 7 | 27.05.1986 |
| 3 | Rudenko D. I. | lieutenant, Fire Unit No. 7 | 29.05.1986 |
| 4 | Lavrinenko A. V. | SIUR, Unit 4 | 31.05.1986 |
| 5 | Tkachuk Yu. M. | shift supervisor, Unit 4 | 02.06.1986 |
| 6 | Tsybulko M. | senior sergeant, Fire Unit No. 7 | 03.06.1986 |
| 7 | Kalinin B. F. | SIUB, Unit 4 | 14.06.1986 |
| 8-20 | (patients PT-xxxx, station and contractor personnel) | | 22.05-20.06.1986 |

Total deceased in the clinic as of 20.06.1986: 20.
Note: the clinic list does not include persons who died at the station on 17.05 (2 persons) or patients in other hospitals.
