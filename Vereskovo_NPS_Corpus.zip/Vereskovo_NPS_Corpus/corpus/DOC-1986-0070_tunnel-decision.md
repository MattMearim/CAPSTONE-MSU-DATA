---
doc_id: DOC-1986-0070
title: Government Commission decision No. 12: tunnel and cooling slab under Unit 4
doc_type: commission decision
source_system: Government Commission secretariat
author: V. A. Demidov
date: 1986-06-03
original_language: Russian (translated)
classification: secret
status: approved
related_ids: TUN-HX-01; P57
---

# Government Commission decision No. 12: tunnel and cooling slab under Unit 4

DECISION No. 12
03.06.1986

1. To prevent possible penetration of molten fuel through the foundation plate into the ground and groundwater, a tunnel shall be driven under the foundation of Unit 4 from the side of Unit 3 and a reinforced concrete slab with a built-in heat exchanger shall be installed under the foundation.

2. The work is entrusted to a brigade of miners (Ministry of Coal Industry), foreman S. Ryabov. Completion: within 30 days.

3. The heat exchanger will be connected if the temperature of the foundation rises again.
