---
doc_id: DOC-1985-0016
title: Training center: qualification records of Unit 4 reactor control staff (extract)
doc_type: training record
source_system: training center
author: A. Danilchenko
date: 1985-12-20
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P08; P67; P09
---

# Training center: qualification records of Unit 4 reactor control staff (extract)

TRAINING CENTER - QUALIFICATION RECORDS (extract) as of 20.12.1985

| Name | Position | Admitted to independent work | Last simulator/exam | Notes |
|---|---|---|---|---|
| Lavrinenko A. V. | SIUR, Unit 4 | 15.11.1985 | exam 08.11.1985 | previously SIUR trainee 1984-85 |
| Kalinin B. F. | SIUB, Unit 4 | 01.03.1982 | 14.06.1985 | |
| Kalnysh M. | SIUR, Unit 4 | 01.06.1984 | 22.05.1985 | |
| Babych P. | SIUR trainee | - | - | started training 01.09.1985 |
| Melnyk I. S. | senior turbine control engineer | 01.06.1981 | 12.03.1985 | |

Note: low-power operation exercises were not part of the 1985 program (simulator does not model the core below 10% power).

Head of training center   A. Danylchenko
