---
doc_id: DOC-1987-0018
title: Order: N. F. Makarenko
doc_type: personnel order
source_system: regional executive committee
author: chairman of the regional executive committee
date: 1987-06-30
original_language: Ukrainian (translated)
classification: for official use
status: approved
related_ids: P31
---

# Order: N. F. Makarenko

ORDER   30.06.1987

N. F. Makarenko, chair of the Vereskivsk town executive committee (seat temporarily in Lisove/Zhytnyky), is transferred to the post of deputy head of the department for evacuated persons of the regional executive committee from 1 July 1987. The town executive committee of Vereskivsk is abolished.
