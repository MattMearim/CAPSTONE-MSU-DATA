---
doc_id: DOC-1986-0032
title: Government Commission decision No. 2: evacuation of Vereskovsk
doc_type: commission decision
source_system: Government Commission secretariat
author: G. I. Zaitsev
date: 1986-05-18
original_language: Russian (translated)
classification: secret
status: approved
related_ids: SET-001; SET-006; PRJ-04
---

# Government Commission decision No. 2: evacuation of Vereskovsk

DECISION No. 2
18.05.1986, 09:30

1. Evacuate the population of the town of Vereskovsk and of the settlement at Verbovka station on 18 May 1986 from 14:00.

2. Announcement to the population through the town radio network at 13:00. The population shall be informed that the evacuation is temporary and that they should take documents, money and food for three days.

3. Transport: buses of the regional motor transport enterprises (Col. Karpenko); assembly at the entrances of residential buildings.

4. The population is to be placed in the villages of Lisove district outside the 10-km area.

5. Station personnel needed for operation of Units 1-3 remain; housed in the rotation camp (to be organized).

Chair of the Government Commission   G. Zaitsev
