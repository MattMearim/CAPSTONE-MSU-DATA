---
doc_id: DOC-1986-0017
title: Government Commission: minutes of the first meeting, Lisove, 17 May 1986, 22:00
doc_type: commission minutes
source_system: Government Commission secretariat
author: commission secretary
date: 1986-05-17
original_language: Russian (translated)
classification: secret
status: approved
related_ids: P27; P29; P01; P35
---

# Government Commission: minutes of the first meeting, Lisove, 17 May 1986, 22:00

MINUTES No. 1
Meeting of the Government Commission on the accident at Vereskovo NPS
Lisove, district Party committee building, 17.05.1986, 22:00

Chair: G. I. Zaitsev. Present: A. G. Polishchuk (Goskomatom), Academician Ye. B. Nikitin (IRP), B. K. Levchenko (OKB-Kanal), Col. A. I. Karpenko (civil defense), V. S. Hrytsenko (station), N. F. Makarenko (town).

1. Report of the station director (Hrytsenko): explosion in the area of the turbine hall during a test; reactor is being cooled with water; radiation situation in the town is within acceptable limits, maximum on site up to 1,000 micro-roentgen per second.

2. Nikitin: water supply has continued for 20 hours and water is flowing into the lower rooms; the dose rates reported by military reconnaissance near the unit (hundreds of roentgen per hour) are not consistent with an intact reactor. Proposes visual inspection from a helicopter at dawn.

3. Karpenko: plan of evacuation of the town is ready; 1,100 buses can be gathered within 6-8 hours.

4. Decided:
- helicopter reconnaissance of the unit at dawn (Nikitin, Polishchuk);
- military radiation reconnaissance of the town and 10-km area overnight;
- prepare evacuation of Vereskovsk; final decision after reconnaissance;
- stop the supply of water to Unit 4 until the condition of the reactor is known (not executed until 18.05, 09:00).
