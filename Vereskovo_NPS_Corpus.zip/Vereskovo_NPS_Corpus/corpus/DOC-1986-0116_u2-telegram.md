---
doc_id: DOC-1986-0116
title: Telegram: Unit 2 restarted
doc_type: telegram
source_system: station chancellery
author: M. Yu. Belov
date: 1986-11-06
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: U2-RCT-01
---

# Telegram: Unit 2 restarted

TELEGRAM
TO: GOSKOMATOM MOSCOW
06.11.86

UNIT 2 REACTOR BROUGHT TO MINIMUM CONTROLLED POWER ON 05.11 AT 22:40. TG-3 SYNCHRONIZED 06.11 AT 11:10.
DIRECTOR BELOV
