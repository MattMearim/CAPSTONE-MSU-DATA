---
doc_id: DOC-1987-0031
title: Recollection of P. Babych written for the training center ('what I saw')
doc_type: recollection
source_system: training center (internal collection)
author: P. Babich
date: 1987-11-10
original_language: Russian (translated)
classification: unknown
status: unknown
related_ids: P67; P07; P08; P03
---

# Recollection of P. Babych written for the training center ('what I saw')

WHAT I SAW

I was a trainee. I was not on the duty list for that panel, I came to learn.

When the power fell after midnight, Andrei (Lavrinenko) said he could not hold it. Tkachuk said "we stop". Zuev came and said the test must be done now, otherwise we wait a year for the next outage. Tkachuk did not argue more. I do not know whose decision it was in the end - nobody said "I decide".

At 01:22 Andrei took the printout. He said "seven, eight". He showed it to Tkachuk. Tkachuk looked at it and put it on the desk.

At the test Andrei was watching the power. I think he pressed the AZ when the test ended, as in the program. Or maybe he saw the power rising - I was looking at the clock. Then everything shook.

I kept my pencil dosimeter. It showed 170. They told me later that the real dose was higher.

P. Babych
