---
doc_id: DOC-1986-0055
title: Personal letter from an evacuated resident (copy kept in the district archive)
doc_type: personal letter
source_system: district archive (private letters collection)
author: Halyna
date: unknown
original_language: Ukrainian (translated)
classification: unclassified
status: unknown
related_ids: SET-001; SET-011
---

# Personal letter from an evacuated resident (copy kept in the district archive)

[Translator's note: private letter; surname not given. Date written at the top: "Wednesday".]

Dear Mama,

We are in Bilyi Brid at the house of an old woman, five of us in one room. They took us out on Sunday on buses, they said for three days, so I took only the documents and some bread. Volodya stayed at the station, I don't know where he sleeps.

People say all kinds of things. In the bus they said the director ran away from the town the first night with his family, and that is why nobody told us anything. Others say that red wine helps against the radiation, and the men are taking it seriously, you can imagine. A woman from our building says we will be home by the holidays.

The children are well. Olya's throat is a little sore, the doctor gave her tablets. Don't worry. Write to the post office in Bilyi Brid, "for the evacuated".

Your Halya
