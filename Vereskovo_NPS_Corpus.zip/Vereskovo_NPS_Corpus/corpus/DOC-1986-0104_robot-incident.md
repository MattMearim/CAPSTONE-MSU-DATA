---
doc_id: DOC-1986-0104
title: Incident report: fall of robot MRK-2 from the Unit 3 roof
doc_type: incident report
source_system: NIIKRE robotics laboratory
author: V. Chernov
date: 1986-09-19
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ROB-MRK2-01
---

# Incident report: fall of robot MRK-2 from the Unit 3 roof

INCIDENT REPORT - 19.09.1986

At 11:20 robot MRK-2 unit 01, working in zone "L" of the Unit 3 roof, drove onto a fragment of a graphite block, lost stability and fell from the roof (level +71) onto the debris of Unit 4. The robot is destroyed.

A replacement robot of the same type has been requested from Moscow. Further clearing of zones "L" and "M" will be carried out manually by personnel (decision of the Government Commission of today).
