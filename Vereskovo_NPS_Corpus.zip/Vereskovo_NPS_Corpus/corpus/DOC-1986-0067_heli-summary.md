---
doc_id: DOC-1986-0067
title: Helicopter group: summary of operations 18-28 May 1986
doc_type: operations summary
source_system: helicopter group staff
author: Col. V. Kharchenko
date: 1986-05-30
original_language: Russian (translated)
classification: secret
status: approved
related_ids: HEL-V8T; HEL-V26H; MAT-001; MAT-002; MAT-003; MAT-004; MAT-005
---

# Helicopter group: summary of operations 18-28 May 1986

SUMMARY OF OPERATIONS (18-28.05.1986)

Total sorties over Unit 4: 1,057.

Materials dropped into the reactor shaft:

| Material | Tonnes |
|---|---|
| Boron carbide | 40 |
| Dolomite | 800 |
| Sand and clay | 1,800 |
| Lead | 2,380 |
| Total | 5,020 |

Doses of crews: 14 crews removed from flights after reaching 25 R. No losses of aircraft.

Note: daily data from the 2nd squadron for 23.05 was submitted twice to the operations staff; the totals above are corrected.

Commander of the helicopter group   Col. V. Kharchenko
