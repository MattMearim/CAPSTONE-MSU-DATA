---
doc_id: DOC-1986-0045
title: VRPI situation report No. 1: increased radioactivity in Varnland
doc_type: foreign monitoring report
source_system: Varnland Radiation Protection Institute
author: Dr. M. Holt
date: 1986-05-19
original_language: English
classification: unclassified
status: approved
related_ids: ORG-0018
---

# VRPI situation report No. 1: increased radioactivity in Varnland

VARNLAND RADIATION PROTECTION INSTITUTE
Situation report No. 1 - 19 May 1986, 18:00 local time

1. Increased airborne radioactivity was detected on 19 May at Skarvik (first at 05:00 UTC) and later at Holmvik and other stations. Peak air concentrations so far: iodine-131 about 11 Bq/m3, caesium-137 about 1.5 Bq/m3 (Skarvik, evening of 19 May).

2. The nuclide composition (I-131, Cs-137, Cs-134, Te-132, Ru-103, Ba-140) indicates a release from a nuclear reactor, including fuel. The ratio Cs-134/Cs-137 suggests a power reactor fuel with significant burnup.

3. Back-trajectory analysis with meteorological services indicates air masses that passed over the western part of the Soviet Union two to three days ago.

4. No nuclear installation in Varnland is the source. All Varnland plants have reported normal conditions.

5. Doses to the Varnland public at present levels are small. Recommendations will follow.

6. The Ministry of Foreign Affairs has been asked to request information from the Soviet authorities.

M. Holt, duty physicist
