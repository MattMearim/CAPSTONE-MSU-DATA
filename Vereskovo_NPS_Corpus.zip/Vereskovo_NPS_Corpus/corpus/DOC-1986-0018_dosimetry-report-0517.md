---
doc_id: DOC-1986-0018
title: Dosimetry service: report on the radiation situation as of 08:00, 17 May 1986
doc_type: dosimetry report
source_system: dosimetry service
author: V. N. Morozov
date: 1986-05-17
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: DOS-RKS4; DOS-VR1000-0012; SET-001
---

# Dosimetry service: report on the radiation situation as of 08:00, 17 May 1986

To: Director of the station, Chief engineer
17.05.1986, 08:00

1. From 01:50 the shift dosimetrists (Lukin, Mironenko) measured with RKS-4 instruments. In the Unit 4 control room, deaerator gallery and turbine hall the instruments went to the end of the scale (4 R/h). Actual dose rates there were therefore higher than 4 R/h and could not be measured.

2. The high-range instrument VR-1000 No. 0012 was kept in the safe of the Unit 1 dosimetry room. The key was at the home of the dosimetry engineer; the safe was opened at 03:40 and the instrument brought to Unit 4 at 03:50.

3. Readings with VR-1000: north side of Unit 4 at 50 m from the debris - 250 R/h; access to the turbine hall roof - 180 R/h; Unit 4 control room - 25 R/h. Near the debris the instrument went off scale.

4. Town of Vereskovsk at 06:00: 14 mR/h on Komsomolskaya Street (north). Normal background 0.012-0.02 mR/h.

5. Graphite blocks and fuel fragments are lying on the site north of Unit 4.

6. I consider it necessary to limit access to the north side, issue iodine to all personnel and inform the town authorities.

Head of dosimetry service   V. Morozov
