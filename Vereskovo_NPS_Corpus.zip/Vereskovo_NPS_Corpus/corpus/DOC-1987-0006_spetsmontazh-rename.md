---
doc_id: DOC-1987-0006
title: Letter: renaming of Spetsmontazh Trust No. 3
doc_type: letter
source_system: Spetsatomstroy-3
author: manager of the trust
date: 1987-03-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ORG-0012
---

# Letter: renaming of Spetsmontazh Trust No. 3

To: Vereskovo NPS, SU-219, Goskomatom supply directorate
10.03.1987

We inform you that from 1 March 1987 Spetsmontazh Trust No. 3 has been reorganized and renamed Spetsatomstroy-3 (trust "Spetsatomstroy-3"). All contracts concluded with Spetsmontazh Trust No. 3 remain in force. Bank details are unchanged.
