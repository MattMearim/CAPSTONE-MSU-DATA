---
doc_id: DOC-1985-0015
title: State Nuclear Safety Inspectorate: findings of inspection of Vereskovo NPS, November 1985
doc_type: inspection report
source_system: GNI resident inspector
author: K. Ye. Fedorov
date: 1985-12-10
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: ORG-0005; U4-RCT-01
---

# State Nuclear Safety Inspectorate: findings of inspection of Vereskovo NPS, November 1985

STATE NUCLEAR SAFETY INSPECTORATE
Act of inspection No. 85-37
Period: 4-29 November 1985

Findings:

1. On two occasions in October 1985 (8 Oct and 23 Oct) the operating reactivity margin of Unit 4 fell below 15 rods (13 and 14 rods respectively, per computer printouts) without shutdown of the reactor as required by the Technological Regulations. The station considers that the printout was delayed and the actual margin was higher. The Inspectorate does not accept this explanation.

2. Test programs (including the program of the turbine-generator rundown test on Unit 3) were approved by the chief engineer of the station without agreement with the chief designer and the Inspectorate.

3. Training of senior reactor control engineers does not include exercises on low-power operation.

4. Diesel generators of Unit 4 accept load in 58-65 s.

Required: corrective measures by 01.03.1986. Programs for tests that affect reactor safety shall be agreed with the chief designer and the Inspectorate.

Resident inspector   K. Ye. Fedorov
