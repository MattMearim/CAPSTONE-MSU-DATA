---
doc_id: DOC-1987-0014
title: Recollections of Col. V. Kharchenko (anniversary article in a military newspaper)
doc_type: recollection
source_system: military newspaper (article)
author: V. Kharchenko
date: 1987-05-17
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: P56; HEL-V8T
---

# Recollections of Col. V. Kharchenko (anniversary article in a military newspaper)

"WE FLEW INTO THE MOUTH OF THE REACTOR"

...On the evening of 18 May we made the first sorties. The crater glowed below us, the heat came up through the open doors. The bags were thrown by hand at first; later we made hooks and dropped them on parachute harness.

In ten days we dropped sand, clay, dolomite, boron - and about four thousand tonnes of lead alone. The lead was brought from all over the country.

The boys flew without counting doses. Fourteen crews were taken off flights. Nobody refused.
