---
doc_id: DOC-1986-0085
title: Goskomatom order No. 314-k on the director of Vereskovo NPS
doc_type: order
source_system: Goskomatom
author: I. K. Antonov
date: 1986-07-02
original_language: Russian (translated)
classification: for official use
status: approved
related_ids: P01; P06
---

# Goskomatom order No. 314-k on the director of Vereskovo NPS

ORDER No. 314-k   02.07.1986

1. For serious shortcomings in the management of the station, which led to the accident at Unit 4, V. S. Hrytsenko is dismissed from the post of director of Vereskovo NPS from 2 July 1986.

2. Until the appointment of a new director, the deputy director S. L. Bondar is to temporarily perform the duties of director.

Chairman of Goskomatom   I. Antonov
