---
doc_id: DOC-1986-0123
title: Sovetsky Vestnik: 'The Shelter is built'
doc_type: newspaper article
source_system: Sovetsky Vestnik
author: G. Yakubovich
date: 1986-12-17
original_language: Russian (translated)
classification: unclassified
status: approved
related_ids: PRJ-06
---

# Sovetsky Vestnik: 'The Shelter is built'

THE SHELTER IS BUILT

In early December the builders completed the enclosure of the damaged fourth unit of the Vereskovo NPS - ahead of the schedule set by the Government. A unique structure, which the builders call "the sarcophagus", now reliably isolates the reactor from the environment.

The builders used hundreds of thousands of cubic metres of concrete and thousands of tonnes of metal. The work was done in conditions of high radiation, with remote-controlled cranes and the help of television cameras.
