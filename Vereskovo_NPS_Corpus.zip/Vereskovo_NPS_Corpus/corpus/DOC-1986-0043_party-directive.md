---
doc_id: DOC-1986-0043
title: Regional Party committee: directive on information about the accident
doc_type: directive
source_system: regional Party committee
author: regional Party committee secretariat
date: 1986-05-19
original_language: Russian (translated)
classification: secret
status: approved
related_ids: ORG-0023
---

# Regional Party committee: directive on information about the accident

DIRECTIVE (secret)
19.05.1986

To: editors of regional and district newspapers, regional radio

1. Information about the accident at Vereskovo NPS is to be published only in the form of official statements and materials agreed with the Government Commission.

2. Data on dose rates, contamination of territories and food, and numbers of sick persons are not to be published.

3. The evacuation of the town is to be described as a temporary precautionary measure.

4. Materials on the heroism of firefighters and station personnel are recommended.
