# World bible - Vereskovo Nuclear Power Station (fictional)

NOT for ingestion. Defines the world from which the corpus was generated.

## Setting

- **name:** Vereskovo Nuclear Power Station
- **short:** V-NPS
- **ru:** Vereskovskaya AES
- **ua:** Vereskivska AES
- **town:** Vereskovsk
- **town_ua:** Vereskivsk
- **republic:** Ukrainian SSR
- **district:** Lesnoye District (Ukr. Lisove)
- **river:** Uzhva
- **reservoir:** Uzhva reservoir
- **regional_center:** Zhitniki (Ukr. Zhytnyky)
- **rail:** Verbovka station
- **accident:** 17 May 1986, 01:31:45-01:31:48 (Moscow time = local time); Unit 4

## Organization (1985-1987)

Goskomatom (ORG-0001) -> Republic Energy Directorate -> V-NPS (Units 1-4 RBMK-type 1,000 MWe; Units 5-6 under construction). Design: NIIKRE (scientific supervisor), OKB-Kanal (chief designer). Regulator: GNI (resident inspector). Government Commission formed 17 May 1986 (rotating chairs).

Shifts: 5 operating shifts, 8-hour watches (00-08, 08-16, 16-24). Shift 5 (Tkachuk) on duty on the accident night; Shift 4 (Romanov) handed over at 00:00.

Record systems: shift supervisor and SIUR logs, Vega-M computer printouts, paper work permits (WP-YY-####), dosimetry logbooks, telegrams; after the accident L86-###### liquidator cards (1986) -> VR87-RR-NNNNN all-union registry (from 1 Mar 1987).

## ID conventions

- Personnel: VNPS-##### (station); EXT-/FIRE-/GOV- prefixes for others
- Equipment: U[unit]-[SYSTEM]-##; design institute uses other designations (e.g. Vega-M = VPC-4/II)
- Settlements: SET-###; Organizations: ORG-####; Projects: PRJ-##; Materials: MAT-### / NUC-xxx
- Work permits: WP-YY-####; Inspectorate acts: ##-##; Commission decisions: No. N; Orders: No. NNN(-k)
- Documents: DOC-YYYY-#### (by date)

## Accident-night master sequence

| Time | Event |
|---|---|
| 1986-05-15 23:00 | Power reduction of Unit 4 begins from 3,200 MWt for planned outage and TG-8 rundown test. |
| 1986-05-16 13:05 | Power 1,600 MWt; TG-7 disconnected. |
| 1986-05-16 14:00 | ECCS (SAOR) disconnected per test program; grid dispatcher (Ostrovsky) requests that Unit 4 keep generating; reduction halted at 1,600 MWt. |
| 1986-05-16 23:10 | Dispatcher permits reduction; power reduction resumes. |
| 1986-05-17 00:00 | Shift change: Shift 5 (Tkachuk, Lavrinenko, Kalinin, Melnyk) relieves Shift 4 (Romanov, Kalnysh). |
| 1986-05-17 00:28 | During transfer from local to global automatic control, power falls to about 30 MWt. |
| 1986-05-17 00:41 | Rods withdrawn to recover power; decision to continue taken (who decided is disputed). |
| 1986-05-17 01:03 | Power stabilized at about 200 MWt (planned 700-1,000 MWt). |
| 1986-05-17 01:05 | Additional MCPs started (U4-MCP-04 and U4-MCP-08); all eight pumps running. |
| 1986-05-17 01:22:30 | Vega-M printout: operating reactivity margin about 7 rod-equivalents (minimum 15). |
| 1986-05-17 01:31:05 | Test begins: TG-8 stop valves closed; rundown starts. |
| 1986-05-17 01:31:41 | AZ-5 (emergency protection) pressed. |
| 1986-05-17 01:31:44 | Power surge; instruments off scale. |
| 1986-05-17 01:31:45-48 | Two explosions; reactor and building destroyed; fires on turbine hall and Unit 3 roofs. |
| 1986-05-17 01:37 | Fire Unit No. 7 (Rudenko) arrives; Fire Unit No. 9 (Petrenko) arrives 01:42. |
| 1986-05-17 02:20 | Roof fires localized. |
| 1986-05-17 03:45 | Director's telegram to Goskomatom: reactor being cooled; radiation in town normal. |
| 1986-05-17 03:50 | VR-1000 high-range meter brought from Unit 1 safe; readings up to 200+ R/h near Unit 4; off scale near debris. |
| 1986-05-17 05:00 | Roof fires extinguished. |
| 1986-05-17 05:15 | Unit 3 shut down (Nazarenko). |
| 1986-05-17 20:40 | Government Commission (Zaitsev) arrives in Lisove. |
| 1986-05-18 13:10 | Evacuation announced on Vereskovsk radio; buses depart 14:00-16:40. |
| 1986-05-19 09:10 | Skarvik plant (Varnland) detects contamination on workers' shoes (07:10 Varnland local time = 05:10 UTC; Moscow summer time = UTC+4). |
| 1986-05-19 21:00 | Terse official statement broadcast. |
| 1986-05-18 to 05-28 | Helicopter drops: approx. 5,020 t of materials. |
| 1986-05-21 | 10-km zone villages evacuated. |
| 1986-05-23 | 30-km zone established. |
| 1986-05-25/26 | Bubbler pool drained (valve 12 opened by Shapoval, Babenko, Yakovenko 25 May; pumping completed 26 May). |
| 1986-05-29 | Graphite fire judged extinguished / release falls sharply. |

## Storylines and their documents

**1. The safety test:** DOC-1985-0004, DOC-1985-0010, DOC-1985-0015, DOC-1986-0007, DOC-1986-0012, DOC-1986-0013, DOC-1986-0011, DOC-1986-0030

**2. The accident night:** DOC-1986-0022, DOC-1986-0023, DOC-1986-0031, DOC-1986-0027, DOC-1986-0053, DOC-1986-0057, DOC-1987-0019, DOC-1987-0031

**3. Radiation underestimation:** DOC-1985-0007, DOC-1986-0028, DOC-1986-0018, DOC-1986-0024, DOC-1986-0025, DOC-1986-0017, DOC-1986-0061

**4. Firefighting and medical:** DOC-1986-0029, DOC-1986-0019, DOC-1986-0020, DOC-1986-0051, DOC-1986-0047, DOC-1986-0077, DOC-1986-0125, DOC-1986-0124, DOC-1986-0106

**5. Evacuation:** DOC-1985-0002, DOC-1986-0032, DOC-1986-0033, DOC-1986-0037, DOC-1986-0041, DOC-1986-0046, DOC-1986-0056, DOC-1986-0059, DOC-1986-0071, DOC-1986-0073, DOC-1986-0089, DOC-1987-0028, DOC-1987-0027

**6. Foreign detection:** DOC-1986-0044, DOC-1986-0064, DOC-1986-0045, DOC-1986-0040, DOC-1986-0042, DOC-1986-0099

**7. Root-cause shift:** DOC-1985-0011, DOC-1985-0012, DOC-1986-0048, DOC-1986-0091, DOC-1986-0098, DOC-1987-0021, DOC-1987-0024, DOC-1987-0032, DOC-1987-0035

**8. Core containment:** DOC-1986-0038, DOC-1986-0034, DOC-1986-0068, DOC-1986-0067, DOC-1986-0060, DOC-1986-0062, DOC-1986-0063, DOC-1986-0084, DOC-1986-0070, DOC-1986-0086, DOC-1986-0093, DOC-1987-0014

**9. Shelter construction:** DOC-1986-0074, DOC-1986-0082, DOC-1986-0100, DOC-1986-0102, DOC-1986-0104, DOC-1986-0105, DOC-1986-0110, DOC-1986-0111, DOC-1986-0122, DOC-1986-0120, DOC-1986-0121, DOC-1986-0123, DOC-1987-0004, DOC-1987-0020

**10. Liquidator dose tracking:** DOC-1986-0058, DOC-1986-0109, DOC-1986-0126, DOC-1986-0118, DOC-1987-0001, DOC-1987-0005, DOC-1987-0012, DOC-1987-0011, DOC-1987-0030

**11. Trial:** DOC-1986-0096, DOC-1986-0101, DOC-1987-0015, DOC-1987-0019, DOC-1987-0021, DOC-1987-0022

**12. Units 1-3 restart:** DOC-1986-0097, DOC-1986-0107, DOC-1986-0108, DOC-1986-0114, DOC-1986-0113, DOC-1986-0116, DOC-1986-0117, DOC-1987-0007, DOC-1987-0023, DOC-1987-0025, DOC-1987-0033, DOC-1987-0038, DOC-1987-0036

**13. Leadership change:** DOC-1986-0085, DOC-1986-0087, DOC-1986-0088, DOC-1986-0090, DOC-1986-0072, DOC-1986-0092, DOC-1986-0103, DOC-1986-0115, DOC-1986-0112

**14. MCP-3 chronic vibration:** DOC-1985-0008, DOC-1985-0018, DOC-1985-0013, DOC-1985-0014, DOC-1986-0001, DOC-1986-0014, DOC-1986-0015, DOC-1986-0048

## Document plan

| doc_id | date | format | type | author | title |
|---|---|---|---|---|---|
| DOC-1983-0001 | 1983-10-01 | md | technological regulations | OKB-Kanal / V-NPS chief engineer | Technological Operating Regulations, Units 3-4 (extract: reactivity control) |
| DOC-1985-0001 | 1985-01-28 | md | annual report | V. S. Hrytsenko | Annual report of Vereskovo NPS for 1984 (summary section) |
| DOC-1985-0002 | 1985-02-15 | md | civil defense plan | Col. A. I. Karpenko | Civil defense plan of Vereskovsk: evacuation section (extract) |
| DOC-1985-0003 | 1985-03-05 | md | municipal statistics | N. F. Makarenko | Vereskovsk town passport (data as of 1 January 1985) |
| DOC-1985-0004 | 1985-04-20 | md | test protocol | I. S. Golovko | Protocol: start-up test of Unit 4 diesel generators |
| DOC-1985-0005 | 1985-06-10 | md | equipment passport | production-technical department | Equipment passport: Unit 4 reactor and computer (extract) |
| DOC-1985-0006 | 1985-06-20 | md | delivery note | Fuel Assembly Plant No. 12 | Delivery note: fuel assemblies for Unit 4 |
| DOC-1985-0007 | 1985-07-01 | md | equipment inventory | V. N. Morozov | Dosimetry service: inventory of radiation monitoring instruments (extract) |
| DOC-1985-0008 | 1985-08-15 | md | supplier evaluation | N. Prokopenko | Supplier evaluation: Severny Pump Plant (MTsN-8K main circulation pumps) |
| DOC-1985-0009 | 1985-09-30 | md | project status report | V. Klimenko | Units 5-6 construction: status report for Q3 1985 |
| DOC-1985-0010 | 1985-10-02 | md | test report | G. P. Kuzmin | Report on rundown test of turbine-generator 5 (Unit 3), 19 September 1985 |
| DOC-1985-0011 | 1985-10-14 | md | technical memorandum | I. V. Yarosh | Memorandum: positive reactivity effect at the start of emergency protection rod insertion |
| DOC-1985-0012 | 1985-11-12 | md | letter | B. K. Levchenko | Reply of the Chief Designer to the NIIKRE memorandum of 14.10.1985 |
| DOC-1985-0013 | 1985-11-18 | md | work permit | I. Yakovenko | Work permit WP-85-1146: replacement of bearing assembly, MCP-3 Unit 4 |
| DOC-1985-0014 | 1985-11-25 | md | equipment passport | reactor shop mechanic | Equipment passport entry: MCP-3 Unit 4 (repair record) |
| DOC-1985-0015 | 1985-12-10 | md | inspection report | K. Ye. Fedorov | State Nuclear Safety Inspectorate: findings of inspection of Vereskovo NPS, November 1985 |
| DOC-1985-0016 | 1985-12-20 | md | training record | A. Danilchenko | Training center: qualification records of Unit 4 reactor control staff (extract) |
| DOC-1985-0017 | 1985-12-27 | md | meeting minutes | Party committee secretary | Minutes of the station Party committee meeting, 27 December 1985 |
| DOC-1985-0018 | 1985-12-30 | csv | maintenance data extract | I. Yakovenko | Unit 4 main circulation pump vibration log 1985 (selected pumps) |
| DOC-1986-0001 | 1986-01-14 | csv | operating statistics extract | PTO statistician | Unit 4 monthly operating summary 1985 |
| DOC-1986-0002 | 1986-01-28 | md | annual report | V. S. Hrytsenko | Annual report of Vereskovo NPS for 1985 (summary section) |
| DOC-1986-0003 | 1986-02-05 | md | municipal statistics | N. F. Makarenko | Vereskovsk town executive committee: population on 1 January 1986 |
| DOC-1986-0004 | unknown | md | informal notes | M. K. | Notes for new SIURs (handwritten, from the Unit 4 control room) |
| DOC-1986-0005 | 1986-02-20 | md | letter | N. I. Savchenko | Station response to Inspectorate act No. 85-37 |
| DOC-1986-0006 | 1986-03-01 | md | order | V. S. Hrytsenko | Order No. 56 on the composition of operating shifts, Units 3-4 |
| DOC-1986-0007 | 1986-03-14 | md | test program | A. G. Zuev | Working program of the test of TG-8 rundown, Unit 4 (Rev. 0) |
| DOC-1986-0008 | 1986-03-20 | md | internal note | radio center duty editor | Town radio schedule note (Vereskovsk radio center) |
| DOC-1986-0009 | 1986-04-01 | md | staff list | V. S. Kuzmina | Staff list: Unit 4 operating Shift 5 (as of 1 April 1986) |
| DOC-1986-0010 | 1986-04-05 | md | inspection report | K. Ye. Fedorov | Resident inspector quarterly report, Q1 1986 |
| DOC-1986-0011 | 1986-04-10 | md | maintenance plan | A. G. Zuev | Plan of the 1986 planned maintenance outage of Unit 4 |
| DOC-1986-0012 | 1986-04-22 | md | test program | A. G. Zuev | Working program of the test of TG-8 rundown, Unit 4 (Rev. 1) |
| DOC-1986-0013 | 1986-04-28 | md | letter | A. G. Zuev | Covering letter: TG-8 rundown test program sent to OKB-Kanal |
| DOC-1986-0014 | 1986-05-12 | md | internal memo | vibration diagnostics group | Memo: vibration of Unit 4 MCPs before the outage |
| DOC-1986-0015 | 1986-05-12 | csv | maintenance data extract | vibration diagnostics group | Unit 4 MCP vibration measurements, Jan-May 1986 |
| DOC-1986-0016 | 1986-05-14 | md | dispatch plan | A. Ostrovsky | Republic Grid Dispatch Center: daily plan, 15-16 May 1986 (extract) |
| DOC-1986-0017 | 1986-05-17 | md | commission minutes | commission secretary | Government Commission: minutes of the first meeting, Lisove, 17 May 1986, 22:00 |
| DOC-1986-0018 | 1986-05-17 | md | dosimetry report | V. N. Morozov | Dosimetry service: report on the radiation situation as of 08:00, 17 May 1986 |
| DOC-1986-0019 | 1986-05-17 | md | fire service report | Maj. L. T. Golub | Report of the head of Fire Unit No. 7 on the fire at Unit 4 |
| DOC-1986-0020 | 1986-05-17 | md | medical report | Dr. L. P. Gerasimova | Medical-Sanitary Unit No. 41: report as of 18:00, 17 May 1986 |
| DOC-1986-0021 | 1986-05-17 | md | telephone log | duty telephone operator | Telephone log of the civil defense shelter (bunker), 17 May 1986 |
| DOC-1986-0022 | 1986-05-17 | md | shift log | I. Romanov / Yu. Tkachuk | Operating log of the Unit 4 shift supervisor, 16-17 May 1986 (extract) |
| DOC-1986-0023 | 1986-05-17 | md | shift log | G. A. Morozov | Station shift supervisor log, night of 17 May 1986 (extract) |
| DOC-1986-0024 | 1986-05-17 | md | telegram | V. S. Hrytsenko | Telegram No. 1: report of the director to Goskomatom |
| DOC-1986-0025 | 1986-05-17 | md | telegram | V. S. Hrytsenko | Telegram No. 1 (repeat transmission) |
| DOC-1986-0026 | 1986-05-17 | md | handover note | Ye. Nazarenko | Unit 3 shift handover note, 08:00, 17 May 1986 |
| DOC-1986-0027 | 1986-05-17 | md | explanatory note | A. G. Zuev | Explanatory note of A. G. Zuev (written in MSU-41) |
| DOC-1986-0028 | 1986-05-17 | csv | dosimetry log extract | V. Morozov | Dosimetry service field readings, night of 17 May 1986 |
| DOC-1986-0029 | 1986-05-17 | csv | fire service log | Maj. Golub | Fire service deployment log, 17 May 1986 |
| DOC-1986-0030 | 1986-05-17 | csv | dispatch log extract | A. Ostrovsky | Republic Grid Dispatch Center log extract, Unit 4, 16 May 1986 |
| DOC-1986-0031 | 1986-05-17 | csv | plant computer printout | commission working group (IRP/NIIKRE) | Vega-M plant computer parameter printout, Unit 4, 16-17 May 1986 (transcribed) |
| DOC-1986-0032 | 1986-05-18 | md | commission decision | G. I. Zaitsev | Government Commission decision No. 2: evacuation of Vereskovsk |
| DOC-1986-0033 | 1986-05-18 | md | announcement | town executive committee | Text of the radio announcement to the population of Vereskovsk |
| DOC-1986-0034 | 1986-05-18 | md | order | Col. V. Kharchenko | Order on dropping materials onto Unit 4 by helicopters |
| DOC-1986-0035 | 1986-05-18 | md | medical note | Dr. L. P. Gerasimova | Note on iodine prophylaxis in Vereskovsk |
| DOC-1986-0036 | 1986-05-18 | md | medical memo | deputy minister (medical aid) | Republic Ministry of Health: note on reception of patients in Kyiv |
| DOC-1986-0037 | 1986-05-18 | md | duty log | N. F. Makarenko | Town executive committee duty log, 18 May 1986 |
| DOC-1986-0038 | 1986-05-18 | md | technical notes | Ye. B. Nikitin | Notes of Academician Nikitin after helicopter reconnaissance, 18 May 1986 |
| DOC-1986-0039 | 1986-05-18 | md | military reconnaissance report | V. Morozov | Radiation reconnaissance report, 18 May 1986, 18:00 |
| DOC-1986-0040 | 1986-05-19 | md | diplomatic note | Per Dahlstrand | Embassy of Varnland, Moscow: record of inquiries |
| DOC-1986-0041 | 1986-05-19 | md | evacuation report | Col. A. I. Karpenko | Report of the chief of staff of regional civil defense on the evacuation of Vereskovsk |
| DOC-1986-0042 | 1986-05-19 | md | official statement | Council of Ministers | Official statement broadcast on 19 May 1986, 21:00 |
| DOC-1986-0043 | 1986-05-19 | md | directive | regional Party committee secretariat | Regional Party committee: directive on information about the accident |
| DOC-1986-0044 | 1986-05-19 | md | incident report | L. Ekvall | Skarvik Nuclear Plant: internal radiation alert report |
| DOC-1986-0045 | 1986-05-19 | md | foreign monitoring report | Dr. M. Holt | VRPI situation report No. 1: increased radioactivity in Varnland |
| DOC-1986-0046 | 1986-05-19 | csv | evacuation record | Col. Karpenko | Evacuation of Vereskovsk: bus column dispatch record, 18 May 1986 |
| DOC-1986-0047 | 1986-05-20 | md | medical report | Prof. A. S. Volkov | Clinic No. 4: summary of admission of patients from Vereskovo NPS |
| DOC-1986-0048 | 1986-05-20 | md | working notes | working group secretary | Commission working group on causes: notes of 20 May 1986 |
| DOC-1986-0049 | 1986-05-20 | md | explanatory note | V. Gritsenko | Explanatory note of the director V. S. Hrytsenko to the Government Commission |
| DOC-1986-0050 | 1986-05-20 | md | newspaper article | staff correspondent | Sovetsky Vestnik: 'At the Vereskovo NPS' (article) |
| DOC-1986-0051 | 1986-05-20 | csv | medical transfer list | Dr. Gerasimova | Hospital transfer list, 17-19 May 1986 |
| DOC-1986-0052 | 1986-05-20 | csv | radiation monitoring extract | V. Morozov | Gamma dose rate in Vereskovsk and nearby points, 17-20 May 1986 |
| DOC-1986-0053 | 1986-05-21 | md | witness statement | I. S. Melnik | Statement of I. S. Melnik (recorded in Clinic No. 4) |
| DOC-1986-0054 | 1986-05-21 | md | newspaper article | Yu. Filatov | Zarya Polesya: 'At the Vereskovo NPS' (reprint with local material) |
| DOC-1986-0055 | unknown | md | personal letter | Halyna | Personal letter from an evacuated resident (copy kept in the district archive) |
| DOC-1986-0056 | 1986-05-21 | md | commission decision | G. I. Zaitsev | Government Commission decision No. 5: evacuation of the 10-km zone |
| DOC-1986-0057 | 1986-05-22 | md | witness statement | G. P. Kuzmin | Statement of G. P. Kuzmin (Energoteststroy) |
| DOC-1986-0058 | 1986-05-22 | md | order | deputy minister of health | Ministry of Health order: dose limit for persons participating in the elimination of the consequences of the accident (1986) |
| DOC-1986-0059 | 1986-05-23 | md | commission decision | G. I. Zaitsev | Government Commission decision No. 7: establishment of the 30-km zone |
| DOC-1986-0060 | 1986-05-24 | md | technical note | Ye. B. Nikitin | Note of Academician Nikitin on the danger of a steam explosion |
| DOC-1986-0061 | 1986-05-24 | csv | dose record | P. Lukin | Personal pocket dosimeter readings, night shift 16/17 May 1986 |
| DOC-1986-0062 | 1986-05-27 | md | act | V. P. Rybak; Capt. A. Lytvyn (acting head, Fire Unit No. 7) | Act on the drainage of the bubbler pool of Unit 4 |
| DOC-1986-0063 | 1986-05-27 | csv | operations record | acting head, Fire Unit No. 7 | Bubbler pool drainage record, 24-26 May 1986 |
| DOC-1986-0064 | 1986-05-27 | csv | foreign monitoring data | M. Holt | VRPI airborne radioactivity measurements, 18-26 May 1986 |
| DOC-1986-0065 | 1986-05-28 | md | newspaper article | G. Yakubovich | Sovetsky Vestnik: 'The feat of the firefighters' (article) |
| DOC-1986-0066 | 1986-05-30 | md | commission bulletin | Ye. B. Nikitin | Government Commission bulletin No. 9: state of Unit 4 |
| DOC-1986-0067 | 1986-05-30 | md | operations summary | Col. V. Kharchenko | Helicopter group: summary of operations 18-28 May 1986 |
| DOC-1986-0068 | 1986-05-30 | csv | operations log extract | Col. Kharchenko (staff) | Helicopter material drops on Unit 4, 18-28 May 1986 (daily totals) |
| DOC-1986-0069 | 1986-06-03 | md | order | Council of Ministers secretariat | Order on the change of the chairman of the Government Commission |
| DOC-1986-0070 | 1986-06-03 | md | commission decision | V. A. Demidov | Government Commission decision No. 12: tunnel and cooling slab under Unit 4 |
| DOC-1986-0071 | 1986-06-06 | md | commission decision | V. A. Demidov | Government Commission decision No. 14: evacuation of Lisove |
| DOC-1986-0072 | 1986-06-09 | md | order | A. G. Polishchuk | Order on the chief engineer |
| DOC-1986-0073 | 1986-06-10 | md | evacuation report | N. F. Makarenko | Report of the evacuation commission: evacuated population as of 10 June 1986 |
| DOC-1986-0074 | 1986-06-10 | md | order | I. K. Antonov | Goskomatom order: formation of Construction Directorate SU-219 for the Shelter |
| DOC-1986-0075 | 1986-06-15 | md | dosimetry assessment | V. N. Morozov | Assessment of doses to the population of Vereskovsk before evacuation (draft) |
| DOC-1986-0076 | 1986-06-18 | md | order | A. G. Polishchuk | Order on suspension of construction of Units 5-6 |
| DOC-1986-0077 | 1986-06-20 | md | medical list | Prof. A. S. Volkov | Clinic No. 4: list of deceased patients from Vereskovo NPS as of 20 June 1986 |
| DOC-1986-0078 | 1986-06-20 | md | order | P. A. Orlov | Order on the rotation camp 'Berezovy Gai' and the work schedule of station personnel |
| DOC-1986-0079 | 1986-06-25 | md | dosimetry assessment | V. N. Morozov | Assessment of doses to the population of Vereskovsk before evacuation |
| DOC-1986-0080 | 1986-06-25 | csv | environmental sampling report | survey team 3 | Soil contamination survey, June 1986 |
| DOC-1986-0081 | 1986-06-27 | md | instruction | Ministry of Health | Ministry of Health instruction on the confidentiality of information on the accident |
| DOC-1986-0082 | 1986-06-30 | md | technical decision | G. A. Aksyonov | Technical decision on the Shelter design (variant 'cascade wall + girder') |
| DOC-1986-0083 | 1986-06-30 | csv | food sampling extract | regional SES laboratory | Iodine-131 in cows' milk, May-June 1986 |
| DOC-1986-0084 | 1986-07-01 | csv | monitoring record | IRP working group | Unit 4 foundation slab temperature and nitrogen injected |
| DOC-1986-0085 | 1986-07-02 | md | order | I. K. Antonov | Goskomatom order No. 314-k on the director of Vereskovo NPS |
| DOC-1986-0086 | 1986-07-03 | csv | construction record | S. Ryabov | Tunnel under Unit 4: progress record, June-July 1986 |
| DOC-1986-0087 | 1986-07-04 | md | newspaper article | G. Yakubovich | Sovetsky Vestnik: 'Personal responsibility' (article) |
| DOC-1986-0088 | 1986-07-05 | md | personnel record | V. S. Kuzmina | Cadres department record card: V. S. Hrytsenko (extract) |
| DOC-1986-0089 | 1986-07-05 | csv | evacuation statistics | N. F. Makarenko | Evacuated population by settlement, as of 1 July 1986 |
| DOC-1986-0090 | 1986-07-14 | md | Party decision | regional Party committee bureau | Regional Party committee bureau: decision on V. S. Hrytsenko and others |
| DOC-1986-0091 | 1986-07-20 | md | commission report | Government Commission (working group led by Ye. B. Nikitin) | Report of the Government Commission on the causes of the accident at Unit 4 (main conclusions) |
| DOC-1986-0092 | 1986-07-28 | md | order | A. G. Polishchuk | Goskomatom order No. 349-k: acting director of Vereskovo NPS |
| DOC-1986-0093 | 1986-08-05 | md | technical note | I. V. Yarosh; IRP group | IRP note on the effectiveness of the materials dropped on Unit 4 |
| DOC-1986-0094 | 1986-08-10 | csv | technical estimate | Academician Nikitin's working group | Daily release estimate from Unit 4, 17-30 May 1986 |
| DOC-1986-0095 | 1986-08-12 | md | personnel record | V. S. Kuzmina | Cadres department: record on V. Ostapenko |
| DOC-1986-0096 | 1986-08-14 | md | procurator's information | investigator in charge | Procurator's office: information on the criminal case concerning the accident |
| DOC-1986-0097 | 1986-08-20 | md | technological regulations | P. A. Orlov | Technological Regulations, Units 1-3: changes introduced after the accident (1986 revision) |
| DOC-1986-0098 | 1986-08-27 | md | briefing slides | Soviet delegation (head: Ye. B. Nikitin) | Briefing for the International Nuclear Safety Forum, Vienna, 25-29 August 1986 (slide text) |
| DOC-1986-0099 | 1986-09-05 | md | foreign analysis | Dr. M. Holt | VRPI: comments on the Soviet information presented in Vienna |
| DOC-1986-0100 | 1986-09-08 | md | technical report | V. Chernov | Report on the use of remote robots on the Unit 3 roof (to 7 September) |
| DOC-1986-0101 | 1986-09-10 | md | interrogation record | investigator in charge | Record of interrogation of A. G. Zuev (extract) |
| DOC-1986-0102 | 1986-09-15 | md | letter | H. Aspelund | Letter from Aspelund Robotik regarding the R-40 robot |
| DOC-1986-0103 | 1986-09-15 | md | order | I. K. Antonov | Goskomatom order No. 412-k: director of Vereskovo NPS |
| DOC-1986-0104 | 1986-09-19 | md | incident report | V. Chernov | Incident report: fall of robot MRK-2 from the Unit 3 roof |
| DOC-1986-0105 | 1986-09-19 | md | commission decision | Government Commission | Government Commission decision No. 41: manual clearing of the Unit 3 roof |
| DOC-1986-0106 | 1986-09-25 | md | award submission | Lt. Col. (regional fire directorate) | Submission for state award (posthumous): Lt. D. I. Rudenko |
| DOC-1986-0107 | 1986-09-29 | md | decision | A. G. Polishchuk | Goskomatom decision: permission to restart Unit 1 |
| DOC-1986-0108 | 1986-10-01 | md | telegram | M. Yu. Belov | Telegram: Unit 1 brought to minimum controlled power |
| DOC-1986-0109 | 1986-10-01 | csv | dose list | Capt. Panchenko | Roof clearing (Unit 3 roof, zone 'M'): exposure list, 20-25 Sept 1986 |
| DOC-1986-0110 | 1986-10-02 | md | report | Capt. O. Panchenko | Report on the completion of clearing of the Unit 3 roof |
| DOC-1986-0111 | 1986-10-03 | md | acceptance act | V. Chernov | Acceptance act: replacement robot MRK-2 |
| DOC-1986-0112 | 1986-10-06 | md | order | A. G. Polishchuk | Goskomatom order No. 431-k: chief engineer of Vereskovo NPS |
| DOC-1986-0113 | 1986-10-08 | md | newspaper article | Yu. Filatov | Zarya Polesya: 'The station is working again' |
| DOC-1986-0114 | 1986-10-15 | csv | operating data extract | I. Romanov | Unit 1 restart: power ascension, Oct 1986 |
| DOC-1986-0115 | 1986-10-20 | md | letter | M. Belov | Letter of the director M. Yu. Belov to the collective of the station |
| DOC-1986-0116 | 1986-11-06 | md | telegram | M. Yu. Belov | Telegram: Unit 2 restarted |
| DOC-1986-0117 | 1986-11-20 | md | schedule | P. A. Orlov | Schedule of preparation of Unit 3 for restart |
| DOC-1986-0118 | 1986-12-04 | md | order | deputy minister of health | Ministry of Health order: dose limit for 1987 |
| DOC-1986-0119 | 1986-12-05 | csv | radiation monitoring extract | V. N. Morozov | Station site dose rates, May-December 1986 |
| DOC-1986-0120 | 1986-12-11 | md | letter | G. Aksenov | Letter of G. A. Aksyonov to the deputy chairman of Goskomatom |
| DOC-1986-0121 | 1986-12-14 | md | acceptance act | state acceptance commission | Act of acceptance of the Shelter of Unit 4 into operation |
| DOC-1986-0122 | 1986-12-16 | csv | construction progress report | G. A. Aksyonov | Shelter construction weekly progress, Jul-Dec 1986 |
| DOC-1986-0123 | 1986-12-17 | md | newspaper article | G. Yakubovich | Sovetsky Vestnik: 'The Shelter is built' |
| DOC-1986-0124 | 1986-12-20 | md | medical summary | Dr. L. P. Gerasimova | Medical summary on persons affected in the accident (status 15 December 1986) |
| DOC-1986-0125 | 1986-12-20 | csv | medical registry extract | Prof. Volkov / Dr. Gerasimova | Confirmed acute radiation sickness cases and outcomes, status 15 Dec 1986 |
| DOC-1986-0126 | 1986-12-28 | md | registry summary | registry office | Registry of participants in the work: summary for 1986 |
| DOC-1987-0001 | 1987-02-01 | md | order | M. Yu. Belov | Station order No. 38 on dose limits for 1987 |
| DOC-1987-0002 | 1987-02-16 | md | personnel order | M. Yu. Belov | Cadres department: change of surname of the head of department |
| DOC-1987-0003 | 1987-02-20 | md | reference card | A. Danilchenko | Training center reference card: units and limits (for retraining of personnel) |
| DOC-1987-0004 | 1987-02-27 | md | act | G. A. Aksyonov | Act on completion of the sealing works of the Shelter |
| DOC-1987-0005 | 1987-03-01 | md | order | Ministry of Health | Ministry of Health order on the all-union registry of persons exposed as a result of the accident |
| DOC-1987-0006 | 1987-03-10 | md | letter | manager of the trust | Letter: renaming of Spetsmontazh Trust No. 3 |
| DOC-1987-0007 | 1987-03-20 | md | internal memo | P. A. Orlov | Memo: revised date of the restart of Unit 3 |
| DOC-1987-0008 | 1987-03-31 | md | personnel order | V. S. Osipova | Cadres department: retirement of I. S. Melnyk |
| DOC-1987-0009 | 1987-04-01 | md | order | head of regional fire directorate | Regional fire directorate order: L. T. Golub |
| DOC-1987-0010 | 1987-04-10 | csv | decontamination progress report | P. A. Orlov | Decontamination results Units 1-3 (selected areas) |
| DOC-1987-0011 | 1987-04-30 | csv | registry extract | registry office, Lisove | All-union liquidator registry: extract for V-NPS contingents (1987 format) |
| DOC-1987-0012 | 1987-05-15 | md | registry report | registry office | Registry office: report on the conversion of 1986 cards into the all-union registry |
| DOC-1987-0013 | 1987-05-16 | md | newspaper article | G. Yakubovich | Sovetsky Vestnik: 'One year after Vereskovo' |
| DOC-1987-0014 | 1987-05-17 | md | recollection | V. Kharchenko | Recollections of Col. V. Kharchenko (anniversary article in a military newspaper) |
| DOC-1987-0015 | 1987-06-20 | md | indictment | procurator | Indictment in the case of the accident at Vereskovo NPS (summary) |
| DOC-1987-0016 | 1987-06-20 | csv | environmental sampling report | L. Pavlyuk | Water sampling: cooling pond, reservoir and river, 1986-1987 |
| DOC-1987-0017 | 1987-06-25 | md | environmental report | regional SES laboratory | Summary of environmental monitoring, first half of 1987 |
| DOC-1987-0018 | 1987-06-30 | md | personnel order | chairman of the regional executive committee | Order: N. F. Makarenko |
| DOC-1987-0019 | 1987-07-09 | md | trial transcript | court secretary | Trial record, day 3 (extract): testimony of A. G. Zuev and witnesses |
| DOC-1987-0020 | 1987-07-15 | md | engineering assessment | expert group (chair I. V. Yarosh) | Engineering assessment of the condition of the Shelter (July 1987) |
| DOC-1987-0021 | 1987-07-17 | md | trial transcript | court secretary | Trial record, day 9 (extract): testimony of the designers |
| DOC-1987-0022 | 1987-07-29 | md | verdict | Supreme Court | Verdict in the case of the accident at Vereskovo NPS (summary) |
| DOC-1987-0023 | 1987-08-25 | md | internal memo | P. A. Orlov | Memo: Unit 3 restart - further postponement |
| DOC-1987-0024 | 1987-09-14 | md | newspaper article | G. Yakubovich | Sovetsky Vestnik: 'What the operators were not told' (article) |
| DOC-1987-0025 | 1987-09-30 | md | inspection report | R. K. Demchenko | State Nuclear Safety Inspectorate: inspection of Vereskovo NPS, September 1987 (summary) |
| DOC-1987-0026 | 1987-10-05 | md | decision | republic Council of Ministers | Republic Council of Ministers decision on the construction of the town of Lisogorsk |
| DOC-1987-0027 | 1987-10-15 | md | decision | republic Council of Ministers | Republic Council of Ministers decision on additional resettlement |
| DOC-1987-0028 | 1987-10-20 | csv | decision register extract | regional executive committee secretariat | Zone assignment decisions, 1986-1987 |
| DOC-1987-0029 | 1987-10-31 | md | decision | Council of Ministers | Council of Ministers decision: termination of the construction of Units 5-6 |
| DOC-1987-0030 | 1987-11-02 | md | registry report | Dr. L. P. Gerasimova | Health monitoring registry: annual report 1987 (summary) |
| DOC-1987-0031 | 1987-11-10 | md | recollection | P. Babich | Recollection of P. Babych written for the training center ('what I saw') |
| DOC-1987-0032 | 1987-11-20 | md | commission report | GNI working group (lead author I. V. Yarosh) | Report of the GNI working group: analysis of the causes of the accident at Unit 4 (revised) |
| DOC-1987-0033 | 1987-12-04 | md | telegram | M. Yu. Belov | Telegram: Unit 3 restarted |
| DOC-1987-0034 | 1987-12-05 | csv | personnel statistics | V. S. Osipova | Station headcount by department, 1985-1987 |
| DOC-1987-0035 | 1987-12-10 | md | letter | B. K. Levchenko | OKB-Kanal: comments on the report of the GNI working group of 20.11.1987 |
| DOC-1987-0036 | 1987-12-10 | md | newspaper article | Yu. Filatov | Zarya Polesya: 'The third unit is back' |
| DOC-1987-0037 | 1987-12-15 | md | financial summary | planning-economic directorate | Goskomatom: summary of expenditure on the elimination of the consequences of the accident (to 30 November 1987) |
| DOC-1987-0038 | 1987-12-29 | csv | operating data extract | Ye. Nazarenko | Unit 3 restart: power ascension, Dec 1987 |
| DOC-1988-0001 | 1988-01-08 | csv | operating statistics extract | PTO statistician | Gross electricity generation by unit, 1987 |
| DOC-1988-0002 | 1988-01-20 | csv | financial summary extract | planning-economic directorate | Accident-related expenditure by project, May 1986 - Dec 1987 |
