# Run FRIB on macOS with real local AI

Extract the complete project into a writable folder, then double-click **START_FRIB.command**. That one launcher prepares missing dependencies, the private Ollama runtime, **qwen3:8b**, and **all-MiniLM-L6-v2**, starts the API and dashboard, and opens the app at http://127.0.0.1:8501. If you have only the source folder, use **Start FRIB.command** there. First setup needs internet access and several gigabytes of disk space for model downloads; later launches reuse the installed environment and cached models.

For fictional practice data in a separate workspace, use **START_LIVE_DEMO.command**. Both launchers use real local models; “demo” describes the data. A normal Finder launch opens a progress window with **Preparing application → Preparing AI → Starting workspace → Ready**. **Show details** reveals logs, **Retry** is available after a failure, and **Open workspace** returns to the browser. Keep the startup window open and use **Stop workspace** when finished. Reopening an already-running app shows **Close window** and leaves the original app running. Terminal-only and `--no-browser` runs keep their existing Ctrl+C controls. Set `FRIB_NO_GUI=1` to use the console explicitly. **SETUP_LOCAL_AI.command** remains an optional setup/repair command.

Inside the app, **Next** and **Back** at the bottom keep your dataset selected and move through data, procedures, investigation, guidance and review. During the first-use tutorial they follow the same tour as the controls above. Clicking a citation opens its highlighted source excerpt beside the answer; original documents remain available for download. Navigation alone never approves a finding.

The launcher requires 64-bit Python 3.11, 3.12 or 3.13. It detects python.org and Homebrew installations. If none is present, install Python 3.12 from [python.org](https://www.python.org/downloads/macos/). The project installs packages into its private environment, without changing system Python.

AI files are stored permanently in **~/Library/Application Support/FRIB**, shared by all project copies. In Finder, choose **Go → Go to Folder…** and paste that path. **tools/ollama** holds Ollama, **models/ollama** holds Qwen, and **cache/huggingface** holds the semantic embedding model. Closing the app, restarting the Mac, moving the project or extracting a fresh copy does not remove these files. Setup checks for an installed model before pulling anything. An already prepared model cache loads offline; changing to a model that is not installed requires a one-time download. Set **FRIB_AI_HOME** before launch to choose a different permanent storage location. Normal saved records live in **FRIB_Decision_Support/data-local-ai**; presentation records live in **Demo_Workspace_AI** beside the main launchers. During first setup, if **data/frib.db** exists and **data-local-ai** does not, setup copies the existing normal workspace and re-embeds its approved document chunks with the real embedding model. The source **data** folder is untouched. An existing **data-local-ai** destination is never overwritten. The old **Demo_Workspace** is retained but is not migrated automatically; upload presentation procedures into **Demo_Workspace_AI** when needed.

Python packages are also kept in the permanent FRIB folder under **python**. A fresh project copy with the same Python installation and package requirements reuses them without downloading; its small local environment points to that copy's source files. Existing working environments remain usable. Changing Python or applying package upgrades can require new compatible packages; it does not remove the saved AI models.

If Finder refuses to open a downloaded launcher, use Terminal in the extracted folder:

```sh
bash START_FRIB.command
```

For an installation check, run `bash START_FRIB.command --check`. **RUN_DEMO_CHECKS.command** checks the supplied fictional inputs in disposable storage with explicit test doubles; it does not measure real-model answer quality. Its results are saved in **Demo_Check_Results/TEST_LAB_RESULTS.md**. Normal application launchers never select those test providers.

Launchers support paths with spaces and arguments such as `--no-browser`, `--api-port 8002` and `--port 8502`. Set `FRIB_PYTHON` to select a compatible Python executable or `FRIB_NO_PAUSE=1` for unattended checks. Opening the same launcher twice reopens the existing healthy app for that workspace. Closing a browser tab does not stop it.
