from .registry import ProcessorRegistry
