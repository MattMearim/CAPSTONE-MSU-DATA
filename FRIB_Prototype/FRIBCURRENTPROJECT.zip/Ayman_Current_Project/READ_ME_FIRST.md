# Ayman project on this Mac

Double-click **START_AYMAN.command** in this folder to start the application.
The launcher finds the project relative to itself, so keep the folder together.

The original branch ZIP is in Downloads as `CAPSTONE-MSU-DATA-aymanfull-zip.zip`.
The extracted source is under `CAPSTONE-MSU-DATA-aymanfull-zip/FRIB_Final_Project/FRIB_Decision_Support`.

AI selection is editable in **AI settings**. The local `config/ai-settings.json`
profile selects the model already cached on this Mac, avoiding another model
download. Model files remain in the permanent per-user FRIB storage folder;
application records belong to this extracted workspace.

The local fixes preserve selected models in demo launchers and prevent real AI
drafts from being filled with canned summaries, hypotheses, or actions. Measured
observations and source identifiers continue to come directly from evidence.

Model names, server addresses, and data locations have
configuration defaults. Safety limits, schemas, and pinned download checksums
remain deliberate code constants.
