# Ayman project: local macOS verification

Checked November 13, 2026. Source: `MattMearim/CAPSTONE-MSU-DATA`, branch
`aymanfull-zip`, commit `6dc17bbe88d2d4f2bab398aef06c974d8382cd18`.
The GitHub branch was not modified.

Original download: `CAPSTONE-MSU-DATA-aymanfull-zip.zip` in Downloads.
SHA256: `f9473f6260a31657e1951c96d1fddb79581e1e09195be249e409ab2cedb3c704`.
Archive integrity passed before extraction (453 members); extraction rejected
traversal and symlink entries. The original download remains unchanged.

## Configuration and AI behavior

- No embedded credentials or user-specific absolute runtime paths were found in
  the inspected application and launch scripts. Paths derive from the project
  folder or the current user's standard storage directories.
- Removed forced LLM and embedding selections from provided/generated demo
  launchers. YAML, environment variables and saved profiles retain control.
- Real model drafts no longer receive canned summaries, hypotheses or review
  actions when the model omits them. Empty summaries fail without saving;
  empty guidance stays empty. Explicit mock providers remain isolated test tools
  and are rejected by ordinary application startup.
- Measured observations and source identifiers still come directly from evidence.
- The real-AI verification helper now accepts a question and procedure title,
  instead of always asking its original Chernobyl training question.
- Selected this Mac's already cached `qwen3:8b` model through an editable profile.
  The models stay in the permanent per-user FRIB cache. No model weights were
  downloaded again. The editable context/output budgets are 8192/2048 tokens.

Defaults, prompt instructions, schemas, safety limits and pinned download
checksums remain intentional constants. This is not a claim that software
contains no literals or that every possible defect has been eliminated.

## Repairs needed to run and verify this copy

- Registered the newly declared `psutil` dependency in startup's import checks.
  Previously first-time installation succeeded but validation failed with a
  `KeyError`, preventing startup.
- Added `psutil` to the curated upgrade allowlist with its `>=6,<8` bound.
- Scoped draft citation controls by their rendering location/knowledge record,
  preventing a duplicate-widget crash for records sharing a draft ID.
- Updated two obsolete test assumptions and added regression coverage for
  dependency registration, model preservation and strict real-model drafts.
- Created the portable top-level `START_AYMAN.command` shortcut.

## Verification results

- Final complete suite: **1463 passed, 7 skipped**, 157.88 seconds.
- Both API and dashboard responded successfully on local ports 8000/8501.
- Startup receipt identifies this extracted Ayman project as the active workspace.
- One API listener, one dashboard listener and one local Ollama listener were
  present after verified handoff from the older FRIB copy.
- Real inference check used the included fictional RF CSV/procedure in temporary
  application storage: real SentenceTransformers embeddings, `llm` cited answer
  with four source passages, and a `configured_llm` draft. No verification
  events/documents were added to the user's active workspace.

Detailed local reports are in the source folder's `.frib/full-tests-final.xml`
and `.frib/verification/real-ai.json`. The broader upstream audit and its separate
analysis/deployment limitations remain in `PROJECT_CHECK_REPORT.md`.
