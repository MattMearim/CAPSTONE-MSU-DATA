"""A real model's omissions must never turn into canned engineering guidance."""
from datetime import datetime, timezone
import json
from pathlib import Path

import pytest

from frib_ds.knowledge import service
from frib_ds.models import AnalysisResult, EngineeringEvent, RAGResponse, RAGSource
from frib_ds.rag.llm import MockLLMProvider
from frib_ds.storage.sqlite import SQLiteRepository


PROMPTS = Path(__file__).resolve().parents[1] / "prompts"


class ModelResponse:
    identity = {"provider": "ollama", "model": "selected-real-model"}

    def __init__(self, payload):
        self.payload = payload

    def chat(self, *_args, **_kwargs):
        return json.dumps(self.payload)


def evidence():
    event = EngineeringEvent(
        event_id="NO-CANNED-1", domain="mechanical", event_type="pressure_change",
        provenance={"source": "test_measurement"},
    )
    analysis = AnalysisResult(
        event_id=event.event_id, processor="measured_signal", processor_version="1",
        findings=["Pressure increased from 2 to 3 kPa."],
    )
    rag = RAGResponse(question="What happened?", answer="Retrieved context", sources=[
        RAGSource(label="S1", title="Approved inspection procedure", document_id="DOC-1",
                  chunk_id="CHUNK-1", version="2", page=4),
    ])
    return event, analysis, rag


@pytest.mark.parametrize("summary", ["", " ", "\n\t", None])
def test_empty_real_summary_fails_without_saving_a_substitute(tmp_path, summary):
    repo = SQLiteRepository(tmp_path / "drafts.db")
    event, analysis, rag = evidence()
    model = ModelResponse({"summary": summary, "hypotheses": [], "recommended_actions": []})

    with pytest.raises(service.KnowledgeGenerationUnavailable, match="No replacement draft"):
        service.KnowledgeService(repo, model, PROMPTS).create_draft(event, analysis, rag)

    assert repo.latest_draft_for_event(event.event_id) is None
    assert repo.list_knowledge() == []


@pytest.mark.parametrize("include_empty_fields", [True, False])
def test_real_draft_keeps_missing_or_empty_guidance_empty(tmp_path, monkeypatch, include_empty_fields):
    def no_mock_templates(*_args):
        raise AssertionError("A real model must never invoke deterministic hypothesis templates")

    monkeypatch.setattr(service, "build_hypotheses", no_mock_templates)
    payload = {
        "summary": "The measured pressure increased; the cause remains unresolved.",
        "observations": ["Invented measurement"], "relevant_sources": ["Invented source"],
        "draft_id": "FORGED", "event_id": "FORGED", "status": "approved",
        "generated_by": "human", "created_at": "9999-01-01T00:00:00Z",
        "generation": {"provider": "forged"}, "evidence_snapshot": {"event_sha256": "forged"},
    }
    if include_empty_fields:
        payload.update(hypotheses=[], recommended_actions=[])
    repo = SQLiteRepository(tmp_path / "drafts.db")
    event, analysis, rag = evidence()
    before = datetime.now(timezone.utc)

    draft = service.KnowledgeService(repo, ModelResponse(payload), PROMPTS).create_draft(event, analysis, rag)

    assert draft.summary == payload["summary"]
    assert draft.hypotheses == []
    assert draft.recommended_actions == []
    assert draft.generated_by == "configured_llm"
    assert draft.generation == ModelResponse.identity
    assert draft.observations == analysis.findings
    assert draft.relevant_sources == [
        "S1: Approved inspection procedure; document=DOC-1; chunk=CHUNK-1; version=2; page=4"
    ]
    assert draft.tags == [event.domain, event.event_type]
    assert draft.draft_id != "FORGED" and draft.event_id == event.event_id
    assert draft.status == "draft"
    assert before <= draft.created_at <= datetime.now(timezone.utc)
    assert draft.evidence_snapshot["generation"] == ModelResponse.identity
    assert draft.evidence_snapshot["event_sha256"] != "forged"
    saved = repo.get_draft(draft.draft_id)
    assert saved.hypotheses == [] and saved.recommended_actions == []


def test_real_guidance_is_preserved_without_template_additions(tmp_path):
    payload = {
        "summary": "Model interpretation requiring review.",
        "hypotheses": [{"rank": 4, "description": "A model-proposed possibility", "support": "low"}],
        "recommended_actions": ["Review the recorded sensor calibration history."],
        "tags": ["model_tag"],
    }
    event, analysis, rag = evidence()
    repo = SQLiteRepository(tmp_path / "drafts.db")

    draft = service.KnowledgeService(repo, ModelResponse(payload), PROMPTS).create_draft(event, analysis, rag)

    assert [item.description for item in draft.hypotheses] == ["A model-proposed possibility"]
    assert [item.rank for item in draft.hypotheses] == [1]
    assert draft.recommended_actions == payload["recommended_actions"]
    assert draft.tags == ["model_tag"]
    assert draft.generated_by == "configured_llm"


def test_explicit_mock_provider_retains_isolated_test_fallback(tmp_path):
    event, analysis, rag = evidence()
    repo = SQLiteRepository(tmp_path / "drafts.db")

    draft = service.KnowledgeService(repo, MockLLMProvider(), PROMPTS).create_draft(event, analysis, rag)

    assert draft.generated_by == "deterministic_fallback"
    assert draft.summary.strip() and draft.recommended_actions
    assert draft.observations == analysis.findings
    assert draft.generation == {}
    assert repo.get_draft(draft.draft_id) is not None
