#!/bin/bash
# Keep this launcher portable when the whole project folder is moved.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec "$ROOT/CAPSTONE-MSU-DATA-aymanfull-zip/FRIB_Final_Project/START_FRIB.command" "$@"
